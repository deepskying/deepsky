var Ed = Object.defineProperty;
var fd = (X, c, Z) => c in X ? Ed(X, c, { enumerable: !0, configurable: !0, writable: !0, value: Z }) : X[c] = Z;
var nd = (X, c, Z) => fd(X, typeof c != "symbol" ? c + "" : c, Z);
const Ad=deepsky.UIMod
const qd=deepsky._ToolType
var $ = { exports: {} }, td;
function _d() {
  return td || (td = 1, function(X) {
    var c = function(Z) {
      var i = Object.prototype, y = i.hasOwnProperty, s = Object.defineProperty || function(l, d, m) {
        l[d] = m.value;
      }, h, M = typeof Symbol == "function" ? Symbol : {}, S = M.iterator || "@@iterator", C = M.asyncIterator || "@@asyncIterator", e = M.toStringTag || "@@toStringTag";
      function L(l, d, m) {
        return Object.defineProperty(l, d, {
          value: m,
          enumerable: !0,
          configurable: !0,
          writable: !0
        }), l[d];
      }
      try {
        L({}, "");
      } catch {
        L = function(d, m, G) {
          return d[m] = G;
        };
      }
      function R(l, d, m, G) {
        var b = d && d.prototype instanceof K ? d : K, u = Object.create(b.prototype), o = new O(G || []);
        return s(u, "_invoke", { value: q(l, m, o) }), u;
      }
      Z.wrap = R;
      function P(l, d, m) {
        try {
          return { type: "normal", arg: l.call(d, m) };
        } catch (G) {
          return { type: "throw", arg: G };
        }
      }
      var F = "suspendedStart", a = "suspendedYield", Y = "executing", j = "completed", V = {};
      function K() {
      }
      function T() {
      }
      function H() {
      }
      var r = {};
      L(r, S, function() {
        return this;
      });
      var v = Object.getPrototypeOf, U = v && v(v(E([])));
      U && U !== i && y.call(U, S) && (r = U);
      var k = H.prototype = K.prototype = Object.create(r);
      T.prototype = H, s(k, "constructor", { value: H, configurable: !0 }), s(
        H,
        "constructor",
        { value: T, configurable: !0 }
      ), T.displayName = L(
        H,
        e,
        "GeneratorFunction"
      );
      function D(l) {
        ["next", "throw", "return"].forEach(function(d) {
          L(l, d, function(m) {
            return this._invoke(d, m);
          });
        });
      }
      Z.isGeneratorFunction = function(l) {
        var d = typeof l == "function" && l.constructor;
        return d ? d === T || // For the native GeneratorFunction constructor, the best we can
        // do is to check its .name property.
        (d.displayName || d.name) === "GeneratorFunction" : !1;
      }, Z.mark = function(l) {
        return Object.setPrototypeOf ? Object.setPrototypeOf(l, H) : (l.__proto__ = H, L(l, e, "GeneratorFunction")), l.prototype = Object.create(k), l;
      }, Z.awrap = function(l) {
        return { __await: l };
      };
      function Q(l, d) {
        function m(u, o, n, J) {
          var t = P(l[u], l, o);
          if (t.type === "throw")
            J(t.arg);
          else {
            var W = t.arg, p = W.value;
            return p && typeof p == "object" && y.call(p, "__await") ? d.resolve(p.__await).then(function(I) {
              m("next", I, n, J);
            }, function(I) {
              m("throw", I, n, J);
            }) : d.resolve(p).then(function(I) {
              W.value = I, n(W);
            }, function(I) {
              return m("throw", I, n, J);
            });
          }
        }
        var G;
        function b(u, o) {
          function n() {
            return new d(function(J, t) {
              m(u, o, J, t);
            });
          }
          return G = // If enqueue has been called before, then we want to wait until
          // all previous Promises have been resolved before calling invoke,
          // so that results are always delivered in the correct order. If
          // enqueue has not been called before, then it is important to
          // call invoke immediately, without waiting on a callback to fire,
          // so that the async generator function has the opportunity to do
          // any necessary setup in a predictable way. This predictability
          // is why the Promise constructor synchronously invokes its
          // executor callback, and why async functions synchronously
          // execute code before the first await. Since we implement simple
          // async functions in terms of async generators, it is especially
          // important to get this right, even though it requires care.
          G ? G.then(
            n,
            // Avoid propagating failures to Promises returned by later
            // invocations of the iterator.
            n
          ) : n();
        }
        s(this, "_invoke", { value: b });
      }
      D(Q.prototype), L(Q.prototype, C, function() {
        return this;
      }), Z.AsyncIterator = Q, Z.async = function(l, d, m, G, b) {
        b === void 0 && (b = Promise);
        var u = new Q(
          R(l, d, m, G),
          b
        );
        return Z.isGeneratorFunction(d) ? u : u.next().then(function(o) {
          return o.done ? o.value : u.next();
        });
      };
      function q(l, d, m) {
        var G = F;
        return function(u, o) {
          if (G === Y)
            throw new Error("Generator is already running");
          if (G === j) {
            if (u === "throw")
              throw o;
            return A();
          }
          for (m.method = u, m.arg = o; ; ) {
            var n = m.delegate;
            if (n) {
              var J = g(n, m);
              if (J) {
                if (J === V) continue;
                return J;
              }
            }
            if (m.method === "next")
              m.sent = m._sent = m.arg;
            else if (m.method === "throw") {
              if (G === F)
                throw G = j, m.arg;
              m.dispatchException(m.arg);
            } else m.method === "return" && m.abrupt("return", m.arg);
            G = Y;
            var t = P(l, d, m);
            if (t.type === "normal") {
              if (G = m.done ? j : a, t.arg === V)
                continue;
              return {
                value: t.arg,
                done: m.done
              };
            } else t.type === "throw" && (G = j, m.method = "throw", m.arg = t.arg);
          }
        };
      }
      function g(l, d) {
        var m = d.method, G = l.iterator[m];
        if (G === h)
          return d.delegate = null, m === "throw" && l.iterator.return && (d.method = "return", d.arg = h, g(l, d), d.method === "throw") || m !== "return" && (d.method = "throw", d.arg = new TypeError(
            "The iterator does not provide a '" + m + "' method"
          )), V;
        var b = P(G, l.iterator, d.arg);
        if (b.type === "throw")
          return d.method = "throw", d.arg = b.arg, d.delegate = null, V;
        var u = b.arg;
        if (!u)
          return d.method = "throw", d.arg = new TypeError("iterator result is not an object"), d.delegate = null, V;
        if (u.done)
          d[l.resultName] = u.value, d.next = l.nextLoc, d.method !== "return" && (d.method = "next", d.arg = h);
        else
          return u;
        return d.delegate = null, V;
      }
      D(k), L(k, e, "Generator"), L(k, S, function() {
        return this;
      }), L(k, "toString", function() {
        return "[object Generator]";
      });
      function x(l) {
        var d = { tryLoc: l[0] };
        1 in l && (d.catchLoc = l[1]), 2 in l && (d.finallyLoc = l[2], d.afterLoc = l[3]), this.tryEntries.push(d);
      }
      function B(l) {
        var d = l.completion || {};
        d.type = "normal", delete d.arg, l.completion = d;
      }
      function O(l) {
        this.tryEntries = [{ tryLoc: "root" }], l.forEach(x, this), this.reset(!0);
      }
      Z.keys = function(l) {
        var d = Object(l), m = [];
        for (var G in d)
          m.push(G);
        return m.reverse(), function b() {
          for (; m.length; ) {
            var u = m.pop();
            if (u in d)
              return b.value = u, b.done = !1, b;
          }
          return b.done = !0, b;
        };
      };
      function E(l) {
        if (l) {
          var d = l[S];
          if (d)
            return d.call(l);
          if (typeof l.next == "function")
            return l;
          if (!isNaN(l.length)) {
            var m = -1, G = function b() {
              for (; ++m < l.length; )
                if (y.call(l, m))
                  return b.value = l[m], b.done = !1, b;
              return b.value = h, b.done = !0, b;
            };
            return G.next = G;
          }
        }
        return { next: A };
      }
      Z.values = E;
      function A() {
        return { value: h, done: !0 };
      }
      return O.prototype = {
        constructor: O,
        reset: function(l) {
          if (this.prev = 0, this.next = 0, this.sent = this._sent = h, this.done = !1, this.delegate = null, this.method = "next", this.arg = h, this.tryEntries.forEach(B), !l)
            for (var d in this)
              d.charAt(0) === "t" && y.call(this, d) && !isNaN(+d.slice(1)) && (this[d] = h);
        },
        stop: function() {
          this.done = !0;
          var l = this.tryEntries[0], d = l.completion;
          if (d.type === "throw")
            throw d.arg;
          return this.rval;
        },
        dispatchException: function(l) {
          if (this.done)
            throw l;
          var d = this;
          function m(J, t) {
            return u.type = "throw", u.arg = l, d.next = J, t && (d.method = "next", d.arg = h), !!t;
          }
          for (var G = this.tryEntries.length - 1; G >= 0; --G) {
            var b = this.tryEntries[G], u = b.completion;
            if (b.tryLoc === "root")
              return m("end");
            if (b.tryLoc <= this.prev) {
              var o = y.call(b, "catchLoc"), n = y.call(b, "finallyLoc");
              if (o && n) {
                if (this.prev < b.catchLoc)
                  return m(b.catchLoc, !0);
                if (this.prev < b.finallyLoc)
                  return m(b.finallyLoc);
              } else if (o) {
                if (this.prev < b.catchLoc)
                  return m(b.catchLoc, !0);
              } else if (n) {
                if (this.prev < b.finallyLoc)
                  return m(b.finallyLoc);
              } else
                throw new Error("try statement without catch or finally");
            }
          }
        },
        abrupt: function(l, d) {
          for (var m = this.tryEntries.length - 1; m >= 0; --m) {
            var G = this.tryEntries[m];
            if (G.tryLoc <= this.prev && y.call(G, "finallyLoc") && this.prev < G.finallyLoc) {
              var b = G;
              break;
            }
          }
          b && (l === "break" || l === "continue") && b.tryLoc <= d && d <= b.finallyLoc && (b = null);
          var u = b ? b.completion : {};
          return u.type = l, u.arg = d, b ? (this.method = "next", this.next = b.finallyLoc, V) : this.complete(u);
        },
        complete: function(l, d) {
          if (l.type === "throw")
            throw l.arg;
          return l.type === "break" || l.type === "continue" ? this.next = l.arg : l.type === "return" ? (this.rval = this.arg = l.arg, this.method = "return", this.next = "end") : l.type === "normal" && d && (this.next = d), V;
        },
        finish: function(l) {
          for (var d = this.tryEntries.length - 1; d >= 0; --d) {
            var m = this.tryEntries[d];
            if (m.finallyLoc === l)
              return this.complete(m.completion, m.afterLoc), B(m), V;
          }
        },
        catch: function(l) {
          for (var d = this.tryEntries.length - 1; d >= 0; --d) {
            var m = this.tryEntries[d];
            if (m.tryLoc === l) {
              var G = m.completion;
              if (G.type === "throw") {
                var b = G.arg;
                B(m);
              }
              return b;
            }
          }
          throw new Error("illegal catch attempt");
        },
        delegateYield: function(l, d, m) {
          return this.delegate = {
            iterator: E(l),
            resultName: d,
            nextLoc: m
          }, this.method === "next" && (this.arg = h), V;
        }
      }, Z;
    }(
      // If this script is executing as a CommonJS module, use module.exports
      // as the regeneratorRuntime namespace. Otherwise create a new empty
      // object. Either way, the resulting object will be used to initialize
      // the regeneratorRuntime variable at the top of this file.
      X.exports
    );
    try {
      regeneratorRuntime = c;
    } catch {
      typeof globalThis == "object" ? globalThis.regeneratorRuntime = c : Function("r", "regeneratorRuntime = r")(c);
    }
  }($)), $.exports;
}
var dd, Md;
function Kd() {
  return Md || (Md = 1, dd = (X, c) => `${X}-${c}-${Math.random().toString(16).slice(3, 8)}`), dd;
}
var ld, Td;
function Qd() {
  if (Td) return ld;
  Td = 1;
  const X = Kd();
  let c = 0;
  return ld = ({
    id: Z,
    action: i,
    payload: y = {}
  }) => {
    let s = Z;
    return typeof s > "u" && (s = X("Job", c), c += 1), {
      id: s,
      action: i,
      payload: y
    };
  }, ld;
}
var f = {}, Jd;
function Vd() {
  if (Jd) return f;
  Jd = 1;
  let X = !1;
  return f.logging = X, f.setLogging = (c) => {
    X = c;
  }, f.log = (...c) => X ? console.log.apply(this, c) : null, f;
}
var md, Sd;
function $d() {
  if (Sd) return md;
  Sd = 1;
  const X = Qd(), { log: c } = Vd(), Z = Kd();
  let i = 0;
  return md = () => {
    const y = Z("Scheduler", i), s = {}, h = {};
    let M = [];
    i += 1;
    const S = () => M.length, C = () => Object.keys(s).length, e = () => {
      if (M.length !== 0) {
        const a = Object.keys(s);
        for (let Y = 0; Y < a.length; Y += 1)
          if (typeof h[a[Y]] > "u") {
            M[0](s[a[Y]]);
            break;
          }
      }
    }, L = (a, Y) => new Promise((j, V) => {
      const K = X({ action: a, payload: Y });
      M.push(async (T) => {
        M.shift(), h[T.id] = K;
        try {
          j(await T[a].apply(this, [...Y, K.id]));
        } catch (H) {
          V(H);
        } finally {
          delete h[T.id], e();
        }
      }), c(`[${y}]: Add ${K.id} to JobQueue`), c(`[${y}]: JobQueue length=${M.length}`), e();
    });
    return {
      addWorker: (a) => (s[a.id] = a, c(`[${y}]: Add ${a.id}`), c(`[${y}]: Number of workers=${C()}`), e(), a.id),
      addJob: async (a, ...Y) => {
        if (C() === 0)
          throw Error(`[${y}]: You need to have at least one worker before adding jobs`);
        return L(a, Y);
      },
      terminate: async () => {
        Object.keys(s).forEach(async (a) => {
          await s[a].terminate();
        }), M = [];
      },
      getQueueLen: S,
      getNumWorkers: C
    };
  }, md;
}
function dl(X) {
  throw new Error('Could not dynamically require "' + X + '". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.');
}
var Zd, Rd;
function ll() {
  return Rd || (Rd = 1, Zd = (X) => {
    const c = {};
    return typeof WorkerGlobalScope < "u" ? c.type = "webworker" : typeof document == "object" ? c.type = "browser" : typeof process == "object" && typeof dl == "function" && (c.type = "node"), typeof X > "u" ? c : c[X];
  }), Zd;
}
var cd, Hd;
function ml() {
  if (Hd) return cd;
  Hd = 1;
  const c = ll()("type") === "browser" ? (Z) => new URL(Z, window.location.href).href : (Z) => Z;
  return cd = (Z) => {
    const i = { ...Z };
    return ["corePath", "workerPath", "langPath"].forEach((y) => {
      Z[y] && (i[y] = c(i[y]));
    }), i;
  }, cd;
}
var bd, xd;
function Dd() {
  return xd || (xd = 1, bd = {
    TESSERACT_ONLY: 0,
    LSTM_ONLY: 1,
    TESSERACT_LSTM_COMBINED: 2,
    DEFAULT: 3
  }), bd;
}
const Zl = "6.0.1", cl = {
  version: Zl
};
var Xd, zd;
function bl() {
  return zd || (zd = 1, Xd = {
    /*
     * Use BlobURL for worker script by default
     * TODO: remove this option
     *
     */
    workerBlobURL: !0,
    logger: () => {
    }
  }), Xd;
}
var yd, Nd;
function Xl() {
  if (Nd) return yd;
  Nd = 1;
  const X = cl.version;
  return yd = {
    ...bl(),
    workerPath: `https://cdn.jsdelivr.net/npm/tesseract.js@v${X}/dist/worker.min.js`
  }, yd;
}
var Gd, Cd;
function yl() {
  return Cd || (Cd = 1, Gd = ({ workerPath: X, workerBlobURL: c }) => {
    let Z;
    if (Blob && URL && c) {
      const i = new Blob([`importScripts("${X}");`], {
        type: "application/javascript"
      });
      Z = new Worker(URL.createObjectURL(i));
    } else
      Z = new Worker(X);
    return Z;
  }), Gd;
}
var id, ed;
function Gl() {
  return ed || (ed = 1, id = (X) => {
    X.terminate();
  }), id;
}
var Wd, Pd;
function il() {
  return Pd || (Pd = 1, Wd = (X, c) => {
    X.onmessage = ({ data: Z }) => {
      c(Z);
    };
  }), Wd;
}
var pd, kd;
function Wl() {
  return kd || (kd = 1, pd = async (X, c) => {
    X.postMessage(c);
  }), pd;
}
var sd, gd;
function pl() {
  if (gd) return sd;
  gd = 1;
  const X = (Z) => new Promise((i, y) => {
    const s = new FileReader();
    s.onload = () => {
      i(s.result);
    }, s.onerror = ({ target: { error: { code: h } } }) => {
      y(Error(`File could not be read! Code=${h}`));
    }, s.readAsArrayBuffer(Z);
  }), c = async (Z) => {
    let i = Z;
    if (typeof Z > "u")
      return "undefined";
    if (typeof Z == "string")
      /data:image\/([a-zA-Z]*);base64,([^"]*)/.test(Z) ? i = atob(Z.split(",")[1]).split("").map((y) => y.charCodeAt(0)) : i = await (await fetch(Z)).arrayBuffer();
    else if (typeof HTMLElement < "u" && Z instanceof HTMLElement)
      Z.tagName === "IMG" && (i = await c(Z.src)), Z.tagName === "VIDEO" && (i = await c(Z.poster)), Z.tagName === "CANVAS" && await new Promise((y) => {
        Z.toBlob(async (s) => {
          i = await X(s), y();
        });
      });
    else if (typeof OffscreenCanvas < "u" && Z instanceof OffscreenCanvas) {
      const y = await Z.convertToBlob();
      i = await X(y);
    } else (Z instanceof File || Z instanceof Blob) && (i = await X(Z));
    return new Uint8Array(i);
  };
  return sd = c, sd;
}
var ud, wd;
function sl() {
  if (wd) return ud;
  wd = 1;
  const X = Xl(), c = yl(), Z = Gl(), i = il(), y = Wl(), s = pl();
  return ud = {
    defaultOptions: X,
    spawnWorker: c,
    terminateWorker: Z,
    onMessage: i,
    send: y,
    loadImage: s
  }, ud;
}
var hd, jd;
function Bd() {
  if (jd) return hd;
  jd = 1;
  const X = ml(), c = Qd(), { log: Z } = Vd(), i = Kd(), y = Dd(), {
    defaultOptions: s,
    spawnWorker: h,
    terminateWorker: M,
    onMessage: S,
    loadImage: C,
    send: e
  } = sl();
  let L = 0;
  return hd = async (R = "eng", P = y.LSTM_ONLY, F = {}, a = {}) => {
    const Y = i("Worker", L), {
      logger: j,
      errorHandler: V,
      ...K
    } = X({
      ...s,
      ...F
    }), T = {}, H = typeof R == "string" ? R.split("+") : R;
    let r = P, v = a;
    const U = [y.DEFAULT, y.LSTM_ONLY].includes(P) && !K.legacyCore;
    let k, D;
    const Q = new Promise((W, p) => {
      D = W, k = p;
    }), q = (W) => {
      k(W.message);
    };
    let g = h(K);
    g.onerror = q, L += 1;
    const x = ({ id: W, action: p, payload: I }) => new Promise((z, N) => {
      Z(`[${Y}]: Start ${W}, action=${p}`);
      const w = `${p}-${W}`;
      T[w] = { resolve: z, reject: N }, e(g, {
        workerId: Y,
        jobId: W,
        action: p,
        payload: I
      });
    }), B = () => console.warn("`load` is depreciated and should be removed from code (workers now come pre-loaded)"), O = (W) => x(c({
      id: W,
      action: "load",
      payload: { options: { lstmOnly: U, corePath: K.corePath, logging: K.logging } }
    })), E = (W, p, I) => x(c({
      id: I,
      action: "FS",
      payload: { method: "writeFile", args: [W, p] }
    })), A = (W, p) => x(c({
      id: p,
      action: "FS",
      payload: { method: "readFile", args: [W, { encoding: "utf8" }] }
    })), l = (W, p) => x(c({
      id: p,
      action: "FS",
      payload: { method: "unlink", args: [W] }
    })), d = (W, p, I) => x(c({
      id: I,
      action: "FS",
      payload: { method: W, args: p }
    })), m = (W, p) => x(c({
      id: p,
      action: "loadLanguage",
      payload: {
        langs: W,
        options: {
          langPath: K.langPath,
          dataPath: K.dataPath,
          cachePath: K.cachePath,
          cacheMethod: K.cacheMethod,
          gzip: K.gzip,
          lstmOnly: [y.DEFAULT, y.LSTM_ONLY].includes(r) && !K.legacyLang
        }
      }
    })), G = (W, p, I, z) => x(c({
      id: z,
      action: "initialize",
      payload: { langs: W, oem: p, config: I }
    })), b = (W = "eng", p, I, z) => {
      if (U && [y.TESSERACT_ONLY, y.TESSERACT_LSTM_COMBINED].includes(p)) throw Error("Legacy model requested but code missing.");
      const N = p || r;
      r = N;
      const w = I || v;
      v = w;
      const _ = (typeof W == "string" ? W.split("+") : W).filter((Od) => !H.includes(Od));
      return H.push(..._), _.length > 0 ? m(_, z).then(() => G(W, N, w, z)) : G(W, N, w, z);
    }, u = (W = {}, p) => x(c({
      id: p,
      action: "setParameters",
      payload: { params: W }
    })), o = async (W, p = {}, I = {
      text: !0
    }, z) => x(c({
      id: z,
      action: "recognize",
      payload: { image: await C(W), options: p, output: I }
    })), n = async (W, p) => {
      if (U) throw Error("`worker.detect` requires Legacy model, which was not loaded.");
      return x(c({
        id: p,
        action: "detect",
        payload: { image: await C(W) }
      }));
    }, J = async () => (g !== null && (M(g), g = null), Promise.resolve());
    S(g, ({
      workerId: W,
      jobId: p,
      status: I,
      action: z,
      data: N
    }) => {
      const w = `${z}-${p}`;
      if (I === "resolve")
        Z(`[${W}]: Complete ${p}`), T[w].resolve({ jobId: p, data: N }), delete T[w];
      else if (I === "reject")
        if (T[w].reject(N), delete T[w], z === "load" && k(N), V)
          V(N);
        else
          throw Error(N);
      else I === "progress" && j({ ...N, userJobId: p });
    });
    const t = {
      id: Y,
      worker: g,
      load: B,
      writeText: E,
      readText: A,
      removeFile: l,
      FS: d,
      reinitialize: b,
      setParameters: u,
      recognize: o,
      detect: n,
      terminate: J
    };
    return O().then(() => m(R)).then(() => G(R, P, a)).then(() => D(t)).catch(() => {
    }), Q;
  }, hd;
}
var Id, Ud;
function ul() {
  if (Ud) return Id;
  Ud = 1;
  const X = Bd();
  return Id = {
    recognize: async (i, y, s) => {
      const h = await X(y, 1, s);
      return h.recognize(i).finally(async () => {
        await h.terminate();
      });
    },
    detect: async (i, y) => {
      const s = await X("osd", 0, y);
      return s.detect(i).finally(async () => {
        await s.terminate();
      });
    }
  }, Id;
}
var ad, Fd;
function hl() {
  return Fd || (Fd = 1, ad = {
    AFR: "afr",
    AMH: "amh",
    ARA: "ara",
    ASM: "asm",
    AZE: "aze",
    AZE_CYRL: "aze_cyrl",
    BEL: "bel",
    BEN: "ben",
    BOD: "bod",
    BOS: "bos",
    BUL: "bul",
    CAT: "cat",
    CEB: "ceb",
    CES: "ces",
    CHI_SIM: "chi_sim",
    CHI_TRA: "chi_tra",
    CHR: "chr",
    CYM: "cym",
    DAN: "dan",
    DEU: "deu",
    DZO: "dzo",
    ELL: "ell",
    ENG: "eng",
    ENM: "enm",
    EPO: "epo",
    EST: "est",
    EUS: "eus",
    FAS: "fas",
    FIN: "fin",
    FRA: "fra",
    FRK: "frk",
    FRM: "frm",
    GLE: "gle",
    GLG: "glg",
    GRC: "grc",
    GUJ: "guj",
    HAT: "hat",
    HEB: "heb",
    HIN: "hin",
    HRV: "hrv",
    HUN: "hun",
    IKU: "iku",
    IND: "ind",
    ISL: "isl",
    ITA: "ita",
    ITA_OLD: "ita_old",
    JAV: "jav",
    JPN: "jpn",
    KAN: "kan",
    KAT: "kat",
    KAT_OLD: "kat_old",
    KAZ: "kaz",
    KHM: "khm",
    KIR: "kir",
    KOR: "kor",
    KUR: "kur",
    LAO: "lao",
    LAT: "lat",
    LAV: "lav",
    LIT: "lit",
    MAL: "mal",
    MAR: "mar",
    MKD: "mkd",
    MLT: "mlt",
    MSA: "msa",
    MYA: "mya",
    NEP: "nep",
    NLD: "nld",
    NOR: "nor",
    ORI: "ori",
    PAN: "pan",
    POL: "pol",
    POR: "por",
    PUS: "pus",
    RON: "ron",
    RUS: "rus",
    SAN: "san",
    SIN: "sin",
    SLK: "slk",
    SLV: "slv",
    SPA: "spa",
    SPA_OLD: "spa_old",
    SQI: "sqi",
    SRP: "srp",
    SRP_LATN: "srp_latn",
    SWA: "swa",
    SWE: "swe",
    SYR: "syr",
    TAM: "tam",
    TEL: "tel",
    TGK: "tgk",
    TGL: "tgl",
    THA: "tha",
    TIR: "tir",
    TUR: "tur",
    UIG: "uig",
    UKR: "ukr",
    URD: "urd",
    UZB: "uzb",
    UZB_CYRL: "uzb_cyrl",
    VIE: "vie",
    YID: "yid"
  }), ad;
}
var Ld, rd;
function Il() {
  return rd || (rd = 1, Ld = {
    OSD_ONLY: "0",
    AUTO_OSD: "1",
    AUTO_ONLY: "2",
    AUTO: "3",
    SINGLE_COLUMN: "4",
    SINGLE_BLOCK_VERT_TEXT: "5",
    SINGLE_BLOCK: "6",
    SINGLE_LINE: "7",
    SINGLE_WORD: "8",
    CIRCLE_WORD: "9",
    SINGLE_CHAR: "10",
    SPARSE_TEXT: "11",
    SPARSE_TEXT_OSD: "12",
    RAW_LINE: "13"
  }), Ld;
}
var Yd, vd;
function al() {
  if (vd) return Yd;
  vd = 1, _d();
  const X = $d(), c = Bd(), Z = ul(), i = hl(), y = Dd(), s = Il(), { setLogging: h } = Vd();
  return Yd = {
    languages: i,
    OEM: y,
    PSM: s,
    createScheduler: X,
    createWorker: c,
    setLogging: h,
    ...Z
  }, Yd;
}
var Ll = al();
const Yl = "data:text/javascript;base64,LyohIEZvciBsaWNlbnNlIGluZm9ybWF0aW9uIHBsZWFzZSBzZWUgd29ya2VyLm1pbi5qcy5MSUNFTlNFLnR4dCAqLwooKCk9Pnt2YXIgdD17MzA6KHQsZSxyKT0+e2Z1bmN0aW9uIG4odCl7cmV0dXJuIG49ImZ1bmN0aW9uIj09dHlwZW9mIFN5bWJvbCYmInN5bWJvbCI9PXR5cGVvZiBTeW1ib2wuaXRlcmF0b3I/ZnVuY3Rpb24odCl7cmV0dXJuIHR5cGVvZiB0fTpmdW5jdGlvbih0KXtyZXR1cm4gdCYmImZ1bmN0aW9uIj09dHlwZW9mIFN5bWJvbCYmdC5jb25zdHJ1Y3Rvcj09PVN5bWJvbCYmdCE9PVN5bWJvbC5wcm90b3R5cGU/InN5bWJvbCI6dHlwZW9mIHR9LG4odCl9dmFyIGk9ZnVuY3Rpb24odCl7InVzZSBzdHJpY3QiO3ZhciBlLHI9T2JqZWN0LnByb3RvdHlwZSxpPXIuaGFzT3duUHJvcGVydHksbz1PYmplY3QuZGVmaW5lUHJvcGVydHl8fGZ1bmN0aW9uKHQsZSxyKXt0W2VdPXIudmFsdWV9LGE9ImZ1bmN0aW9uIj09dHlwZW9mIFN5bWJvbD9TeW1ib2w6e30scz1hLml0ZXJhdG9yfHwiQEBpdGVyYXRvciIsdT1hLmFzeW5jSXRlcmF0b3J8fCJAQGFzeW5jSXRlcmF0b3IiLGg9YS50b1N0cmluZ1RhZ3x8IkBAdG9TdHJpbmdUYWciO2Z1bmN0aW9uIGYodCxlLHIpe3JldHVybiBPYmplY3QuZGVmaW5lUHJvcGVydHkodCxlLHt2YWx1ZTpyLGVudW1lcmFibGU6ITAsY29uZmlndXJhYmxlOiEwLHdyaXRhYmxlOiEwfSksdFtlXX10cnl7Zih7fSwiIil9Y2F0Y2godCl7Zj1mdW5jdGlvbih0LGUscil7cmV0dXJuIHRbZV09cn19ZnVuY3Rpb24gYyh0LGUscixuKXt2YXIgaT1lJiZlLnByb3RvdHlwZSBpbnN0YW5jZW9mIHY/ZTp2LGE9T2JqZWN0LmNyZWF0ZShpLnByb3RvdHlwZSkscz1uZXcgXyhufHxbXSk7cmV0dXJuIG8oYSwiX2ludm9rZSIse3ZhbHVlOlUodCxyLHMpfSksYX1mdW5jdGlvbiBsKHQsZSxyKXt0cnl7cmV0dXJue3R5cGU6Im5vcm1hbCIsYXJnOnQuY2FsbChlLHIpfX1jYXRjaCh0KXtyZXR1cm57dHlwZToidGhyb3ciLGFyZzp0fX19dC53cmFwPWM7dmFyIHA9InN1c3BlbmRlZFN0YXJ0Iix5PSJzdXNwZW5kZWRZaWVsZCIsZD0iZXhlY3V0aW5nIixnPSJjb21wbGV0ZWQiLGI9e307ZnVuY3Rpb24gdigpe31mdW5jdGlvbiB3KCl7fWZ1bmN0aW9uIG0oKXt9dmFyIEE9e307ZihBLHMsKGZ1bmN0aW9uKCl7cmV0dXJuIHRoaXN9KSk7dmFyIEU9T2JqZWN0LmdldFByb3RvdHlwZU9mLGs9RSYmRShFKGooW10pKSk7ayYmayE9PXImJmkuY2FsbChrLHMpJiYoQT1rKTt2YXIgeD1tLnByb3RvdHlwZT12LnByb3RvdHlwZT1PYmplY3QuY3JlYXRlKEEpO2Z1bmN0aW9uIE8odCl7WyJuZXh0IiwidGhyb3ciLCJyZXR1cm4iXS5mb3JFYWNoKChmdW5jdGlvbihlKXtmKHQsZSwoZnVuY3Rpb24odCl7cmV0dXJuIHRoaXMuX2ludm9rZShlLHQpfSkpfSkpfWZ1bmN0aW9uIEkodCxlKXtmdW5jdGlvbiByKG8sYSxzLHUpe3ZhciBoPWwodFtvXSx0LGEpO2lmKCJ0aHJvdyIhPT1oLnR5cGUpe3ZhciBmPWguYXJnLGM9Zi52YWx1ZTtyZXR1cm4gYyYmIm9iamVjdCI9PT1uKGMpJiZpLmNhbGwoYywiX19hd2FpdCIpP2UucmVzb2x2ZShjLl9fYXdhaXQpLnRoZW4oKGZ1bmN0aW9uKHQpe3IoIm5leHQiLHQscyx1KX0pLChmdW5jdGlvbih0KXtyKCJ0aHJvdyIsdCxzLHUpfSkpOmUucmVzb2x2ZShjKS50aGVuKChmdW5jdGlvbih0KXtmLnZhbHVlPXQscyhmKX0pLChmdW5jdGlvbih0KXtyZXR1cm4gcigidGhyb3ciLHQscyx1KX0pKX11KGguYXJnKX12YXIgYTtvKHRoaXMsIl9pbnZva2UiLHt2YWx1ZTpmdW5jdGlvbih0LG4pe2Z1bmN0aW9uIGkoKXtyZXR1cm4gbmV3IGUoKGZ1bmN0aW9uKGUsaSl7cih0LG4sZSxpKX0pKX1yZXR1cm4gYT1hP2EudGhlbihpLGkpOmkoKX19KX1mdW5jdGlvbiBVKHQsZSxyKXt2YXIgbj1wO3JldHVybiBmdW5jdGlvbihpLG8pe2lmKG49PT1kKXRocm93IG5ldyBFcnJvcigiR2VuZXJhdG9yIGlzIGFscmVhZHkgcnVubmluZyIpO2lmKG49PT1nKXtpZigidGhyb3ciPT09aSl0aHJvdyBvO3JldHVybiBQKCl9Zm9yKHIubWV0aG9kPWksci5hcmc9bzs7KXt2YXIgYT1yLmRlbGVnYXRlO2lmKGEpe3ZhciBzPVMoYSxyKTtpZihzKXtpZihzPT09Yiljb250aW51ZTtyZXR1cm4gc319aWYoIm5leHQiPT09ci5tZXRob2Qpci5zZW50PXIuX3NlbnQ9ci5hcmc7ZWxzZSBpZigidGhyb3ciPT09ci5tZXRob2Qpe2lmKG49PT1wKXRocm93IG49ZyxyLmFyZztyLmRpc3BhdGNoRXhjZXB0aW9uKHIuYXJnKX1lbHNlInJldHVybiI9PT1yLm1ldGhvZCYmci5hYnJ1cHQoInJldHVybiIsci5hcmcpO249ZDt2YXIgdT1sKHQsZSxyKTtpZigibm9ybWFsIj09PXUudHlwZSl7aWYobj1yLmRvbmU/Zzp5LHUuYXJnPT09Yiljb250aW51ZTtyZXR1cm57dmFsdWU6dS5hcmcsZG9uZTpyLmRvbmV9fSJ0aHJvdyI9PT11LnR5cGUmJihuPWcsci5tZXRob2Q9InRocm93IixyLmFyZz11LmFyZyl9fX1mdW5jdGlvbiBTKHQscil7dmFyIG49ci5tZXRob2QsaT10Lml0ZXJhdG9yW25dO2lmKGk9PT1lKXJldHVybiByLmRlbGVnYXRlPW51bGwsInRocm93Ij09PW4mJnQuaXRlcmF0b3IucmV0dXJuJiYoci5tZXRob2Q9InJldHVybiIsci5hcmc9ZSxTKHQsciksInRocm93Ij09PXIubWV0aG9kKXx8InJldHVybiIhPT1uJiYoci5tZXRob2Q9InRocm93IixyLmFyZz1uZXcgVHlwZUVycm9yKCJUaGUgaXRlcmF0b3IgZG9lcyBub3QgcHJvdmlkZSBhICciK24rIicgbWV0aG9kIikpLGI7dmFyIG89bChpLHQuaXRlcmF0b3Isci5hcmcpO2lmKCJ0aHJvdyI9PT1vLnR5cGUpcmV0dXJuIHIubWV0aG9kPSJ0aHJvdyIsci5hcmc9by5hcmcsci5kZWxlZ2F0ZT1udWxsLGI7dmFyIGE9by5hcmc7cmV0dXJuIGE/YS5kb25lPyhyW3QucmVzdWx0TmFtZV09YS52YWx1ZSxyLm5leHQ9dC5uZXh0TG9jLCJyZXR1cm4iIT09ci5tZXRob2QmJihyLm1ldGhvZD0ibmV4dCIsci5hcmc9ZSksci5kZWxlZ2F0ZT1udWxsLGIpOmE6KHIubWV0aG9kPSJ0aHJvdyIsci5hcmc9bmV3IFR5cGVFcnJvcigiaXRlcmF0b3IgcmVzdWx0IGlzIG5vdCBhbiBvYmplY3QiKSxyLmRlbGVnYXRlPW51bGwsYil9ZnVuY3Rpb24gTCh0KXt2YXIgZT17dHJ5TG9jOnRbMF19OzEgaW4gdCYmKGUuY2F0Y2hMb2M9dFsxXSksMiBpbiB0JiYoZS5maW5hbGx5TG9jPXRbMl0sZS5hZnRlckxvYz10WzNdKSx0aGlzLnRyeUVudHJpZXMucHVzaChlKX1mdW5jdGlvbiBCKHQpe3ZhciBlPXQuY29tcGxldGlvbnx8e307ZS50eXBlPSJub3JtYWwiLGRlbGV0ZSBlLmFyZyx0LmNvbXBsZXRpb249ZX1mdW5jdGlvbiBfKHQpe3RoaXMudHJ5RW50cmllcz1be3RyeUxvYzoicm9vdCJ9XSx0LmZvckVhY2goTCx0aGlzKSx0aGlzLnJlc2V0KCEwKX1mdW5jdGlvbiBqKHQpe2lmKHQpe3ZhciByPXRbc107aWYocilyZXR1cm4gci5jYWxsKHQpO2lmKCJmdW5jdGlvbiI9PXR5cGVvZiB0Lm5leHQpcmV0dXJuIHQ7aWYoIWlzTmFOKHQubGVuZ3RoKSl7dmFyIG49LTEsbz1mdW5jdGlvbiByKCl7Zm9yKDsrK248dC5sZW5ndGg7KWlmKGkuY2FsbCh0LG4pKXJldHVybiByLnZhbHVlPXRbbl0sci5kb25lPSExLHI7cmV0dXJuIHIudmFsdWU9ZSxyLmRvbmU9ITAscn07cmV0dXJuIG8ubmV4dD1vfX1yZXR1cm57bmV4dDpQfX1mdW5jdGlvbiBQKCl7cmV0dXJue3ZhbHVlOmUsZG9uZTohMH19cmV0dXJuIHcucHJvdG90eXBlPW0sbyh4LCJjb25zdHJ1Y3RvciIse3ZhbHVlOm0sY29uZmlndXJhYmxlOiEwfSksbyhtLCJjb25zdHJ1Y3RvciIse3ZhbHVlOncsY29uZmlndXJhYmxlOiEwfSksdy5kaXNwbGF5TmFtZT1mKG0saCwiR2VuZXJhdG9yRnVuY3Rpb24iKSx0LmlzR2VuZXJhdG9yRnVuY3Rpb249ZnVuY3Rpb24odCl7dmFyIGU9ImZ1bmN0aW9uIj09dHlwZW9mIHQmJnQuY29uc3RydWN0b3I7cmV0dXJuISFlJiYoZT09PXd8fCJHZW5lcmF0b3JGdW5jdGlvbiI9PT0oZS5kaXNwbGF5TmFtZXx8ZS5uYW1lKSl9LHQubWFyaz1mdW5jdGlvbih0KXtyZXR1cm4gT2JqZWN0LnNldFByb3RvdHlwZU9mP09iamVjdC5zZXRQcm90b3R5cGVPZih0LG0pOih0Ll9fcHJvdG9fXz1tLGYodCxoLCJHZW5lcmF0b3JGdW5jdGlvbiIpKSx0LnByb3RvdHlwZT1PYmplY3QuY3JlYXRlKHgpLHR9LHQuYXdyYXA9ZnVuY3Rpb24odCl7cmV0dXJue19fYXdhaXQ6dH19LE8oSS5wcm90b3R5cGUpLGYoSS5wcm90b3R5cGUsdSwoZnVuY3Rpb24oKXtyZXR1cm4gdGhpc30pKSx0LkFzeW5jSXRlcmF0b3I9SSx0LmFzeW5jPWZ1bmN0aW9uKGUscixuLGksbyl7dm9pZCAwPT09byYmKG89UHJvbWlzZSk7dmFyIGE9bmV3IEkoYyhlLHIsbixpKSxvKTtyZXR1cm4gdC5pc0dlbmVyYXRvckZ1bmN0aW9uKHIpP2E6YS5uZXh0KCkudGhlbigoZnVuY3Rpb24odCl7cmV0dXJuIHQuZG9uZT90LnZhbHVlOmEubmV4dCgpfSkpfSxPKHgpLGYoeCxoLCJHZW5lcmF0b3IiKSxmKHgscywoZnVuY3Rpb24oKXtyZXR1cm4gdGhpc30pKSxmKHgsInRvU3RyaW5nIiwoZnVuY3Rpb24oKXtyZXR1cm4iW29iamVjdCBHZW5lcmF0b3JdIn0pKSx0LmtleXM9ZnVuY3Rpb24odCl7dmFyIGU9T2JqZWN0KHQpLHI9W107Zm9yKHZhciBuIGluIGUpci5wdXNoKG4pO3JldHVybiByLnJldmVyc2UoKSxmdW5jdGlvbiB0KCl7Zm9yKDtyLmxlbmd0aDspe3ZhciBuPXIucG9wKCk7aWYobiBpbiBlKXJldHVybiB0LnZhbHVlPW4sdC5kb25lPSExLHR9cmV0dXJuIHQuZG9uZT0hMCx0fX0sdC52YWx1ZXM9aixfLnByb3RvdHlwZT17Y29uc3RydWN0b3I6XyxyZXNldDpmdW5jdGlvbih0KXtpZih0aGlzLnByZXY9MCx0aGlzLm5leHQ9MCx0aGlzLnNlbnQ9dGhpcy5fc2VudD1lLHRoaXMuZG9uZT0hMSx0aGlzLmRlbGVnYXRlPW51bGwsdGhpcy5tZXRob2Q9Im5leHQiLHRoaXMuYXJnPWUsdGhpcy50cnlFbnRyaWVzLmZvckVhY2goQiksIXQpZm9yKHZhciByIGluIHRoaXMpInQiPT09ci5jaGFyQXQoMCkmJmkuY2FsbCh0aGlzLHIpJiYhaXNOYU4oK3Iuc2xpY2UoMSkpJiYodGhpc1tyXT1lKX0sc3RvcDpmdW5jdGlvbigpe3RoaXMuZG9uZT0hMDt2YXIgdD10aGlzLnRyeUVudHJpZXNbMF0uY29tcGxldGlvbjtpZigidGhyb3ciPT09dC50eXBlKXRocm93IHQuYXJnO3JldHVybiB0aGlzLnJ2YWx9LGRpc3BhdGNoRXhjZXB0aW9uOmZ1bmN0aW9uKHQpe2lmKHRoaXMuZG9uZSl0aHJvdyB0O3ZhciByPXRoaXM7ZnVuY3Rpb24gbihuLGkpe3JldHVybiBzLnR5cGU9InRocm93IixzLmFyZz10LHIubmV4dD1uLGkmJihyLm1ldGhvZD0ibmV4dCIsci5hcmc9ZSksISFpfWZvcih2YXIgbz10aGlzLnRyeUVudHJpZXMubGVuZ3RoLTE7bz49MDstLW8pe3ZhciBhPXRoaXMudHJ5RW50cmllc1tvXSxzPWEuY29tcGxldGlvbjtpZigicm9vdCI9PT1hLnRyeUxvYylyZXR1cm4gbigiZW5kIik7aWYoYS50cnlMb2M8PXRoaXMucHJldil7dmFyIHU9aS5jYWxsKGEsImNhdGNoTG9jIiksaD1pLmNhbGwoYSwiZmluYWxseUxvYyIpO2lmKHUmJmgpe2lmKHRoaXMucHJldjxhLmNhdGNoTG9jKXJldHVybiBuKGEuY2F0Y2hMb2MsITApO2lmKHRoaXMucHJldjxhLmZpbmFsbHlMb2MpcmV0dXJuIG4oYS5maW5hbGx5TG9jKX1lbHNlIGlmKHUpe2lmKHRoaXMucHJldjxhLmNhdGNoTG9jKXJldHVybiBuKGEuY2F0Y2hMb2MsITApfWVsc2V7aWYoIWgpdGhyb3cgbmV3IEVycm9yKCJ0cnkgc3RhdGVtZW50IHdpdGhvdXQgY2F0Y2ggb3IgZmluYWxseSIpO2lmKHRoaXMucHJldjxhLmZpbmFsbHlMb2MpcmV0dXJuIG4oYS5maW5hbGx5TG9jKX19fX0sYWJydXB0OmZ1bmN0aW9uKHQsZSl7Zm9yKHZhciByPXRoaXMudHJ5RW50cmllcy5sZW5ndGgtMTtyPj0wOy0tcil7dmFyIG49dGhpcy50cnlFbnRyaWVzW3JdO2lmKG4udHJ5TG9jPD10aGlzLnByZXYmJmkuY2FsbChuLCJmaW5hbGx5TG9jIikmJnRoaXMucHJldjxuLmZpbmFsbHlMb2Mpe3ZhciBvPW47YnJlYWt9fW8mJigiYnJlYWsiPT09dHx8ImNvbnRpbnVlIj09PXQpJiZvLnRyeUxvYzw9ZSYmZTw9by5maW5hbGx5TG9jJiYobz1udWxsKTt2YXIgYT1vP28uY29tcGxldGlvbjp7fTtyZXR1cm4gYS50eXBlPXQsYS5hcmc9ZSxvPyh0aGlzLm1ldGhvZD0ibmV4dCIsdGhpcy5uZXh0PW8uZmluYWxseUxvYyxiKTp0aGlzLmNvbXBsZXRlKGEpfSxjb21wbGV0ZTpmdW5jdGlvbih0LGUpe2lmKCJ0aHJvdyI9PT10LnR5cGUpdGhyb3cgdC5hcmc7cmV0dXJuImJyZWFrIj09PXQudHlwZXx8ImNvbnRpbnVlIj09PXQudHlwZT90aGlzLm5leHQ9dC5hcmc6InJldHVybiI9PT10LnR5cGU/KHRoaXMucnZhbD10aGlzLmFyZz10LmFyZyx0aGlzLm1ldGhvZD0icmV0dXJuIix0aGlzLm5leHQ9ImVuZCIpOiJub3JtYWwiPT09dC50eXBlJiZlJiYodGhpcy5uZXh0PWUpLGJ9LGZpbmlzaDpmdW5jdGlvbih0KXtmb3IodmFyIGU9dGhpcy50cnlFbnRyaWVzLmxlbmd0aC0xO2U+PTA7LS1lKXt2YXIgcj10aGlzLnRyeUVudHJpZXNbZV07aWYoci5maW5hbGx5TG9jPT09dClyZXR1cm4gdGhpcy5jb21wbGV0ZShyLmNvbXBsZXRpb24sci5hZnRlckxvYyksQihyKSxifX0sY2F0Y2g6ZnVuY3Rpb24odCl7Zm9yKHZhciBlPXRoaXMudHJ5RW50cmllcy5sZW5ndGgtMTtlPj0wOy0tZSl7dmFyIHI9dGhpcy50cnlFbnRyaWVzW2VdO2lmKHIudHJ5TG9jPT09dCl7dmFyIG49ci5jb21wbGV0aW9uO2lmKCJ0aHJvdyI9PT1uLnR5cGUpe3ZhciBpPW4uYXJnO0Iocil9cmV0dXJuIGl9fXRocm93IG5ldyBFcnJvcigiaWxsZWdhbCBjYXRjaCBhdHRlbXB0Iil9LGRlbGVnYXRlWWllbGQ6ZnVuY3Rpb24odCxyLG4pe3JldHVybiB0aGlzLmRlbGVnYXRlPXtpdGVyYXRvcjpqKHQpLHJlc3VsdE5hbWU6cixuZXh0TG9jOm59LCJuZXh0Ij09PXRoaXMubWV0aG9kJiYodGhpcy5hcmc9ZSksYn19LHR9KCJvYmplY3QiPT09bih0PXIubm1kKHQpKT90LmV4cG9ydHM6e30pO3RyeXtyZWdlbmVyYXRvclJ1bnRpbWU9aX1jYXRjaCh0KXsib2JqZWN0Ij09PSgidW5kZWZpbmVkIj09dHlwZW9mIGdsb2JhbFRoaXM/InVuZGVmaW5lZCI6bihnbG9iYWxUaGlzKSk/Z2xvYmFsVGhpcy5yZWdlbmVyYXRvclJ1bnRpbWU9aTpGdW5jdGlvbigiciIsInJlZ2VuZXJhdG9yUnVudGltZSA9IHIiKShpKX19LDU0OnQ9PnsidXNlIHN0cmljdCI7dC5leHBvcnRzPXtDT0xPUjowLEdSRVk6MSxCSU5BUlk6Mn19LDY1OmZ1bmN0aW9uKHQsZSl7InVzZSBzdHJpY3QiO3ZhciByPXRoaXMsbj0hMTtlLmxvZ2dpbmc9bixlLnNldExvZ2dpbmc9ZnVuY3Rpb24odCl7bj10fSxlLmxvZz1mdW5jdGlvbigpe2Zvcih2YXIgdD1hcmd1bWVudHMubGVuZ3RoLGU9bmV3IEFycmF5KHQpLGk9MDtpPHQ7aSsrKWVbaV09YXJndW1lbnRzW2ldO3JldHVybiBuP2NvbnNvbGUubG9nLmFwcGx5KHIsZSk6bnVsbH19LDEzMzpmdW5jdGlvbih0LGUscil7dmFyIG49cig1NDUpLmhwOyhmdW5jdGlvbigpeyJ1c2Ugc3RyaWN0IjtmdW5jdGlvbiB0KHQpe3Rocm93IHR9dmFyIHI9dm9pZCAwLGk9ITAsbz0idW5kZWZpbmVkIiE9dHlwZW9mIFVpbnQ4QXJyYXkmJiJ1bmRlZmluZWQiIT10eXBlb2YgVWludDE2QXJyYXkmJiJ1bmRlZmluZWQiIT10eXBlb2YgVWludDMyQXJyYXkmJiJ1bmRlZmluZWQiIT10eXBlb2YgRGF0YVZpZXc7ZnVuY3Rpb24gYShlLHIpe3RoaXMuaW5kZXg9Im51bWJlciI9PXR5cGVvZiByP3I6MCx0aGlzLm09MCx0aGlzLmJ1ZmZlcj1lIGluc3RhbmNlb2Yobz9VaW50OEFycmF5OkFycmF5KT9lOm5ldyhvP1VpbnQ4QXJyYXk6QXJyYXkpKDMyNzY4KSwyKnRoaXMuYnVmZmVyLmxlbmd0aDw9dGhpcy5pbmRleCYmdChFcnJvcigiaW52YWxpZCBpbmRleCIpKSx0aGlzLmJ1ZmZlci5sZW5ndGg8PXRoaXMuaW5kZXgmJnRoaXMuZigpfWEucHJvdG90eXBlLmY9ZnVuY3Rpb24oKXt2YXIgdCxlPXRoaXMuYnVmZmVyLHI9ZS5sZW5ndGgsbj1uZXcobz9VaW50OEFycmF5OkFycmF5KShyPDwxKTtpZihvKW4uc2V0KGUpO2Vsc2UgZm9yKHQ9MDt0PHI7Kyt0KW5bdF09ZVt0XTtyZXR1cm4gdGhpcy5idWZmZXI9bn0sYS5wcm90b3R5cGUuZD1mdW5jdGlvbih0LGUscil7dmFyIG4saT10aGlzLmJ1ZmZlcixvPXRoaXMuaW5kZXgsYT10aGlzLm0scz1pW29dO2lmKHImJjE8ZSYmKHQ9ODxlPyhsWzI1NSZ0XTw8MjR8bFt0Pj4+OCYyNTVdPDwxNnxsW3Q+Pj4xNiYyNTVdPDw4fGxbdD4+PjI0JjI1NV0pPj4zMi1lOmxbdF0+PjgtZSksOD5lK2Epcz1zPDxlfHQsYSs9ZTtlbHNlIGZvcihuPTA7bjxlOysrbilzPXM8PDF8dD4+ZS1uLTEmMSw4PT0rK2EmJihhPTAsaVtvKytdPWxbc10scz0wLG89PT1pLmxlbmd0aCYmKGk9dGhpcy5mKCkpKTtpW29dPXMsdGhpcy5idWZmZXI9aSx0aGlzLm09YSx0aGlzLmluZGV4PW99LGEucHJvdG90eXBlLmZpbmlzaD1mdW5jdGlvbigpe3ZhciB0LGU9dGhpcy5idWZmZXIscj10aGlzLmluZGV4O3JldHVybiAwPHRoaXMubSYmKGVbcl08PD04LXRoaXMubSxlW3JdPWxbZVtyXV0scisrKSxvP3Q9ZS5zdWJhcnJheSgwLHIpOihlLmxlbmd0aD1yLHQ9ZSksdH07dmFyIHMsdT1uZXcobz9VaW50OEFycmF5OkFycmF5KSgyNTYpO2ZvcihzPTA7MjU2PnM7KytzKXtmb3IodmFyIGg9Yz1zLGY9NyxjPWM+Pj4xO2M7Yz4+Pj0xKWg8PD0xLGh8PTEmYywtLWY7dVtzXT0oaDw8ZiYyNTUpPj4+MH12YXIgbD11O2Z1bmN0aW9uIHAodCxlLHIpe3ZhciBuLGk9Im51bWJlciI9PXR5cGVvZiBlP2U6ZT0wLG89Im51bWJlciI9PXR5cGVvZiByP3I6dC5sZW5ndGg7Zm9yKG49LTEsaT03Jm87aS0tOysrZSluPW4+Pj44XmRbMjU1JihuXnRbZV0pXTtmb3IoaT1vPj4zO2ktLTtlKz04KW49KG49KG49KG49KG49KG49KG49KG49bj4+PjheZFsyNTUmKG5edFtlXSldKT4+PjheZFsyNTUmKG5edFtlKzFdKV0pPj4+OF5kWzI1NSYobl50W2UrMl0pXSk+Pj44XmRbMjU1JihuXnRbZSszXSldKT4+PjheZFsyNTUmKG5edFtlKzRdKV0pPj4+OF5kWzI1NSYobl50W2UrNV0pXSk+Pj44XmRbMjU1JihuXnRbZSs2XSldKT4+PjheZFsyNTUmKG5edFtlKzddKV07cmV0dXJuKDQyOTQ5NjcyOTVebik+Pj4wfXZhciB5PVswLDE5OTY5NTk4OTQsMzk5MzkxOTc4OCwyNTY3NTI0Nzk0LDEyNDYzNDEzNywxODg2MDU3NjE1LDM5MTU2MjE2ODUsMjY1NzM5MjAzNSwyNDkyNjgyNzQsMjA0NDUwODMyNCwzNzcyMTE1MjMwLDI1NDcxNzc4NjQsMTYyOTQxOTk1LDIxMjU1NjEwMjEsMzg4NzYwNzA0NywyNDI4NDQ0MDQ5LDQ5ODUzNjU0OCwxNzg5OTI3NjY2LDQwODkwMTY2NDgsMjIyNzA2MTIxNCw0NTA1NDg4NjEsMTg0MzI1ODYwMyw0MTA3NTgwNzUzLDIyMTE2Nzc2MzksMzI1ODgzOTkwLDE2ODQ3NzcxNTIsNDI1MTEyMjA0MiwyMzIxOTI2NjM2LDMzNTYzMzQ4NywxNjYxMzY1NDY1LDQxOTUzMDI3NTUsMjM2NjExNTMxNyw5OTcwNzMwOTYsMTI4MTk1Mzg4NiwzNTc5ODU1MzMyLDI3MjQ2ODgyNDIsMTAwNjg4ODE0NSwxMjU4NjA3Njg3LDM1MjQxMDE2MjksMjc2ODk0MjQ0Myw5MDEwOTc3MjIsMTExOTAwMDY4NCwzNjg2NTE3MjA2LDI4OTgwNjU3MjgsODUzMDQ0NDUxLDExNzIyNjYxMDEsMzcwNTAxNTc1OSwyODgyNjE2NjY1LDY1MTc2Nzk4MCwxMzczNTAzNTQ2LDMzNjk1NTQzMDQsMzIxODEwNDU5OCw1NjU1MDcyNTMsMTQ1NDYyMTczMSwzNDg1MTExNzA1LDMwOTk0MzYzMDMsNjcxMjY2OTc0LDE1OTQxOTgwMjQsMzMyMjczMDkzMCwyOTcwMzQ3ODEyLDc5NTgzNTUyNywxNDgzMjMwMjI1LDMyNDQzNjcyNzUsMzA2MDE0OTU2NSwxOTk0MTQ2MTkyLDMxMTU4NTM0LDI1NjM5MDc3NzIsNDAyMzcxNzkzMCwxOTA3NDU5NDY1LDExMjYzNzIxNSwyNjgwMTUzMjUzLDM5MDQ0MjcwNTksMjAxMzc3NjI5MCwyNTE3MjIwMzYsMjUxNzIxNTM3NCwzNzc1ODMwMDQwLDIxMzc2NTY3NjMsMTQxMzc2ODEzLDI0MzkyNzc3MTksMzg2NTI3MTI5NywxODAyMTk1NDQ0LDQ3Njg2NDg2NiwyMjM4MDAxMzY4LDQwNjY1MDg4NzgsMTgxMjM3MDkyNSw0NTMwOTI3MzEsMjE4MTYyNTAyNSw0MTExNDUxMjIzLDE3MDYwODg5MDIsMzE0MDQyNzA0LDIzNDQ1MzIyMDIsNDI0MDAxNzUzMiwxNjU4NjU4MjcxLDM2NjYxOTk3NywyMzYyNjcwMzIzLDQyMjQ5OTQ0MDUsMTMwMzUzNTk2MCw5ODQ5NjE0ODYsMjc0NzAwNzA5MiwzNTY5MDM3NTM4LDEyNTYxNzA4MTcsMTAzNzYwNDMxMSwyNzY1MjEwNzMzLDM1NTQwNzk5OTUsMTEzMTAxNDUwNiw4Nzk2Nzk5OTYsMjkwOTI0MzQ2MiwzNjYzNzcxODU2LDExNDExMjQ0NjcsODU1ODQyMjc3LDI4NTI4MDE2MzEsMzcwODY0ODY0OSwxMzQyNTMzOTQ4LDY1NDQ1OTMwNiwzMTg4Mzk2MDQ4LDMzNzMwMTUxNzQsMTQ2NjQ3OTkwOSw1NDQxNzk2MzUsMzExMDUyMzkxMywzNDYyNTIyMDE1LDE1OTE2NzEwNTQsNzAyMTM4Nzc2LDI5NjY0NjA0NTAsMzM1Mjc5OTQxMiwxNTA0OTE4ODA3LDc4MzU1MTg3MywzMDgyNjQwNDQzLDMyMzM0NDI5ODksMzk4ODI5MjM4NCwyNTk2MjU0NjQ2LDYyMzE3MDY4LDE5NTc4MTA4NDIsMzkzOTg0NTk0NSwyNjQ3ODE2MTExLDgxNDcwOTk3LDE5NDM4MDM1MjMsMzgxNDkxODkzMCwyNDg5NTk2ODA0LDIyNTI3NDQzMCwyMDUzNzkwMzc2LDM4MjYxNzU3NTUsMjQ2NjkwNjAxMywxNjc4MTY3NDMsMjA5NzY1MTM3Nyw0MDI3NTUyNTgwLDIyNjU0OTAzODYsNTAzNDQ0MDcyLDE3NjIwNTA4MTQsNDE1MDQxNzI0NSwyMTU0MTI5MzU1LDQyNjUyMjIyNSwxODUyNTA3ODc5LDQyNzUzMTM1MjYsMjMxMjMxNzkyMCwyODI3NTM2MjYsMTc0MjU1NTg1Miw0MTg5NzA4MTQzLDIzOTQ4Nzc5NDUsMzk3OTE3NzYzLDE2MjIxODM2MzcsMzYwNDM5MDg4OCwyNzE0ODY2NTU4LDk1MzcyOTczMiwxMzQwMDc2NjI2LDM1MTg3MTk5ODUsMjc5NzM2MDk5OSwxMDY4ODI4MzgxLDEyMTk2Mzg4NTksMzYyNDc0MTg1MCwyOTM2Njc1MTQ4LDkwNjE4NTQ2MiwxMDkwODEyNTEyLDM3NDc2NzIwMDMsMjgyNTM3OTY2OSw4MjkzMjkxMzUsMTE4MTMzNTE2MSwzNDEyMTc3ODA0LDMxNjA4MzQ4NDIsNjI4MDg1NDA4LDEzODI2MDUzNjYsMzQyMzM2OTEwOSwzMTM4MDc4NDY3LDU3MDU2MjIzMywxNDI2NDAwODE1LDMzMTczMTY1NDIsMjk5ODczMzYwOCw3MzMyMzk5NTQsMTU1NTI2MTk1NiwzMjY4OTM1NTkxLDMwNTAzNjA2MjUsNzUyNDU5NDAzLDE1NDEzMjAyMjEsMjYwNzA3MTkyMCwzOTY1OTczMDMwLDE5Njk5MjI5NzIsNDA3MzU0OTgsMjYxNzgzNzIyNSwzOTQzNTc3MTUxLDE5MTMwODc4NzcsODM5MDgzNzEsMjUxMjM0MTYzNCwzODAzNzQwNjkyLDIwNzUyMDg2MjIsMjEzMjYxMTEyLDI0NjMyNzI2MDMsMzg1NTk5MDI4NSwyMDk0ODU0MDcxLDE5ODk1ODg4MSwyMjYyMDI5MDEyLDQwNTcyNjA2MTAsMTc1OTM1OTk5Miw1MzQ0MTQxOTAsMjE3NjcxODU0MSw0MTM5MzI5MTE1LDE4NzM4MzYwMDEsNDE0NjY0NTY3LDIyODIyNDg5MzQsNDI3OTIwMDM2OCwxNzExNjg0NTU0LDI4NTI4MTExNiwyNDA1ODAxNzI3LDQxNjcyMTY3NDUsMTYzNDQ2Nzc5NSwzNzYyMjk3MDEsMjY4NTA2Nzg5NiwzNjA4MDA3NDA2LDEzMDg5MTg2MTIsOTU2NTQzOTM4LDI4MDg1NTUxMDUsMzQ5NTk1ODI2MywxMjMxNjM2MzAxLDEwNDc0MjcwMzUsMjkzMjk1OTgxOCwzNjU0NzAzODM2LDEwODgzNTkyNzAsOTM2OTE4ZTMsMjg0NzcxNDg5OSwzNzM2ODM3ODI5LDEyMDI5MDA4NjMsODE3MjMzODk3LDMxODMzNDIxMDgsMzQwMTIzNzEzMCwxNDA0Mjc3NTUyLDYxNTgxODE1MCwzMTM0MjA3NDkzLDM0NTM0MjEyMDMsMTQyMzg1NzQ0OSw2MDE0NTA0MzEsMzAwOTgzNzYxNCwzMjk0NzEwNDU2LDE1NjcxMDM3NDYsNzExOTI4NzI0LDMwMjA2Njg0NzEsMzI3MjM4MDA2NSwxNTEwMzM0MjM1LDc1NTE2NzExN10sZD1vP25ldyBVaW50MzJBcnJheSh5KTp5O2Z1bmN0aW9uIGcoKXt9ZnVuY3Rpb24gYih0KXt0aGlzLmJ1ZmZlcj1uZXcobz9VaW50MTZBcnJheTpBcnJheSkoMip0KSx0aGlzLmxlbmd0aD0wfWZ1bmN0aW9uIHYodCl7dmFyIGUscixuLGksYSxzLHUsaCxmLGMsbD10Lmxlbmd0aCxwPTAseT1OdW1iZXIuUE9TSVRJVkVfSU5GSU5JVFk7Zm9yKGg9MDtoPGw7KytoKXRbaF0+cCYmKHA9dFtoXSksdFtoXTx5JiYoeT10W2hdKTtmb3IoZT0xPDxwLHI9bmV3KG8/VWludDMyQXJyYXk6QXJyYXkpKGUpLG49MSxpPTAsYT0yO248PXA7KXtmb3IoaD0wO2g8bDsrK2gpaWYodFtoXT09PW4pe2ZvcihzPTAsdT1pLGY9MDtmPG47KytmKXM9czw8MXwxJnUsdT4+PTE7Zm9yKGM9bjw8MTZ8aCxmPXM7ZjxlO2YrPWEpcltmXT1jOysraX0rK24saTw8PTEsYTw8PTF9cmV0dXJuW3IscCx5XX1mdW5jdGlvbiB3KHQsZSl7dGhpcy5rPUEsdGhpcy5GPTAsdGhpcy5pbnB1dD1vJiZ0IGluc3RhbmNlb2YgQXJyYXk/bmV3IFVpbnQ4QXJyYXkodCk6dCx0aGlzLmI9MCxlJiYoZS5sYXp5JiYodGhpcy5GPWUubGF6eSksIm51bWJlciI9PXR5cGVvZiBlLmNvbXByZXNzaW9uVHlwZSYmKHRoaXMuaz1lLmNvbXByZXNzaW9uVHlwZSksZS5vdXRwdXRCdWZmZXImJih0aGlzLmE9byYmZS5vdXRwdXRCdWZmZXIgaW5zdGFuY2VvZiBBcnJheT9uZXcgVWludDhBcnJheShlLm91dHB1dEJ1ZmZlcik6ZS5vdXRwdXRCdWZmZXIpLCJudW1iZXIiPT10eXBlb2YgZS5vdXRwdXRJbmRleCYmKHRoaXMuYj1lLm91dHB1dEluZGV4KSksdGhpcy5hfHwodGhpcy5hPW5ldyhvP1VpbnQ4QXJyYXk6QXJyYXkpKDMyNzY4KSl9Yi5wcm90b3R5cGUuZ2V0UGFyZW50PWZ1bmN0aW9uKHQpe3JldHVybiAyKigodC0yKS80fDApfSxiLnByb3RvdHlwZS5wdXNoPWZ1bmN0aW9uKHQsZSl7dmFyIHIsbixpLG89dGhpcy5idWZmZXI7Zm9yKHI9dGhpcy5sZW5ndGgsb1t0aGlzLmxlbmd0aCsrXT1lLG9bdGhpcy5sZW5ndGgrK109dDswPHImJihuPXRoaXMuZ2V0UGFyZW50KHIpLG9bcl0+b1tuXSk7KWk9b1tyXSxvW3JdPW9bbl0sb1tuXT1pLGk9b1tyKzFdLG9bcisxXT1vW24rMV0sb1tuKzFdPWkscj1uO3JldHVybiB0aGlzLmxlbmd0aH0sYi5wcm90b3R5cGUucG9wPWZ1bmN0aW9uKCl7dmFyIHQsZSxyLG4saSxvPXRoaXMuYnVmZmVyO2ZvcihlPW9bMF0sdD1vWzFdLHRoaXMubGVuZ3RoLT0yLG9bMF09b1t0aGlzLmxlbmd0aF0sb1sxXT1vW3RoaXMubGVuZ3RoKzFdLGk9MDshKChuPTIqaSsyKT49dGhpcy5sZW5ndGgpJiYobisyPHRoaXMubGVuZ3RoJiZvW24rMl0+b1tuXSYmKG4rPTIpLG9bbl0+b1tpXSk7KXI9b1tpXSxvW2ldPW9bbl0sb1tuXT1yLHI9b1tpKzFdLG9baSsxXT1vW24rMV0sb1tuKzFdPXIsaT1uO3JldHVybntpbmRleDp0LHZhbHVlOmUsbGVuZ3RoOnRoaXMubGVuZ3RofX07dmFyIG0sQT0yLEU9e05PTkU6MCxMOjEsdDpBLFg6M30saz1bXTtmb3IobT0wOzI4OD5tO20rKylzd2l0Y2goaSl7Y2FzZSAxNDM+PW06ay5wdXNoKFttKzQ4LDhdKTticmVhaztjYXNlIDI1NT49bTprLnB1c2goW20tMTQ0KzQwMCw5XSk7YnJlYWs7Y2FzZSAyNzk+PW06ay5wdXNoKFttLTI1NiswLDddKTticmVhaztjYXNlIDI4Nz49bTprLnB1c2goW20tMjgwKzE5Miw4XSk7YnJlYWs7ZGVmYXVsdDp0KCJpbnZhbGlkIGxpdGVyYWw6ICIrbSl9ZnVuY3Rpb24geCh0LGUpe3RoaXMubGVuZ3RoPXQsdGhpcy5OPWV9dy5wcm90b3R5cGUuaD1mdW5jdGlvbigpe3ZhciBlLG4scyx1LGg9dGhpcy5pbnB1dDtzd2l0Y2godGhpcy5rKXtjYXNlIDA6Zm9yKHM9MCx1PWgubGVuZ3RoO3M8dTspe3ZhciBmLGMsbCxwPW49bz9oLnN1YmFycmF5KHMscys2NTUzNSk6aC5zbGljZShzLHMrNjU1MzUpLHk9KHMrPW4ubGVuZ3RoKT09PXUsZD1yLGc9cixiPXRoaXMuYSx2PXRoaXMuYjtpZihvKXtmb3IoYj1uZXcgVWludDhBcnJheSh0aGlzLmEuYnVmZmVyKTtiLmxlbmd0aDw9ditwLmxlbmd0aCs1OyliPW5ldyBVaW50OEFycmF5KGIubGVuZ3RoPDwxKTtiLnNldCh0aGlzLmEpfWlmKGY9eT8xOjAsYlt2KytdPTB8ZixsPTY1NTM2K34oYz1wLmxlbmd0aCkmNjU1MzUsYlt2KytdPTI1NSZjLGJbdisrXT1jPj4+OCYyNTUsYlt2KytdPTI1NSZsLGJbdisrXT1sPj4+OCYyNTUsbyliLnNldChwLHYpLHYrPXAubGVuZ3RoLGI9Yi5zdWJhcnJheSgwLHYpO2Vsc2V7Zm9yKGQ9MCxnPXAubGVuZ3RoO2Q8ZzsrK2QpYlt2KytdPXBbZF07Yi5sZW5ndGg9dn10aGlzLmI9dix0aGlzLmE9Yn1icmVhaztjYXNlIDE6dmFyIHc9bmV3IGEobz9uZXcgVWludDhBcnJheSh0aGlzLmEuYnVmZmVyKTp0aGlzLmEsdGhpcy5iKTt3LmQoMSwxLGkpLHcuZCgxLDIsaSk7dmFyIG0sRSx4LE89VSh0aGlzLGgpO2ZvcihtPTAsRT1PLmxlbmd0aDttPEU7bSsrKWlmKHg9T1ttXSxhLnByb3RvdHlwZS5kLmFwcGx5KHcsa1t4XSksMjU2PHgpdy5kKE9bKyttXSxPWysrbV0saSksdy5kKE9bKyttXSw1KSx3LmQoT1srK21dLE9bKyttXSxpKTtlbHNlIGlmKDI1Nj09PXgpYnJlYWs7dGhpcy5hPXcuZmluaXNoKCksdGhpcy5iPXRoaXMuYS5sZW5ndGg7YnJlYWs7Y2FzZSBBOnZhciBJLFMsXyxqLFAsVCxSLEMsTSxOLEYsRyx6LEQsVyxZPW5ldyBhKG8/bmV3IFVpbnQ4QXJyYXkodGhpcy5hLmJ1ZmZlcik6dGhpcy5hLHRoaXMuYiksVj1bMTYsMTcsMTgsMCw4LDcsOSw2LDEwLDUsMTEsNCwxMiwzLDEzLDIsMTQsMSwxNV0scT1BcnJheSgxOSk7Zm9yKEk9QSxZLmQoMSwxLGkpLFkuZChJLDIsaSksUz1VKHRoaXMsaCksUj1CKFQ9TCh0aGlzLlUsMTUpKSxNPUIoQz1MKHRoaXMuVCw3KSksXz0yODY7MjU3PF8mJjA9PT1UW18tMV07Xy0tKTtmb3Ioaj0zMDsxPGomJjA9PT1DW2otMV07ai0tKTt2YXIgSixRLFgsSCxLLCQsWj1fLHR0PWosZXQ9bmV3KG8/VWludDMyQXJyYXk6QXJyYXkpKFordHQpLHJ0PW5ldyhvP1VpbnQzMkFycmF5OkFycmF5KSgzMTYpLG50PW5ldyhvP1VpbnQ4QXJyYXk6QXJyYXkpKDE5KTtmb3IoSj1RPTA7SjxaO0orKylldFtRKytdPVRbSl07Zm9yKEo9MDtKPHR0O0orKylldFtRKytdPUNbSl07aWYoIW8pZm9yKEo9MCxIPW50Lmxlbmd0aDtKPEg7KytKKW50W0pdPTA7Zm9yKEo9Sz0wLEg9ZXQubGVuZ3RoO0o8SDtKKz1RKXtmb3IoUT0xO0orUTxIJiZldFtKK1FdPT09ZXRbSl07KytRKTtpZihYPVEsMD09PWV0W0pdKWlmKDM+WClmb3IoOzA8WC0tOylydFtLKytdPTAsbnRbMF0rKztlbHNlIGZvcig7MDxYOykoJD0xMzg+WD9YOjEzOCk+WC0zJiYkPFgmJigkPVgtMyksMTA+PSQ/KHJ0W0srK109MTcscnRbSysrXT0kLTMsbnRbMTddKyspOihydFtLKytdPTE4LHJ0W0srK109JC0xMSxudFsxOF0rKyksWC09JDtlbHNlIGlmKHJ0W0srK109ZXRbSl0sbnRbZXRbSl1dKyssMz4tLVgpZm9yKDswPFgtLTspcnRbSysrXT1ldFtKXSxudFtldFtKXV0rKztlbHNlIGZvcig7MDxYOykoJD02Plg/WDo2KT5YLTMmJiQ8WCYmKCQ9WC0zKSxydFtLKytdPTE2LHJ0W0srK109JC0zLG50WzE2XSsrLFgtPSR9Zm9yKGU9bz9ydC5zdWJhcnJheSgwLEspOnJ0LnNsaWNlKDAsSyksTj1MKG50LDcpLEQ9MDsxOT5EO0QrKylxW0RdPU5bVltEXV07Zm9yKFA9MTk7NDxQJiYwPT09cVtQLTFdO1AtLSk7Zm9yKEY9QihOKSxZLmQoXy0yNTcsNSxpKSxZLmQoai0xLDUsaSksWS5kKFAtNCw0LGkpLEQ9MDtEPFA7RCsrKVkuZChxW0RdLDMsaSk7Zm9yKEQ9MCxXPWUubGVuZ3RoO0Q8VztEKyspaWYoRz1lW0RdLFkuZChGW0ddLE5bR10saSksMTY8PUcpe3N3aXRjaChEKyssRyl7Y2FzZSAxNjp6PTI7YnJlYWs7Y2FzZSAxNzp6PTM7YnJlYWs7Y2FzZSAxODp6PTc7YnJlYWs7ZGVmYXVsdDp0KCJpbnZhbGlkIGNvZGU6ICIrRyl9WS5kKGVbRF0seixpKX12YXIgaXQsb3QsYXQsc3QsdXQsaHQsZnQsY3QsbHQ9W1IsVF0scHQ9W00sQ107Zm9yKHV0PWx0WzBdLGh0PWx0WzFdLGZ0PXB0WzBdLGN0PXB0WzFdLGl0PTAsb3Q9Uy5sZW5ndGg7aXQ8b3Q7KytpdClpZihhdD1TW2l0XSxZLmQodXRbYXRdLGh0W2F0XSxpKSwyNTY8YXQpWS5kKFNbKytpdF0sU1srK2l0XSxpKSxzdD1TWysraXRdLFkuZChmdFtzdF0sY3Rbc3RdLGkpLFkuZChTWysraXRdLFNbKytpdF0saSk7ZWxzZSBpZigyNTY9PT1hdClicmVhazt0aGlzLmE9WS5maW5pc2goKSx0aGlzLmI9dGhpcy5hLmxlbmd0aDticmVhaztkZWZhdWx0OnQoImludmFsaWQgY29tcHJlc3Npb24gdHlwZSIpfXJldHVybiB0aGlzLmF9O3ZhciBPPWZ1bmN0aW9uKCl7ZnVuY3Rpb24gZShlKXtzd2l0Y2goaSl7Y2FzZSAzPT09ZTpyZXR1cm5bMjU3LGUtMywwXTtjYXNlIDQ9PT1lOnJldHVyblsyNTgsZS00LDBdO2Nhc2UgNT09PWU6cmV0dXJuWzI1OSxlLTUsMF07Y2FzZSA2PT09ZTpyZXR1cm5bMjYwLGUtNiwwXTtjYXNlIDc9PT1lOnJldHVyblsyNjEsZS03LDBdO2Nhc2UgOD09PWU6cmV0dXJuWzI2MixlLTgsMF07Y2FzZSA5PT09ZTpyZXR1cm5bMjYzLGUtOSwwXTtjYXNlIDEwPT09ZTpyZXR1cm5bMjY0LGUtMTAsMF07Y2FzZSAxMj49ZTpyZXR1cm5bMjY1LGUtMTEsMV07Y2FzZSAxND49ZTpyZXR1cm5bMjY2LGUtMTMsMV07Y2FzZSAxNj49ZTpyZXR1cm5bMjY3LGUtMTUsMV07Y2FzZSAxOD49ZTpyZXR1cm5bMjY4LGUtMTcsMV07Y2FzZSAyMj49ZTpyZXR1cm5bMjY5LGUtMTksMl07Y2FzZSAyNj49ZTpyZXR1cm5bMjcwLGUtMjMsMl07Y2FzZSAzMD49ZTpyZXR1cm5bMjcxLGUtMjcsMl07Y2FzZSAzND49ZTpyZXR1cm5bMjcyLGUtMzEsMl07Y2FzZSA0Mj49ZTpyZXR1cm5bMjczLGUtMzUsM107Y2FzZSA1MD49ZTpyZXR1cm5bMjc0LGUtNDMsM107Y2FzZSA1OD49ZTpyZXR1cm5bMjc1LGUtNTEsM107Y2FzZSA2Nj49ZTpyZXR1cm5bMjc2LGUtNTksM107Y2FzZSA4Mj49ZTpyZXR1cm5bMjc3LGUtNjcsNF07Y2FzZSA5OD49ZTpyZXR1cm5bMjc4LGUtODMsNF07Y2FzZSAxMTQ+PWU6cmV0dXJuWzI3OSxlLTk5LDRdO2Nhc2UgMTMwPj1lOnJldHVyblsyODAsZS0xMTUsNF07Y2FzZSAxNjI+PWU6cmV0dXJuWzI4MSxlLTEzMSw1XTtjYXNlIDE5ND49ZTpyZXR1cm5bMjgyLGUtMTYzLDVdO2Nhc2UgMjI2Pj1lOnJldHVyblsyODMsZS0xOTUsNV07Y2FzZSAyNTc+PWU6cmV0dXJuWzI4NCxlLTIyNyw1XTtjYXNlIDI1OD09PWU6cmV0dXJuWzI4NSxlLTI1OCwwXTtkZWZhdWx0OnQoImludmFsaWQgbGVuZ3RoOiAiK2UpfX12YXIgcixuLG89W107Zm9yKHI9MzsyNTg+PXI7cisrKW49ZShyKSxvW3JdPW5bMl08PDI0fG5bMV08PDE2fG5bMF07cmV0dXJuIG99KCksST1vP25ldyBVaW50MzJBcnJheShPKTpPO2Z1bmN0aW9uIFUoZSxuKXtmdW5jdGlvbiBhKGUscil7dmFyIG4sbyxhLHMsdT1lLk4saD1bXSxmPTA7c3dpdGNoKG49SVtlLmxlbmd0aF0saFtmKytdPTY1NTM1Jm4saFtmKytdPW4+PjE2JjI1NSxoW2YrK109bj4+MjQsaSl7Y2FzZSAxPT09dTpvPVswLHUtMSwwXTticmVhaztjYXNlIDI9PT11Om89WzEsdS0yLDBdO2JyZWFrO2Nhc2UgMz09PXU6bz1bMix1LTMsMF07YnJlYWs7Y2FzZSA0PT09dTpvPVszLHUtNCwwXTticmVhaztjYXNlIDY+PXU6bz1bNCx1LTUsMV07YnJlYWs7Y2FzZSA4Pj11Om89WzUsdS03LDFdO2JyZWFrO2Nhc2UgMTI+PXU6bz1bNix1LTksMl07YnJlYWs7Y2FzZSAxNj49dTpvPVs3LHUtMTMsMl07YnJlYWs7Y2FzZSAyND49dTpvPVs4LHUtMTcsM107YnJlYWs7Y2FzZSAzMj49dTpvPVs5LHUtMjUsM107YnJlYWs7Y2FzZSA0OD49dTpvPVsxMCx1LTMzLDRdO2JyZWFrO2Nhc2UgNjQ+PXU6bz1bMTEsdS00OSw0XTticmVhaztjYXNlIDk2Pj11Om89WzEyLHUtNjUsNV07YnJlYWs7Y2FzZSAxMjg+PXU6bz1bMTMsdS05Nyw1XTticmVhaztjYXNlIDE5Mj49dTpvPVsxNCx1LTEyOSw2XTticmVhaztjYXNlIDI1Nj49dTpvPVsxNSx1LTE5Myw2XTticmVhaztjYXNlIDM4ND49dTpvPVsxNix1LTI1Nyw3XTticmVhaztjYXNlIDUxMj49dTpvPVsxNyx1LTM4NSw3XTticmVhaztjYXNlIDc2OD49dTpvPVsxOCx1LTUxMyw4XTticmVhaztjYXNlIDEwMjQ+PXU6bz1bMTksdS03NjksOF07YnJlYWs7Y2FzZSAxNTM2Pj11Om89WzIwLHUtMTAyNSw5XTticmVhaztjYXNlIDIwNDg+PXU6bz1bMjEsdS0xNTM3LDldO2JyZWFrO2Nhc2UgMzA3Mj49dTpvPVsyMix1LTIwNDksMTBdO2JyZWFrO2Nhc2UgNDA5Nj49dTpvPVsyMyx1LTMwNzMsMTBdO2JyZWFrO2Nhc2UgNjE0ND49dTpvPVsyNCx1LTQwOTcsMTFdO2JyZWFrO2Nhc2UgODE5Mj49dTpvPVsyNSx1LTYxNDUsMTFdO2JyZWFrO2Nhc2UgMTIyODg+PXU6bz1bMjYsdS04MTkzLDEyXTticmVhaztjYXNlIDE2Mzg0Pj11Om89WzI3LHUtMTIyODksMTJdO2JyZWFrO2Nhc2UgMjQ1NzY+PXU6bz1bMjgsdS0xNjM4NSwxM107YnJlYWs7Y2FzZSAzMjc2OD49dTpvPVsyOSx1LTI0NTc3LDEzXTticmVhaztkZWZhdWx0OnQoImludmFsaWQgZGlzdGFuY2UiKX1mb3Iobj1vLGhbZisrXT1uWzBdLGhbZisrXT1uWzFdLGhbZisrXT1uWzJdLGE9MCxzPWgubGVuZ3RoO2E8czsrK2EpYlt2KytdPWhbYV07bVtoWzBdXSsrLEFbaFszXV0rKyx3PWUubGVuZ3RoK3ItMSx5PW51bGx9dmFyIHMsdSxoLGYsYyxsLHAseSxkLGc9e30sYj1vP25ldyBVaW50MTZBcnJheSgyKm4ubGVuZ3RoKTpbXSx2PTAsdz0wLG09bmV3KG8/VWludDMyQXJyYXk6QXJyYXkpKDI4NiksQT1uZXcobz9VaW50MzJBcnJheTpBcnJheSkoMzApLEU9ZS5GO2lmKCFvKXtmb3IoaD0wOzI4NT49aDspbVtoKytdPTA7Zm9yKGg9MDsyOT49aDspQVtoKytdPTB9Zm9yKG1bMjU2XT0xLHM9MCx1PW4ubGVuZ3RoO3M8dTsrK3Mpe2ZvcihoPWM9MCxmPTM7aDxmJiZzK2ghPT11OysraCljPWM8PDh8bltzK2hdO2lmKGdbY109PT1yJiYoZ1tjXT1bXSksbD1nW2NdLCEoMDx3LS0pKXtmb3IoOzA8bC5sZW5ndGgmJjMyNzY4PHMtbFswXTspbC5zaGlmdCgpO2lmKHMrMz49dSl7Zm9yKHkmJmEoeSwtMSksaD0wLGY9dS1zO2g8ZjsrK2gpZD1uW3MraF0sYlt2KytdPWQsKyttW2RdO2JyZWFrfTA8bC5sZW5ndGg/KHA9UyhuLHMsbCkseT95Lmxlbmd0aDxwLmxlbmd0aD8oZD1uW3MtMV0sYlt2KytdPWQsKyttW2RdLGEocCwwKSk6YSh5LC0xKTpwLmxlbmd0aDxFP3k9cDphKHAsMCkpOnk/YSh5LC0xKTooZD1uW3NdLGJbdisrXT1kLCsrbVtkXSl9bC5wdXNoKHMpfXJldHVybiBiW3YrK109MjU2LG1bMjU2XSsrLGUuVT1tLGUuVD1BLG8/Yi5zdWJhcnJheSgwLHYpOmJ9ZnVuY3Rpb24gUyh0LGUscil7dmFyIG4saSxvLGEscyx1LGg9MCxmPXQubGVuZ3RoO2E9MCx1PXIubGVuZ3RoO3Q6Zm9yKDthPHU7YSsrKXtpZihuPXJbdS1hLTFdLG89MywzPGgpe2ZvcihzPWg7MzxzO3MtLSlpZih0W24rcy0xXSE9PXRbZStzLTFdKWNvbnRpbnVlIHQ7bz1ofWZvcig7MjU4Pm8mJmUrbzxmJiZ0W24rb109PT10W2Urb107KSsrbztpZihvPmgmJihpPW4saD1vKSwyNTg9PT1vKWJyZWFrfXJldHVybiBuZXcgeChoLGUtaSl9ZnVuY3Rpb24gTCh0LGUpe3ZhciByLG4saSxhLHMsdT10Lmxlbmd0aCxoPW5ldyBiKDU3MiksZj1uZXcobz9VaW50OEFycmF5OkFycmF5KSh1KTtpZighbylmb3IoYT0wO2E8dTthKyspZlthXT0wO2ZvcihhPTA7YTx1OysrYSkwPHRbYV0mJmgucHVzaChhLHRbYV0pO2lmKHI9QXJyYXkoaC5sZW5ndGgvMiksbj1uZXcobz9VaW50MzJBcnJheTpBcnJheSkoaC5sZW5ndGgvMiksMT09PXIubGVuZ3RoKXJldHVybiBmW2gucG9wKCkuaW5kZXhdPTEsZjtmb3IoYT0wLHM9aC5sZW5ndGgvMjthPHM7KythKXJbYV09aC5wb3AoKSxuW2FdPXJbYV0udmFsdWU7Zm9yKGk9ZnVuY3Rpb24odCxlLHIpe2Z1bmN0aW9uIG4odCl7dmFyIHI9eVt0XVtkW3RdXTtyPT09ZT8obih0KzEpLG4odCsxKSk6LS1sW3JdLCsrZFt0XX12YXIgaSxhLHMsdSxoLGY9bmV3KG8/VWludDE2QXJyYXk6QXJyYXkpKHIpLGM9bmV3KG8/VWludDhBcnJheTpBcnJheSkociksbD1uZXcobz9VaW50OEFycmF5OkFycmF5KShlKSxwPUFycmF5KHIpLHk9QXJyYXkociksZD1BcnJheShyKSxnPSgxPDxyKS1lLGI9MTw8ci0xO2ZvcihmW3ItMV09ZSxhPTA7YTxyOysrYSlnPGI/Y1thXT0wOihjW2FdPTEsZy09YiksZzw8PTEsZltyLTItYV09KGZbci0xLWFdLzJ8MCkrZTtmb3IoZlswXT1jWzBdLHBbMF09QXJyYXkoZlswXSkseVswXT1BcnJheShmWzBdKSxhPTE7YTxyOysrYSlmW2FdPjIqZlthLTFdK2NbYV0mJihmW2FdPTIqZlthLTFdK2NbYV0pLHBbYV09QXJyYXkoZlthXSkseVthXT1BcnJheShmW2FdKTtmb3IoaT0wO2k8ZTsrK2kpbFtpXT1yO2ZvcihzPTA7czxmW3ItMV07KytzKXBbci0xXVtzXT10W3NdLHlbci0xXVtzXT1zO2ZvcihpPTA7aTxyOysraSlkW2ldPTA7Zm9yKDE9PT1jW3ItMV0mJigtLWxbMF0sKytkW3ItMV0pLGE9ci0yOzA8PWE7LS1hKXtmb3IodT1pPTAsaD1kW2ErMV0scz0wO3M8ZlthXTtzKyspKHU9cFthKzFdW2hdK3BbYSsxXVtoKzFdKT50W2ldPyhwW2FdW3NdPXUseVthXVtzXT1lLGgrPTIpOihwW2FdW3NdPXRbaV0seVthXVtzXT1pLCsraSk7ZFthXT0wLDE9PT1jW2FdJiZuKGEpfXJldHVybiBsfShuLG4ubGVuZ3RoLGUpLGE9MCxzPXIubGVuZ3RoO2E8czsrK2EpZltyW2FdLmluZGV4XT1pW2FdO3JldHVybiBmfWZ1bmN0aW9uIEIodCl7dmFyIGUscixuLGksYT1uZXcobz9VaW50MTZBcnJheTpBcnJheSkodC5sZW5ndGgpLHM9W10sdT1bXSxoPTA7Zm9yKGU9MCxyPXQubGVuZ3RoO2U8cjtlKyspc1t0W2VdXT0xKygwfHNbdFtlXV0pO2ZvcihlPTEscj0xNjtlPD1yO2UrKyl1W2VdPWgsaCs9MHxzW2VdLGg8PD0xO2ZvcihlPTAscj10Lmxlbmd0aDtlPHI7ZSsrKWZvcihoPXVbdFtlXV0sdVt0W2VdXSs9MSxuPWFbZV09MCxpPXRbZV07bjxpO24rKylhW2VdPWFbZV08PDF8MSZoLGg+Pj49MTtyZXR1cm4gYX1mdW5jdGlvbiBfKHQsZSl7dGhpcy5pbnB1dD10LHRoaXMuYj10aGlzLmM9MCx0aGlzLmc9e30sZSYmKGUuZmxhZ3MmJih0aGlzLmc9ZS5mbGFncyksInN0cmluZyI9PXR5cGVvZiBlLmZpbGVuYW1lJiYodGhpcy5maWxlbmFtZT1lLmZpbGVuYW1lKSwic3RyaW5nIj09dHlwZW9mIGUuY29tbWVudCYmKHRoaXMudz1lLmNvbW1lbnQpLGUuZGVmbGF0ZU9wdGlvbnMmJih0aGlzLmw9ZS5kZWZsYXRlT3B0aW9ucykpLHRoaXMubHx8KHRoaXMubD17fSl9Xy5wcm90b3R5cGUuaD1mdW5jdGlvbigpe3ZhciB0LGUsbixpLGEscyx1LGgsZj1uZXcobz9VaW50OEFycmF5OkFycmF5KSgzMjc2OCksYz0wLGw9dGhpcy5pbnB1dCx5PXRoaXMuYyxkPXRoaXMuZmlsZW5hbWUsZz10aGlzLnc7aWYoZltjKytdPTMxLGZbYysrXT0xMzksZltjKytdPTgsdD0wLHRoaXMuZy5mbmFtZSYmKHR8PVQpLHRoaXMuZy5mY29tbWVudCYmKHR8PVIpLHRoaXMuZy5maGNyYyYmKHR8PVApLGZbYysrXT10LGU9KERhdGUubm93P0RhdGUubm93KCk6K25ldyBEYXRlKS8xZTN8MCxmW2MrK109MjU1JmUsZltjKytdPWU+Pj44JjI1NSxmW2MrK109ZT4+PjE2JjI1NSxmW2MrK109ZT4+PjI0JjI1NSxmW2MrK109MCxmW2MrK109aix0aGlzLmcuZm5hbWUhPT1yKXtmb3IodT0wLGg9ZC5sZW5ndGg7dTxoOysrdSkyNTU8KHM9ZC5jaGFyQ29kZUF0KHUpKSYmKGZbYysrXT1zPj4+OCYyNTUpLGZbYysrXT0yNTUmcztmW2MrK109MH1pZih0aGlzLmcuY29tbWVudCl7Zm9yKHU9MCxoPWcubGVuZ3RoO3U8aDsrK3UpMjU1PChzPWcuY2hhckNvZGVBdCh1KSkmJihmW2MrK109cz4+PjgmMjU1KSxmW2MrK109MjU1JnM7ZltjKytdPTB9cmV0dXJuIHRoaXMuZy5maGNyYyYmKG49NjU1MzUmcChmLDAsYyksZltjKytdPTI1NSZuLGZbYysrXT1uPj4+OCYyNTUpLHRoaXMubC5vdXRwdXRCdWZmZXI9Zix0aGlzLmwub3V0cHV0SW5kZXg9YyxmPShhPW5ldyB3KGwsdGhpcy5sKSkuaCgpLGM9YS5iLG8mJihjKzg+Zi5idWZmZXIuYnl0ZUxlbmd0aD8odGhpcy5hPW5ldyBVaW50OEFycmF5KGMrOCksdGhpcy5hLnNldChuZXcgVWludDhBcnJheShmLmJ1ZmZlcikpLGY9dGhpcy5hKTpmPW5ldyBVaW50OEFycmF5KGYuYnVmZmVyKSksaT1wKGwscixyKSxmW2MrK109MjU1JmksZltjKytdPWk+Pj44JjI1NSxmW2MrK109aT4+PjE2JjI1NSxmW2MrK109aT4+PjI0JjI1NSxoPWwubGVuZ3RoLGZbYysrXT0yNTUmaCxmW2MrK109aD4+PjgmMjU1LGZbYysrXT1oPj4+MTYmMjU1LGZbYysrXT1oPj4+MjQmMjU1LHRoaXMuYz15LG8mJmM8Zi5sZW5ndGgmJih0aGlzLmE9Zj1mLnN1YmFycmF5KDAsYykpLGZ9O3ZhciBqPTI1NSxQPTIsVD04LFI9MTY7ZnVuY3Rpb24gQyhlLHIpe3N3aXRjaCh0aGlzLm89W10sdGhpcy5wPTMyNzY4LHRoaXMuZT10aGlzLmo9dGhpcy5jPXRoaXMucz0wLHRoaXMuaW5wdXQ9bz9uZXcgVWludDhBcnJheShlKTplLHRoaXMudT0hMSx0aGlzLnE9Tix0aGlzLks9ITEsIXImJihyPXt9KXx8KHIuaW5kZXgmJih0aGlzLmM9ci5pbmRleCksci5idWZmZXJTaXplJiYodGhpcy5wPXIuYnVmZmVyU2l6ZSksci5idWZmZXJUeXBlJiYodGhpcy5xPXIuYnVmZmVyVHlwZSksci5yZXNpemUmJih0aGlzLks9ci5yZXNpemUpKSx0aGlzLnEpe2Nhc2UgTTp0aGlzLmI9MzI3NjgsdGhpcy5hPW5ldyhvP1VpbnQ4QXJyYXk6QXJyYXkpKDMyNzY4K3RoaXMucCsyNTgpO2JyZWFrO2Nhc2UgTjp0aGlzLmI9MCx0aGlzLmE9bmV3KG8/VWludDhBcnJheTpBcnJheSkodGhpcy5wKSx0aGlzLmY9dGhpcy5TLHRoaXMuej10aGlzLk8sdGhpcy5yPXRoaXMuUTticmVhaztkZWZhdWx0OnQoRXJyb3IoImludmFsaWQgaW5mbGF0ZSBtb2RlIikpfX12YXIgTT0wLE49MTtDLnByb3RvdHlwZS5pPWZ1bmN0aW9uKCl7Zm9yKDshdGhpcy51Oyl7dmFyIGU9bnQodGhpcywzKTtzd2l0Y2goMSZlJiYodGhpcy51PWkpLGU+Pj49MSl7Y2FzZSAwOnZhciBuPXRoaXMuaW5wdXQsYT10aGlzLmMscz10aGlzLmEsdT10aGlzLmIsaD1uLmxlbmd0aCxmPXIsYz1zLmxlbmd0aCxsPXI7c3dpdGNoKHRoaXMuZT10aGlzLmo9MCxhKzE+PWgmJnQoRXJyb3IoImludmFsaWQgdW5jb21wcmVzc2VkIGJsb2NrIGhlYWRlcjogTEVOIikpLGY9blthKytdfG5bYSsrXTw8OCxhKzE+PWgmJnQoRXJyb3IoImludmFsaWQgdW5jb21wcmVzc2VkIGJsb2NrIGhlYWRlcjogTkxFTiIpKSxmPT09fihuW2ErK118blthKytdPDw4KSYmdChFcnJvcigiaW52YWxpZCB1bmNvbXByZXNzZWQgYmxvY2sgaGVhZGVyOiBsZW5ndGggdmVyaWZ5IikpLGErZj5uLmxlbmd0aCYmdChFcnJvcigiaW5wdXQgYnVmZmVyIGlzIGJyb2tlbiIpKSx0aGlzLnEpe2Nhc2UgTTpmb3IoO3UrZj5zLmxlbmd0aDspe2lmKGYtPWw9Yy11LG8pcy5zZXQobi5zdWJhcnJheShhLGErbCksdSksdSs9bCxhKz1sO2Vsc2UgZm9yKDtsLS07KXNbdSsrXT1uW2ErK107dGhpcy5iPXUscz10aGlzLmYoKSx1PXRoaXMuYn1icmVhaztjYXNlIE46Zm9yKDt1K2Y+cy5sZW5ndGg7KXM9dGhpcy5mKHtCOjJ9KTticmVhaztkZWZhdWx0OnQoRXJyb3IoImludmFsaWQgaW5mbGF0ZSBtb2RlIikpfWlmKG8pcy5zZXQobi5zdWJhcnJheShhLGErZiksdSksdSs9ZixhKz1mO2Vsc2UgZm9yKDtmLS07KXNbdSsrXT1uW2ErK107dGhpcy5jPWEsdGhpcy5iPXUsdGhpcy5hPXM7YnJlYWs7Y2FzZSAxOnRoaXMucih0dCxydCk7YnJlYWs7Y2FzZSAyOnZhciBwLHksZCxnLGI9bnQodGhpcyw1KSsyNTcsdz1udCh0aGlzLDUpKzEsbT1udCh0aGlzLDQpKzQsQT1uZXcobz9VaW50OEFycmF5OkFycmF5KShELmxlbmd0aCksRT1yLGs9cix4PXIsTz1yLEk9cjtmb3IoST0wO0k8bTsrK0kpQVtEW0ldXT1udCh0aGlzLDMpO2lmKCFvKWZvcihJPW0sbT1BLmxlbmd0aDtJPG07KytJKUFbRFtJXV09MDtmb3IocD12KEEpLEU9bmV3KG8/VWludDhBcnJheTpBcnJheSkoYit3KSxJPTAsZz1iK3c7STxnOylzd2l0Y2goaz1pdCh0aGlzLHApLGspe2Nhc2UgMTY6Zm9yKE89MytudCh0aGlzLDIpO08tLTspRVtJKytdPXg7YnJlYWs7Y2FzZSAxNzpmb3IoTz0zK250KHRoaXMsMyk7Ty0tOylFW0krK109MDt4PTA7YnJlYWs7Y2FzZSAxODpmb3IoTz0xMStudCh0aGlzLDcpO08tLTspRVtJKytdPTA7eD0wO2JyZWFrO2RlZmF1bHQ6eD1FW0krK109a315PXYobz9FLnN1YmFycmF5KDAsYik6RS5zbGljZSgwLGIpKSxkPXYobz9FLnN1YmFycmF5KGIpOkUuc2xpY2UoYikpLHRoaXMucih5LGQpO2JyZWFrO2RlZmF1bHQ6dChFcnJvcigidW5rbm93biBCVFlQRTogIitlKSl9fXJldHVybiB0aGlzLnooKX07dmFyIEYsRyx6PVsxNiwxNywxOCwwLDgsNyw5LDYsMTAsNSwxMSw0LDEyLDMsMTMsMiwxNCwxLDE1XSxEPW8/bmV3IFVpbnQxNkFycmF5KHopOnosVz1bMyw0LDUsNiw3LDgsOSwxMCwxMSwxMywxNSwxNywxOSwyMywyNywzMSwzNSw0Myw1MSw1OSw2Nyw4Myw5OSwxMTUsMTMxLDE2MywxOTUsMjI3LDI1OCwyNTgsMjU4XSxZPW8/bmV3IFVpbnQxNkFycmF5KFcpOlcsVj1bMCwwLDAsMCwwLDAsMCwwLDEsMSwxLDEsMiwyLDIsMiwzLDMsMywzLDQsNCw0LDQsNSw1LDUsNSwwLDAsMF0scT1vP25ldyBVaW50OEFycmF5KFYpOlYsSj1bMSwyLDMsNCw1LDcsOSwxMywxNywyNSwzMyw0OSw2NSw5NywxMjksMTkzLDI1NywzODUsNTEzLDc2OSwxMDI1LDE1MzcsMjA0OSwzMDczLDQwOTcsNjE0NSw4MTkzLDEyMjg5LDE2Mzg1LDI0NTc3XSxRPW8/bmV3IFVpbnQxNkFycmF5KEopOkosWD1bMCwwLDAsMCwxLDEsMiwyLDMsMyw0LDQsNSw1LDYsNiw3LDcsOCw4LDksOSwxMCwxMCwxMSwxMSwxMiwxMiwxMywxM10sSD1vP25ldyBVaW50OEFycmF5KFgpOlgsSz1uZXcobz9VaW50OEFycmF5OkFycmF5KSgyODgpO2ZvcihGPTAsRz1LLmxlbmd0aDtGPEc7KytGKUtbRl09MTQzPj1GPzg6MjU1Pj1GPzk6Mjc5Pj1GPzc6ODt2YXIgJCxaLHR0PXYoSyksZXQ9bmV3KG8/VWludDhBcnJheTpBcnJheSkoMzApO2ZvcigkPTAsWj1ldC5sZW5ndGg7JDxaOysrJClldFskXT01O3ZhciBydD12KGV0KTtmdW5jdGlvbiBudChlLHIpe2Zvcih2YXIgbixpPWUuaixvPWUuZSxhPWUuaW5wdXQscz1lLmMsdT1hLmxlbmd0aDtvPHI7KXM+PXUmJnQoRXJyb3IoImlucHV0IGJ1ZmZlciBpcyBicm9rZW4iKSksaXw9YVtzKytdPDxvLG8rPTg7cmV0dXJuIG49aSYoMTw8ciktMSxlLmo9aT4+PnIsZS5lPW8tcixlLmM9cyxufWZ1bmN0aW9uIGl0KGUscil7Zm9yKHZhciBuLGksbz1lLmosYT1lLmUscz1lLmlucHV0LHU9ZS5jLGg9cy5sZW5ndGgsZj1yWzBdLGM9clsxXTthPGMmJiEodT49aCk7KW98PXNbdSsrXTw8YSxhKz04O3JldHVybihpPShuPWZbbyYoMTw8YyktMV0pPj4+MTYpPmEmJnQoRXJyb3IoImludmFsaWQgY29kZSBsZW5ndGg6ICIraSkpLGUuaj1vPj5pLGUuZT1hLWksZS5jPXUsNjU1MzUmbn1mdW5jdGlvbiBvdCh0KXt0aGlzLmlucHV0PXQsdGhpcy5jPTAsdGhpcy5HPVtdLHRoaXMuUj0hMX1mdW5jdGlvbiBhdCh0KXtpZigic3RyaW5nIj09dHlwZW9mIHQpe3ZhciBlLHIsbj10LnNwbGl0KCIiKTtmb3IoZT0wLHI9bi5sZW5ndGg7ZTxyO2UrKyluW2VdPSgyNTUmbltlXS5jaGFyQ29kZUF0KDApKT4+PjA7dD1ufWZvcih2YXIgaSxvPTEsYT0wLHM9dC5sZW5ndGgsdT0wOzA8czspe3MtPWk9MTAyNDxzPzEwMjQ6cztkb3thKz1vKz10W3UrK119d2hpbGUoLS1pKTtvJT02NTUyMSxhJT02NTUyMX1yZXR1cm4oYTw8MTZ8byk+Pj4wfWZ1bmN0aW9uIHN0KGUscil7dmFyIG4saTt0aGlzLmlucHV0PWUsdGhpcy5jPTAsIXImJihyPXt9KXx8KHIuaW5kZXgmJih0aGlzLmM9ci5pbmRleCksci52ZXJpZnkmJih0aGlzLlY9ci52ZXJpZnkpKSxuPWVbdGhpcy5jKytdLGk9ZVt0aGlzLmMrK10sKDE1Jm4pPT09dXQ/dGhpcy5tZXRob2Q9dXQ6dChFcnJvcigidW5zdXBwb3J0ZWQgY29tcHJlc3Npb24gbWV0aG9kIikpLDAhPSgobjw8OCkraSklMzEmJnQoRXJyb3IoImludmFsaWQgZmNoZWNrIGZsYWc6IisoKG48PDgpK2kpJTMxKSksMzImaSYmdChFcnJvcigiZmRpY3QgZmxhZyBpcyBub3Qgc3VwcG9ydGVkIikpLHRoaXMuSj1uZXcgQyhlLHtpbmRleDp0aGlzLmMsYnVmZmVyU2l6ZTpyLmJ1ZmZlclNpemUsYnVmZmVyVHlwZTpyLmJ1ZmZlclR5cGUscmVzaXplOnIucmVzaXplfSl9Qy5wcm90b3R5cGUucj1mdW5jdGlvbih0LGUpe3ZhciByPXRoaXMuYSxuPXRoaXMuYjt0aGlzLkE9dDtmb3IodmFyIGksbyxhLHMsdT1yLmxlbmd0aC0yNTg7MjU2IT09KGk9aXQodGhpcyx0KSk7KWlmKDI1Nj5pKW4+PXUmJih0aGlzLmI9bixyPXRoaXMuZigpLG49dGhpcy5iKSxyW24rK109aTtlbHNlIGZvcihzPVlbbz1pLTI1N10sMDxxW29dJiYocys9bnQodGhpcyxxW29dKSksaT1pdCh0aGlzLGUpLGE9UVtpXSwwPEhbaV0mJihhKz1udCh0aGlzLEhbaV0pKSxuPj11JiYodGhpcy5iPW4scj10aGlzLmYoKSxuPXRoaXMuYik7cy0tOylyW25dPXJbbisrLWFdO2Zvcig7ODw9dGhpcy5lOyl0aGlzLmUtPTgsdGhpcy5jLS07dGhpcy5iPW59LEMucHJvdG90eXBlLlE9ZnVuY3Rpb24odCxlKXt2YXIgcj10aGlzLmEsbj10aGlzLmI7dGhpcy5BPXQ7Zm9yKHZhciBpLG8sYSxzLHU9ci5sZW5ndGg7MjU2IT09KGk9aXQodGhpcyx0KSk7KWlmKDI1Nj5pKW4+PXUmJih1PShyPXRoaXMuZigpKS5sZW5ndGgpLHJbbisrXT1pO2Vsc2UgZm9yKHM9WVtvPWktMjU3XSwwPHFbb10mJihzKz1udCh0aGlzLHFbb10pKSxpPWl0KHRoaXMsZSksYT1RW2ldLDA8SFtpXSYmKGErPW50KHRoaXMsSFtpXSkpLG4rcz51JiYodT0ocj10aGlzLmYoKSkubGVuZ3RoKTtzLS07KXJbbl09cltuKystYV07Zm9yKDs4PD10aGlzLmU7KXRoaXMuZS09OCx0aGlzLmMtLTt0aGlzLmI9bn0sQy5wcm90b3R5cGUuZj1mdW5jdGlvbigpe3ZhciB0LGUscj1uZXcobz9VaW50OEFycmF5OkFycmF5KSh0aGlzLmItMzI3NjgpLG49dGhpcy5iLTMyNzY4LGk9dGhpcy5hO2lmKG8pci5zZXQoaS5zdWJhcnJheSgzMjc2OCxyLmxlbmd0aCkpO2Vsc2UgZm9yKHQ9MCxlPXIubGVuZ3RoO3Q8ZTsrK3Qpclt0XT1pW3QrMzI3NjhdO2lmKHRoaXMuby5wdXNoKHIpLHRoaXMucys9ci5sZW5ndGgsbylpLnNldChpLnN1YmFycmF5KG4sbiszMjc2OCkpO2Vsc2UgZm9yKHQ9MDszMjc2OD50OysrdClpW3RdPWlbbit0XTtyZXR1cm4gdGhpcy5iPTMyNzY4LGl9LEMucHJvdG90eXBlLlM9ZnVuY3Rpb24odCl7dmFyIGUscixuLGk9dGhpcy5pbnB1dC5sZW5ndGgvdGhpcy5jKzF8MCxhPXRoaXMuaW5wdXQscz10aGlzLmE7cmV0dXJuIHQmJigibnVtYmVyIj09dHlwZW9mIHQuQiYmKGk9dC5CKSwibnVtYmVyIj09dHlwZW9mIHQuTSYmKGkrPXQuTSkpLHI9Mj5pPyhuPShhLmxlbmd0aC10aGlzLmMpL3RoaXMuQVsyXS8yKjI1OHwwKTxzLmxlbmd0aD9zLmxlbmd0aCtuOnMubGVuZ3RoPDwxOnMubGVuZ3RoKmksbz8oZT1uZXcgVWludDhBcnJheShyKSkuc2V0KHMpOmU9cyx0aGlzLmE9ZX0sQy5wcm90b3R5cGUuej1mdW5jdGlvbigpe3ZhciB0LGUscixuLGksYT0wLHM9dGhpcy5hLHU9dGhpcy5vLGg9bmV3KG8/VWludDhBcnJheTpBcnJheSkodGhpcy5zKyh0aGlzLmItMzI3NjgpKTtpZigwPT09dS5sZW5ndGgpcmV0dXJuIG8/dGhpcy5hLnN1YmFycmF5KDMyNzY4LHRoaXMuYik6dGhpcy5hLnNsaWNlKDMyNzY4LHRoaXMuYik7Zm9yKGU9MCxyPXUubGVuZ3RoO2U8cjsrK2UpZm9yKG49MCxpPSh0PXVbZV0pLmxlbmd0aDtuPGk7KytuKWhbYSsrXT10W25dO2ZvcihlPTMyNzY4LHI9dGhpcy5iO2U8cjsrK2UpaFthKytdPXNbZV07cmV0dXJuIHRoaXMubz1bXSx0aGlzLmJ1ZmZlcj1ofSxDLnByb3RvdHlwZS5PPWZ1bmN0aW9uKCl7dmFyIHQsZT10aGlzLmI7cmV0dXJuIG8/dGhpcy5LPyh0PW5ldyBVaW50OEFycmF5KGUpKS5zZXQodGhpcy5hLnN1YmFycmF5KDAsZSkpOnQ9dGhpcy5hLnN1YmFycmF5KDAsZSk6KHRoaXMuYS5sZW5ndGg+ZSYmKHRoaXMuYS5sZW5ndGg9ZSksdD10aGlzLmEpLHRoaXMuYnVmZmVyPXR9LG90LnByb3RvdHlwZS5pPWZ1bmN0aW9uKCl7Zm9yKHZhciBlPXRoaXMuaW5wdXQubGVuZ3RoO3RoaXMuYzxlOyl7dmFyIG4sYSxzPW5ldyBnLHU9cixoPXIsZj1yLGM9cixsPXIseT1yLGQ9cixiPXRoaXMuaW5wdXQsdj10aGlzLmM7aWYocy5DPWJbdisrXSxzLkQ9Ylt2KytdLCgzMSE9PXMuQ3x8MTM5IT09cy5EKSYmdChFcnJvcigiaW52YWxpZCBmaWxlIHNpZ25hdHVyZToiK3MuQysiLCIrcy5EKSkscy52PWJbdisrXSw4PT09cy52fHx0KEVycm9yKCJ1bmtub3duIGNvbXByZXNzaW9uIG1ldGhvZDogIitzLnYpKSxzLm49Ylt2KytdLGE9Ylt2KytdfGJbdisrXTw8OHxiW3YrK108PDE2fGJbdisrXTw8MjQscy4kPW5ldyBEYXRlKDFlMyphKSxzLmJhPWJbdisrXSxzLmFhPWJbdisrXSwwPCg0JnMubikmJihzLlc9Ylt2KytdfGJbdisrXTw8OCx2Kz1zLlcpLDA8KHMubiZUKSl7Zm9yKHk9W10sbD0wOzA8KGM9Ylt2KytdKTspeVtsKytdPVN0cmluZy5mcm9tQ2hhckNvZGUoYyk7cy5uYW1lPXkuam9pbigiIil9aWYoMDwocy5uJlIpKXtmb3IoeT1bXSxsPTA7MDwoYz1iW3YrK10pOyl5W2wrK109U3RyaW5nLmZyb21DaGFyQ29kZShjKTtzLnc9eS5qb2luKCIiKX0wPChzLm4mUCkmJihzLlA9NjU1MzUmcChiLDAsdikscy5QIT09KGJbdisrXXxiW3YrK108PDgpJiZ0KEVycm9yKCJpbnZhbGlkIGhlYWRlciBjcmMxNiIpKSksdT1iW2IubGVuZ3RoLTRdfGJbYi5sZW5ndGgtM108PDh8YltiLmxlbmd0aC0yXTw8MTZ8YltiLmxlbmd0aC0xXTw8MjQsYi5sZW5ndGgtdi00LTQ8NTEyKnUmJihmPXUpLGg9bmV3IEMoYix7aW5kZXg6dixidWZmZXJTaXplOmZ9KSxzLmRhdGE9bj1oLmkoKSx2PWguYyxzLlk9ZD0oYlt2KytdfGJbdisrXTw8OHxiW3YrK108PDE2fGJbdisrXTw8MjQpPj4+MCxwKG4scixyKSE9PWQmJnQoRXJyb3IoImludmFsaWQgQ1JDLTMyIGNoZWNrc3VtOiAweCIrcChuLHIscikudG9TdHJpbmcoMTYpKyIgLyAweCIrZC50b1N0cmluZygxNikpKSxzLlo9dT0oYlt2KytdfGJbdisrXTw8OHxiW3YrK108PDE2fGJbdisrXTw8MjQpPj4+MCwoNDI5NDk2NzI5NSZuLmxlbmd0aCkhPT11JiZ0KEVycm9yKCJpbnZhbGlkIGlucHV0IHNpemU6ICIrKDQyOTQ5NjcyOTUmbi5sZW5ndGgpKyIgLyAiK3UpKSx0aGlzLkcucHVzaChzKSx0aGlzLmM9dn10aGlzLlI9aTt2YXIgdyxtLEEsRT10aGlzLkcsaz0wLHg9MDtmb3Iodz0wLG09RS5sZW5ndGg7dzxtOysrdyl4Kz1FW3ddLmRhdGEubGVuZ3RoO2lmKG8pZm9yKEE9bmV3IFVpbnQ4QXJyYXkoeCksdz0wO3c8bTsrK3cpQS5zZXQoRVt3XS5kYXRhLGspLGsrPUVbd10uZGF0YS5sZW5ndGg7ZWxzZXtmb3IoQT1bXSx3PTA7dzxtOysrdylBW3ddPUVbd10uZGF0YTtBPUFycmF5LnByb3RvdHlwZS5jb25jYXQuYXBwbHkoW10sQSl9cmV0dXJuIEF9LHN0LnByb3RvdHlwZS5pPWZ1bmN0aW9uKCl7dmFyIGUscj10aGlzLmlucHV0O3JldHVybiBlPXRoaXMuSi5pKCksdGhpcy5jPXRoaXMuSi5jLHRoaXMuViYmKHJbdGhpcy5jKytdPDwyNHxyW3RoaXMuYysrXTw8MTZ8clt0aGlzLmMrK108PDh8clt0aGlzLmMrK10pPj4+MCE9PWF0KGUpJiZ0KEVycm9yKCJpbnZhbGlkIGFkbGVyLTMyIGNoZWNrc3VtIikpLGV9O3ZhciB1dD04O2Z1bmN0aW9uIGh0KHQsZSl7dGhpcy5pbnB1dD10LHRoaXMuYT1uZXcobz9VaW50OEFycmF5OkFycmF5KSgzMjc2OCksdGhpcy5rPWZ0LnQ7dmFyIHIsbj17fTtmb3IociBpbiFlJiYoZT17fSl8fCJudW1iZXIiIT10eXBlb2YgZS5jb21wcmVzc2lvblR5cGV8fCh0aGlzLms9ZS5jb21wcmVzc2lvblR5cGUpLGUpbltyXT1lW3JdO24ub3V0cHV0QnVmZmVyPXRoaXMuYSx0aGlzLkk9bmV3IHcodGhpcy5pbnB1dCxuKX12YXIgZnQ9RTtmdW5jdGlvbiBjdCh0LGUpe3ZhciByO3JldHVybiByPW5ldyBodCh0KS5oKCksZXx8KGU9e30pLGUuSD9yOmR0KHIpfWZ1bmN0aW9uIGx0KHQsZSl7dmFyIHI7cmV0dXJuIHQuc3ViYXJyYXk9dC5zbGljZSxyPW5ldyBzdCh0KS5pKCksZXx8KGU9e30pLGUubm9CdWZmZXI/cjpkdChyKX1mdW5jdGlvbiBwdCh0LGUpe3ZhciByO3JldHVybiB0LnN1YmFycmF5PXQuc2xpY2Uscj1uZXcgXyh0KS5oKCksZXx8KGU9e30pLGUuSD9yOmR0KHIpfWZ1bmN0aW9uIHl0KHQsZSl7dmFyIHI7cmV0dXJuIHQuc3ViYXJyYXk9dC5zbGljZSxyPW5ldyBvdCh0KS5pKCksZXx8KGU9e30pLGUuSD9yOmR0KHIpfWZ1bmN0aW9uIGR0KHQpe3ZhciBlLHIsaT1uZXcgbih0Lmxlbmd0aCk7Zm9yKGU9MCxyPXQubGVuZ3RoO2U8cjsrK2UpaVtlXT10W2VdO3JldHVybiBpfWh0LnByb3RvdHlwZS5oPWZ1bmN0aW9uKCl7dmFyIGUscixuLGksYSxzLHUsaD0wO2lmKHU9dGhpcy5hLChlPXV0KT09PXV0P3I9TWF0aC5MT0cyRSpNYXRoLmxvZygzMjc2OCktODp0KEVycm9yKCJpbnZhbGlkIGNvbXByZXNzaW9uIG1ldGhvZCIpKSxuPXI8PDR8ZSx1W2grK109bixlPT09dXQpc3dpdGNoKHRoaXMuayl7Y2FzZSBmdC5OT05FOmE9MDticmVhaztjYXNlIGZ0Lkw6YT0xO2JyZWFrO2Nhc2UgZnQudDphPTI7YnJlYWs7ZGVmYXVsdDp0KEVycm9yKCJ1bnN1cHBvcnRlZCBjb21wcmVzc2lvbiB0eXBlIikpfWVsc2UgdChFcnJvcigiaW52YWxpZCBjb21wcmVzc2lvbiBtZXRob2QiKSk7cmV0dXJuIGk9YTw8Nix1W2grK109aXwzMS0oMjU2Km4raSklMzEscz1hdCh0aGlzLmlucHV0KSx0aGlzLkkuYj1oLGg9KHU9dGhpcy5JLmgoKSkubGVuZ3RoLG8mJigodT1uZXcgVWludDhBcnJheSh1LmJ1ZmZlcikpLmxlbmd0aDw9aCs0JiYodGhpcy5hPW5ldyBVaW50OEFycmF5KHUubGVuZ3RoKzQpLHRoaXMuYS5zZXQodSksdT10aGlzLmEpLHU9dS5zdWJhcnJheSgwLGgrNCkpLHVbaCsrXT1zPj4yNCYyNTUsdVtoKytdPXM+PjE2JjI1NSx1W2grK109cz4+OCYyNTUsdVtoKytdPTI1NSZzLHV9LGUuZGVmbGF0ZT1mdW5jdGlvbih0LGUscil7cHJvY2Vzcy5uZXh0VGljaygoZnVuY3Rpb24oKXt2YXIgbixpO3RyeXtpPWN0KHQscil9Y2F0Y2godCl7bj10fWUobixpKX0pKX0sZS5kZWZsYXRlU3luYz1jdCxlLmluZmxhdGU9ZnVuY3Rpb24odCxlLHIpe3Byb2Nlc3MubmV4dFRpY2soKGZ1bmN0aW9uKCl7dmFyIG4saTt0cnl7aT1sdCh0LHIpfWNhdGNoKHQpe249dH1lKG4saSl9KSl9LGUuaW5mbGF0ZVN5bmM9bHQsZS5nemlwPWZ1bmN0aW9uKHQsZSxyKXtwcm9jZXNzLm5leHRUaWNrKChmdW5jdGlvbigpe3ZhciBuLGk7dHJ5e2k9cHQodCxyKX1jYXRjaCh0KXtuPXR9ZShuLGkpfSkpfSxlLmd6aXBTeW5jPXB0LGUuZ3VuemlwPWZ1bmN0aW9uKHQsZSxyKXtwcm9jZXNzLm5leHRUaWNrKChmdW5jdGlvbigpe3ZhciBuLGk7dHJ5e2k9eXQodCxyKX1jYXRjaCh0KXtuPXR9ZShuLGkpfSkpfSxlLmd1bnppcFN5bmM9eXR9KS5jYWxsKHRoaXMpfSwyNDI6dD0+eyJ1c2Ugc3RyaWN0Ijtjb25zdCBlPXtiaWdJbnQ6KCk9Pihhc3luYyB0PT57dHJ5e3JldHVybihhd2FpdCBXZWJBc3NlbWJseS5pbnN0YW50aWF0ZSh0KSkuaW5zdGFuY2UuZXhwb3J0cy5iKEJpZ0ludCgwKSk9PT1CaWdJbnQoMCl9Y2F0Y2godCl7cmV0dXJuITF9fSkobmV3IFVpbnQ4QXJyYXkoWzAsOTcsMTE1LDEwOSwxLDAsMCwwLDEsNiwxLDk2LDEsMTI2LDEsMTI2LDMsMiwxLDAsNyw1LDEsMSw5OCwwLDAsMTAsNiwxLDQsMCwzMiwwLDExXSkpLGJ1bGtNZW1vcnk6YXN5bmMoKT0+V2ViQXNzZW1ibHkudmFsaWRhdGUobmV3IFVpbnQ4QXJyYXkoWzAsOTcsMTE1LDEwOSwxLDAsMCwwLDEsNCwxLDk2LDAsMCwzLDIsMSwwLDUsMywxLDAsMSwxMCwxNCwxLDEyLDAsNjUsMCw2NSwwLDY1LDAsMjUyLDEwLDAsMCwxMV0pKSxleGNlcHRpb25zOmFzeW5jKCk9PldlYkFzc2VtYmx5LnZhbGlkYXRlKG5ldyBVaW50OEFycmF5KFswLDk3LDExNSwxMDksMSwwLDAsMCwxLDQsMSw5NiwwLDAsMywyLDEsMCwxMCw4LDEsNiwwLDYsNjQsMjUsMTEsMTFdKSksZXhjZXB0aW9uc0ZpbmFsOigpPT4oYXN5bmMoKT0+e3RyeXtyZXR1cm4gbmV3IFdlYkFzc2VtYmx5Lk1vZHVsZShVaW50OEFycmF5LmZyb20oYXRvYigiQUdGemJRRUFBQUFCQkFGZ0FBQURBZ0VBQ2hBQkRnQUNhUjlBQVFNQUFBc0FDeG9MIiksKHQ9PnQuY29kZVBvaW50QXQoMCkpKSksITB9Y2F0Y2godCl7cmV0dXJuITF9fSkoKSxleHRlbmRlZENvbnN0OmFzeW5jKCk9PldlYkFzc2VtYmx5LnZhbGlkYXRlKG5ldyBVaW50OEFycmF5KFswLDk3LDExNSwxMDksMSwwLDAsMCw1LDMsMSwwLDEsMTEsOSwxLDAsNjUsMSw2NSwyLDEwNiwxMSwwXSkpLGdjOigpPT4oYXN5bmMoKT0+V2ViQXNzZW1ibHkudmFsaWRhdGUobmV3IFVpbnQ4QXJyYXkoWzAsOTcsMTE1LDEwOSwxLDAsMCwwLDEsNSwxLDk1LDEsMTIwLDBdKSkpKCksanNTdHJpbmdCdWlsdGluczooKT0+KGFzeW5jKCk9Pnt0cnl7cmV0dXJuIGF3YWl0IFdlYkFzc2VtYmx5Lmluc3RhbnRpYXRlKFVpbnQ4QXJyYXkuZnJvbShhdG9iKCJBR0Z6YlFFQUFBQUJCZ0ZnQVc4QmZ3SVhBUTUzWVhOdE9tcHpMWE4wY21sdVp3UjBaWE4wQUFBPSIpLCh0PT50LmNvZGVQb2ludEF0KDApKSkse30se2J1aWx0aW5zOlsianMtc3RyaW5nIl19KSwhMH1jYXRjaCh0KXtyZXR1cm4hMX19KSgpLGpzcGk6KCk9Pihhc3luYygpPT4iU3VzcGVuZGluZyJpbiBXZWJBc3NlbWJseSkoKSxtZW1vcnk2NDphc3luYygpPT5XZWJBc3NlbWJseS52YWxpZGF0ZShuZXcgVWludDhBcnJheShbMCw5NywxMTUsMTA5LDEsMCwwLDAsNSwzLDEsNCwxXSkpLG11bHRpTWVtb3J5OigpPT4oYXN5bmMoKT0+e3RyeXtyZXR1cm4gbmV3IFdlYkFzc2VtYmx5Lk1vZHVsZShuZXcgVWludDhBcnJheShbMCw5NywxMTUsMTA5LDEsMCwwLDAsNSw1LDIsMCwwLDAsMF0pKSwhMH1jYXRjaCh0KXtyZXR1cm4hMX19KSgpLG11bHRpVmFsdWU6YXN5bmMoKT0+V2ViQXNzZW1ibHkudmFsaWRhdGUobmV3IFVpbnQ4QXJyYXkoWzAsOTcsMTE1LDEwOSwxLDAsMCwwLDEsNiwxLDk2LDAsMiwxMjcsMTI3LDMsMiwxLDAsMTAsOCwxLDYsMCw2NSwwLDY1LDAsMTFdKSksbXV0YWJsZUdsb2JhbHM6YXN5bmMoKT0+V2ViQXNzZW1ibHkudmFsaWRhdGUobmV3IFVpbnQ4QXJyYXkoWzAsOTcsMTE1LDEwOSwxLDAsMCwwLDIsOCwxLDEsOTcsMSw5OCwzLDEyNywxLDYsNiwxLDEyNywxLDY1LDAsMTEsNyw1LDEsMSw5NywzLDFdKSkscmVmZXJlbmNlVHlwZXM6YXN5bmMoKT0+V2ViQXNzZW1ibHkudmFsaWRhdGUobmV3IFVpbnQ4QXJyYXkoWzAsOTcsMTE1LDEwOSwxLDAsMCwwLDEsNCwxLDk2LDAsMCwzLDIsMSwwLDEwLDcsMSw1LDAsMjA4LDExMiwyNiwxMV0pKSxyZWxheGVkU2ltZDphc3luYygpPT5XZWJBc3NlbWJseS52YWxpZGF0ZShuZXcgVWludDhBcnJheShbMCw5NywxMTUsMTA5LDEsMCwwLDAsMSw1LDEsOTYsMCwxLDEyMywzLDIsMSwwLDEwLDE1LDEsMTMsMCw2NSwxLDI1MywxNSw2NSwyLDI1MywxNSwyNTMsMTI4LDIsMTFdKSksc2F0dXJhdGVkRmxvYXRUb0ludDphc3luYygpPT5XZWJBc3NlbWJseS52YWxpZGF0ZShuZXcgVWludDhBcnJheShbMCw5NywxMTUsMTA5LDEsMCwwLDAsMSw0LDEsOTYsMCwwLDMsMiwxLDAsMTAsMTIsMSwxMCwwLDY3LDAsMCwwLDAsMjUyLDAsMjYsMTFdKSksc2lnbkV4dGVuc2lvbnM6YXN5bmMoKT0+V2ViQXNzZW1ibHkudmFsaWRhdGUobmV3IFVpbnQ4QXJyYXkoWzAsOTcsMTE1LDEwOSwxLDAsMCwwLDEsNCwxLDk2LDAsMCwzLDIsMSwwLDEwLDgsMSw2LDAsNjUsMCwxOTIsMjYsMTFdKSksc2ltZDphc3luYygpPT5XZWJBc3NlbWJseS52YWxpZGF0ZShuZXcgVWludDhBcnJheShbMCw5NywxMTUsMTA5LDEsMCwwLDAsMSw1LDEsOTYsMCwxLDEyMywzLDIsMSwwLDEwLDEwLDEsOCwwLDY1LDAsMjUzLDE1LDI1Myw5OCwxMV0pKSxzdHJlYW1pbmdDb21waWxhdGlvbjooKT0+KGFzeW5jKCk9PiJjb21waWxlU3RyZWFtaW5nImluIFdlYkFzc2VtYmx5KSgpLHRhaWxDYWxsOmFzeW5jKCk9PldlYkFzc2VtYmx5LnZhbGlkYXRlKG5ldyBVaW50OEFycmF5KFswLDk3LDExNSwxMDksMSwwLDAsMCwxLDQsMSw5NiwwLDAsMywyLDEsMCwxMCw2LDEsNCwwLDE4LDAsMTFdKSksdGhyZWFkczooKT0+KGFzeW5jIHQ9Pnt0cnl7cmV0dXJuInVuZGVmaW5lZCIhPXR5cGVvZiBNZXNzYWdlQ2hhbm5lbCYmKG5ldyBNZXNzYWdlQ2hhbm5lbCkucG9ydDEucG9zdE1lc3NhZ2UobmV3IFNoYXJlZEFycmF5QnVmZmVyKDEpKSxXZWJBc3NlbWJseS52YWxpZGF0ZSh0KX1jYXRjaCh0KXtyZXR1cm4hMX19KShuZXcgVWludDhBcnJheShbMCw5NywxMTUsMTA5LDEsMCwwLDAsMSw0LDEsOTYsMCwwLDMsMiwxLDAsNSw0LDEsMywxLDEsMTAsMTEsMSw5LDAsNjUsMCwyNTQsMTYsMiwwLDI2LDExXSkpLHR5cGVSZWZsZWN0aW9uOigpPT4oYXN5bmMoKT0+IkZ1bmN0aW9uImluIFdlYkFzc2VtYmx5KSgpLHR5cGVkRnVuY3Rpb25SZWZlcmVuY2VzOigpPT4oYXN5bmMoKT0+e3RyeXtyZXR1cm4gbmV3IFdlYkFzc2VtYmx5Lk1vZHVsZShVaW50OEFycmF5LmZyb20oYXRvYigiQUdGemJRRUFBQUFCRUFOZ0FYOEJmMkFCWkFBQmYyQUFBWDhEQkFNQkFBSUpCUUVEQUFFQkNod0RDd0JCQ2tFcUlBQVVBR29MQndBZ0FFRUJhZ3NHQU5JQkVBQUwiKSwodD0+dC5jb2RlUG9pbnRBdCgwKSkpKSwhMH1jYXRjaCh0KXtyZXR1cm4hMX19KSgpfTt0LmV4cG9ydHM9ZX0sMjU4Oih0LGUscik9PnsidXNlIHN0cmljdCI7dC5leHBvcnRzPXIoMTMzKS5ndW56aXBTeW5jfSwzMjk6KHQsZSxyKT0+eyJ1c2Ugc3RyaWN0Ijt2YXIgbj1yKDU0NSkuaHA7ZnVuY3Rpb24gaSh0KXtyZXR1cm4gaT0iZnVuY3Rpb24iPT10eXBlb2YgU3ltYm9sJiYic3ltYm9sIj09dHlwZW9mIFN5bWJvbC5pdGVyYXRvcj9mdW5jdGlvbih0KXtyZXR1cm4gdHlwZW9mIHR9OmZ1bmN0aW9uKHQpe3JldHVybiB0JiYiZnVuY3Rpb24iPT10eXBlb2YgU3ltYm9sJiZ0LmNvbnN0cnVjdG9yPT09U3ltYm9sJiZ0IT09U3ltYm9sLnByb3RvdHlwZT8ic3ltYm9sIjp0eXBlb2YgdH0saSh0KX1mdW5jdGlvbiBvKHQsZSl7dmFyIHI9T2JqZWN0LmtleXModCk7aWYoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyl7dmFyIG49T2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyh0KTtlJiYobj1uLmZpbHRlcigoZnVuY3Rpb24oZSl7cmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodCxlKS5lbnVtZXJhYmxlfSkpKSxyLnB1c2guYXBwbHkocixuKX1yZXR1cm4gcn1mdW5jdGlvbiBhKHQpe2Zvcih2YXIgZT0xO2U8YXJndW1lbnRzLmxlbmd0aDtlKyspe3ZhciByPW51bGwhPWFyZ3VtZW50c1tlXT9hcmd1bWVudHNbZV06e307ZSUyP28oT2JqZWN0KHIpLCEwKS5mb3JFYWNoKChmdW5jdGlvbihlKXtzKHQsZSxyW2VdKX0pKTpPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycz9PYmplY3QuZGVmaW5lUHJvcGVydGllcyh0LE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKHIpKTpvKE9iamVjdChyKSkuZm9yRWFjaCgoZnVuY3Rpb24oZSl7T2JqZWN0LmRlZmluZVByb3BlcnR5KHQsZSxPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHIsZSkpfSkpfXJldHVybiB0fWZ1bmN0aW9uIHModCxlLHIpe3JldHVybihlPWZ1bmN0aW9uKHQpe3ZhciBlPWZ1bmN0aW9uKHQpe2lmKCJvYmplY3QiIT1pKHQpfHwhdClyZXR1cm4gdDt2YXIgZT10W1N5bWJvbC50b1ByaW1pdGl2ZV07aWYodm9pZCAwIT09ZSl7dmFyIHI9ZS5jYWxsKHQsInN0cmluZyIpO2lmKCJvYmplY3QiIT1pKHIpKXJldHVybiByO3Rocm93IG5ldyBUeXBlRXJyb3IoIkBAdG9QcmltaXRpdmUgbXVzdCByZXR1cm4gYSBwcmltaXRpdmUgdmFsdWUuIil9cmV0dXJuIFN0cmluZyh0KX0odCk7cmV0dXJuInN5bWJvbCI9PWkoZSk/ZTplKyIifShlKSlpbiB0P09iamVjdC5kZWZpbmVQcm9wZXJ0eSh0LGUse3ZhbHVlOnIsZW51bWVyYWJsZTohMCxjb25maWd1cmFibGU6ITAsd3JpdGFibGU6ITB9KTp0W2VdPXIsdH12YXIgdT1yKDQ1MCk7dC5leHBvcnRzPWZ1bmN0aW9uKHQsZSxyKXt2YXIgaSxvPWFyZ3VtZW50cy5sZW5ndGg+MyYmdm9pZCAwIT09YXJndW1lbnRzWzNdP2FyZ3VtZW50c1szXTowLHM9NjY9PT1yWzBdJiY3Nz09PXJbMV18fDY2PT09clsxXSYmNzc9PT1yWzBdLGg9cGFyc2VJbnQobnVsbD09PShpPXIuc2xpY2UoMCw1MDApLmpvaW4oIiAiKS5tYXRjaCgvMSAxOCAwIDMgMCAwIDAgMSAwIChcZCkvKSl8fHZvaWQgMD09PWk/dm9pZCAwOmlbMV0sMTApfHwxO2lmKHMpe3ZhciBmPW4uZnJvbShBcnJheS5mcm9tKGEoYSh7fSxyKSx7fSx7bGVuZ3RoOk9iamVjdC5rZXlzKHIpLmxlbmd0aH0pKSksYz11LmRlY29kZShmKTt0LkZTLndyaXRlRmlsZSgiL2lucHV0Iix1LmVuY29kZShjKS5kYXRhKX1lbHNlIHQuRlMud3JpdGVGaWxlKCIvaW5wdXQiLHIpO2lmKDE9PT1lLlNldEltYWdlRmlsZShoLG8pKXRocm93IEVycm9yKCJFcnJvciBhdHRlbXB0aW5nIHRvIHJlYWQgaW1hZ2UuIil9fSwzMzA6dD0+eyJ1c2Ugc3RyaWN0Ijt0LmV4cG9ydHM9SlNPTi5wYXJzZSgneyJFbCI6eyJRRSI6Il42LjAuMCJ9fScpfSwzMzQ6KHQsZSxyKT0+eyJ1c2Ugc3RyaWN0Ijt2YXIgbj1yKDUzNSksaT1yKDU0KSxvPWZ1bmN0aW9uKHQpe3ZhciBlPXQuc3BsaXQoIlxuIik7aWYoIiAgIj09PWVbMF0uc3Vic3RyaW5nKDAsMikpZm9yKHZhciByPTA7cjxlLmxlbmd0aDtyKz0xKSIgICI9PT1lW3JdLnN1YnN0cmluZygwLDIpJiYoZVtyXT1lW3JdLnNsaWNlKDIpKTtyZXR1cm4gZS5qb2luKCJcbiIpfTt0LmV4cG9ydHM9ZnVuY3Rpb24odCxlLHIsYSl7dmFyIHMsdSxoLGYsYyxsPWZ1bmN0aW9uKGUscil7cmV0dXJuIE9iamVjdC5rZXlzKHQpLmZpbHRlcigoZnVuY3Rpb24obil7cmV0dXJuIG4uc3RhcnRzV2l0aCgiIi5jb25jYXQociwiXyIpKSYmdFtuXT09PWV9KSkubWFwKChmdW5jdGlvbih0KXtyZXR1cm4gdC5zbGljZShyLmxlbmd0aCsxKX0pKVswXX0scD1mdW5jdGlvbihyKXtlLldyaXRlSW1hZ2UociwiL2ltYWdlLnBuZyIpO3ZhciBpPXQuRlMucmVhZEZpbGUoIi9pbWFnZS5wbmciKSxvPSJkYXRhOmltYWdlL3BuZztiYXNlNjQsIi5jb25jYXQobihpLmJ1ZmZlcikpO3JldHVybiB0LkZTLnVubGluaygiL2ltYWdlLnBuZyIpLG99O3JldHVybnt0ZXh0OnIudGV4dD9lLkdldFVURjhUZXh0KCk6bnVsbCxob2NyOnIuaG9jcj9vKGUuR2V0SE9DUlRleHQoKSk6bnVsbCx0c3Y6ci50c3Y/ZS5HZXRUU1ZUZXh0KCk6bnVsbCxib3g6ci5ib3g/ZS5HZXRCb3hUZXh0KCk6bnVsbCx1bmx2OnIudW5sdj9lLkdldFVOTFZUZXh0KCk6bnVsbCxvc2Q6ci5vc2Q/ZS5HZXRPc2RUZXh0KCk6bnVsbCxwZGY6ci5wZGY/KGg9bnVsbCE9PShzPWEucGRmVGl0bGUpJiZ2b2lkIDAhPT1zP3M6IlRlc3NlcmFjdCBPQ1IgUmVzdWx0IixmPW51bGwhPT0odT1hLnBkZlRleHRPbmx5KSYmdm9pZCAwIT09dSYmdSxjPW5ldyB0LlRlc3NQREZSZW5kZXJlcigidGVzc2VyYWN0LW9jciIsIi8iLGYpLGMuQmVnaW5Eb2N1bWVudChoKSxjLkFkZEltYWdlKGUpLGMuRW5kRG9jdW1lbnQoKSx0Ll9mcmVlKGMpLHQuRlMucmVhZEZpbGUoIi90ZXNzZXJhY3Qtb2NyLnBkZiIpKTpudWxsLGltYWdlQ29sb3I6ci5pbWFnZUNvbG9yP3AoaS5DT0xPUik6bnVsbCxpbWFnZUdyZXk6ci5pbWFnZUdyZXk/cChpLkdSRVkpOm51bGwsaW1hZ2VCaW5hcnk6ci5pbWFnZUJpbmFyeT9wKGkuQklOQVJZKTpudWxsLGNvbmZpZGVuY2U6YS5za2lwUmVjb2duaXRpb24/bnVsbDplLk1lYW5UZXh0Q29uZigpLGJsb2NrczpyLmJsb2NrcyYmIWEuc2tpcFJlY29nbml0aW9uP0pTT04ucGFyc2UoZS5HZXRKU09OVGV4dCgpKS5ibG9ja3M6bnVsbCxsYXlvdXRCbG9ja3M6ci5sYXlvdXRCbG9ja3MmJmEuc2tpcFJlY29nbml0aW9uP0pTT04ucGFyc2UoZS5HZXRKU09OVGV4dCgpKS5ibG9ja3M6bnVsbCxwc206bChlLkdldFBhZ2VTZWdNb2RlKCksIlBTTSIpLG9lbTpsKGUub2VtKCksIk9FTSIpLHZlcnNpb246ZS5WZXJzaW9uKCksZGVidWc6ci5kZWJ1Zz90LkZTLnJlYWRGaWxlKCIvZGVidWdJbnRlcm5hbC50eHQiLHtlbmNvZGluZzoidXRmOCIsZmxhZ3M6ImErIn0pOm51bGx9fX0sMzk4Oih0LGUscik9Pnt2YXIgbj1yKDU0NSkuaHA7ZnVuY3Rpb24gaSh0KXt0aGlzLmJ1ZmZlcj10LmRhdGEsdGhpcy53aWR0aD10LndpZHRoLHRoaXMuaGVpZ2h0PXQuaGVpZ2h0LHRoaXMuZXh0cmFCeXRlcz10aGlzLndpZHRoJTQsdGhpcy5yZ2JTaXplPXRoaXMuaGVpZ2h0KigzKnRoaXMud2lkdGgrdGhpcy5leHRyYUJ5dGVzKSx0aGlzLmhlYWRlckluZm9TaXplPTQwLHRoaXMuZGF0YT1bXSx0aGlzLmZsYWc9IkJNIix0aGlzLnJlc2VydmVkPTAsdGhpcy5vZmZzZXQ9NTQsdGhpcy5maWxlU2l6ZT10aGlzLnJnYlNpemUrdGhpcy5vZmZzZXQsdGhpcy5wbGFuZXM9MSx0aGlzLmJpdFBQPTI0LHRoaXMuY29tcHJlc3M9MCx0aGlzLmhyPTAsdGhpcy52cj0wLHRoaXMuY29sb3JzPTAsdGhpcy5pbXBvcnRhbnRDb2xvcnM9MH1pLnByb3RvdHlwZS5lbmNvZGU9ZnVuY3Rpb24oKXt2YXIgdD1uZXcgbih0aGlzLm9mZnNldCt0aGlzLnJnYlNpemUpO3RoaXMucG9zPTAsdC53cml0ZSh0aGlzLmZsYWcsdGhpcy5wb3MsMiksdGhpcy5wb3MrPTIsdC53cml0ZVVJbnQzMkxFKHRoaXMuZmlsZVNpemUsdGhpcy5wb3MpLHRoaXMucG9zKz00LHQud3JpdGVVSW50MzJMRSh0aGlzLnJlc2VydmVkLHRoaXMucG9zKSx0aGlzLnBvcys9NCx0LndyaXRlVUludDMyTEUodGhpcy5vZmZzZXQsdGhpcy5wb3MpLHRoaXMucG9zKz00LHQud3JpdGVVSW50MzJMRSh0aGlzLmhlYWRlckluZm9TaXplLHRoaXMucG9zKSx0aGlzLnBvcys9NCx0LndyaXRlVUludDMyTEUodGhpcy53aWR0aCx0aGlzLnBvcyksdGhpcy5wb3MrPTQsdC53cml0ZUludDMyTEUoLXRoaXMuaGVpZ2h0LHRoaXMucG9zKSx0aGlzLnBvcys9NCx0LndyaXRlVUludDE2TEUodGhpcy5wbGFuZXMsdGhpcy5wb3MpLHRoaXMucG9zKz0yLHQud3JpdGVVSW50MTZMRSh0aGlzLmJpdFBQLHRoaXMucG9zKSx0aGlzLnBvcys9Mix0LndyaXRlVUludDMyTEUodGhpcy5jb21wcmVzcyx0aGlzLnBvcyksdGhpcy5wb3MrPTQsdC53cml0ZVVJbnQzMkxFKHRoaXMucmdiU2l6ZSx0aGlzLnBvcyksdGhpcy5wb3MrPTQsdC53cml0ZVVJbnQzMkxFKHRoaXMuaHIsdGhpcy5wb3MpLHRoaXMucG9zKz00LHQud3JpdGVVSW50MzJMRSh0aGlzLnZyLHRoaXMucG9zKSx0aGlzLnBvcys9NCx0LndyaXRlVUludDMyTEUodGhpcy5jb2xvcnMsdGhpcy5wb3MpLHRoaXMucG9zKz00LHQud3JpdGVVSW50MzJMRSh0aGlzLmltcG9ydGFudENvbG9ycyx0aGlzLnBvcyksdGhpcy5wb3MrPTQ7Zm9yKHZhciBlPTAscj0zKnRoaXMud2lkdGgrdGhpcy5leHRyYUJ5dGVzLGk9MDtpPHRoaXMuaGVpZ2h0O2krKyl7Zm9yKHZhciBvPTA7bzx0aGlzLndpZHRoO28rKyl7dmFyIGE9dGhpcy5wb3MraSpyKzMqbztlKyssdFthXT10aGlzLmJ1ZmZlcltlKytdLHRbYSsxXT10aGlzLmJ1ZmZlcltlKytdLHRbYSsyXT10aGlzLmJ1ZmZlcltlKytdfWlmKHRoaXMuZXh0cmFCeXRlcz4wKXt2YXIgcz10aGlzLnBvcytpKnIrMyp0aGlzLndpZHRoO3QuZmlsbCgwLHMscyt0aGlzLmV4dHJhQnl0ZXMpfX1yZXR1cm4gdH0sdC5leHBvcnRzPWZ1bmN0aW9uKHQsZSl7cmV0dXJuIHZvaWQgMD09PWUmJihlPTEwMCkse2RhdGE6bmV3IGkodCkuZW5jb2RlKCksd2lkdGg6dC53aWR0aCxoZWlnaHQ6dC5oZWlnaHR9fX0sNDQzOnQ9Pnt0LmV4cG9ydHM9ZnVuY3Rpb24odCl7aWYoInN0cmluZyIhPXR5cGVvZiB0KXJldHVybiExO3ZhciBpPXQubWF0Y2goZSk7aWYoIWkpcmV0dXJuITE7dmFyIG89aVsxXTtyZXR1cm4hIW8mJiEoIXIudGVzdChvKSYmIW4udGVzdChvKSl9O3ZhciBlPS9eKD86XHcrOik/XC9cLyhcUyspJC8scj0vXmxvY2FsaG9zdFtcOj9cZF0qKD86W15cOj9cZF1cUyopPyQvLG49L15bXlxzXC5dK1wuXFN7Mix9JC99LDQ1MDoodCxlLHIpPT57dmFyIG49cigzOTgpLGk9cig4MzQpO3QuZXhwb3J0cz17ZW5jb2RlOm4sZGVjb2RlOml9fSw1MzU6dD0+eyJ1c2Ugc3RyaWN0Ijt0LmV4cG9ydHM9ZnVuY3Rpb24odCl7Zm9yKHZhciBlLHI9IiIsbj0iQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODkrLyIsaT1uZXcgVWludDhBcnJheSh0KSxvPWkuYnl0ZUxlbmd0aCxhPW8lMyxzPW8tYSx1PTA7dTxzO3UrPTMpcis9blsoMTY1MTUwNzImKGU9aVt1XTw8MTZ8aVt1KzFdPDw4fGlbdSsyXSkpPj4xOF0rblsoMjU4MDQ4JmUpPj4xMl0rblsoNDAzMiZlKT4+Nl0rbls2MyZlXTtyZXR1cm4gMT09PWE/KGU9aVtzXSxyKz0iIi5jb25jYXQoblsoMjUyJmUpPj4yXStuWygzJmUpPDw0XSwiPT0iKSk6Mj09PWEmJihlPWlbc108PDh8aVtzKzFdLHIrPSIiLmNvbmNhdChuWyg2NDUxMiZlKT4+MTBdK25bKDEwMDgmZSk+PjRdK25bKDE1JmUpPDwyXSwiPSIpKSxyfX0sNTQ1Oih0LGUscik9PnsidXNlIHN0cmljdCI7ZnVuY3Rpb24gbih0LGUpe2Zvcih2YXIgcj0wO3I8ZS5sZW5ndGg7cisrKXt2YXIgbj1lW3JdO24uZW51bWVyYWJsZT1uLmVudW1lcmFibGV8fCExLG4uY29uZmlndXJhYmxlPSEwLCJ2YWx1ZSJpbiBuJiYobi53cml0YWJsZT0hMCksT2JqZWN0LmRlZmluZVByb3BlcnR5KHQsaShuLmtleSksbil9fWZ1bmN0aW9uIGkodCl7dmFyIGU9ZnVuY3Rpb24odCl7aWYoIm9iamVjdCIhPXUodCl8fCF0KXJldHVybiB0O3ZhciBlPXRbU3ltYm9sLnRvUHJpbWl0aXZlXTtpZih2b2lkIDAhPT1lKXt2YXIgcj1lLmNhbGwodCwic3RyaW5nIik7aWYoIm9iamVjdCIhPXUocikpcmV0dXJuIHI7dGhyb3cgbmV3IFR5cGVFcnJvcigiQEB0b1ByaW1pdGl2ZSBtdXN0IHJldHVybiBhIHByaW1pdGl2ZSB2YWx1ZS4iKX1yZXR1cm4gU3RyaW5nKHQpfSh0KTtyZXR1cm4ic3ltYm9sIj09dShlKT9lOmUrIiJ9ZnVuY3Rpb24gbygpe3RyeXt2YXIgdD0hQm9vbGVhbi5wcm90b3R5cGUudmFsdWVPZi5jYWxsKFJlZmxlY3QuY29uc3RydWN0KEJvb2xlYW4sW10sKGZ1bmN0aW9uKCl7fSkpKX1jYXRjaCh0KXt9cmV0dXJuKG89ZnVuY3Rpb24oKXtyZXR1cm4hIXR9KSgpfWZ1bmN0aW9uIGEodCl7cmV0dXJuIGE9T2JqZWN0LnNldFByb3RvdHlwZU9mP09iamVjdC5nZXRQcm90b3R5cGVPZi5iaW5kKCk6ZnVuY3Rpb24odCl7cmV0dXJuIHQuX19wcm90b19ffHxPYmplY3QuZ2V0UHJvdG90eXBlT2YodCl9LGEodCl9ZnVuY3Rpb24gcyh0LGUpe3JldHVybiBzPU9iamVjdC5zZXRQcm90b3R5cGVPZj9PYmplY3Quc2V0UHJvdG90eXBlT2YuYmluZCgpOmZ1bmN0aW9uKHQsZSl7cmV0dXJuIHQuX19wcm90b19fPWUsdH0scyh0LGUpfWZ1bmN0aW9uIHUodCl7cmV0dXJuIHU9ImZ1bmN0aW9uIj09dHlwZW9mIFN5bWJvbCYmInN5bWJvbCI9PXR5cGVvZiBTeW1ib2wuaXRlcmF0b3I/ZnVuY3Rpb24odCl7cmV0dXJuIHR5cGVvZiB0fTpmdW5jdGlvbih0KXtyZXR1cm4gdCYmImZ1bmN0aW9uIj09dHlwZW9mIFN5bWJvbCYmdC5jb25zdHJ1Y3Rvcj09PVN5bWJvbCYmdCE9PVN5bWJvbC5wcm90b3R5cGU/InN5bWJvbCI6dHlwZW9mIHR9LHUodCl9dmFyIGg9cig3NjgpLGY9cig3NzMpLGM9ImZ1bmN0aW9uIj09dHlwZW9mIFN5bWJvbCYmImZ1bmN0aW9uIj09dHlwZW9mIFN5bWJvbC5mb3I/U3ltYm9sLmZvcigibm9kZWpzLnV0aWwuaW5zcGVjdC5jdXN0b20iKTpudWxsO2UuaHA9eSxlLklTPTUwO3ZhciBsPTIxNDc0ODM2NDc7ZnVuY3Rpb24gcCh0KXtpZih0PmwpdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ1RoZSB2YWx1ZSAiJyt0KyciIGlzIGludmFsaWQgZm9yIG9wdGlvbiAic2l6ZSInKTt2YXIgZT1uZXcgVWludDhBcnJheSh0KTtyZXR1cm4gT2JqZWN0LnNldFByb3RvdHlwZU9mKGUseS5wcm90b3R5cGUpLGV9ZnVuY3Rpb24geSh0LGUscil7aWYoIm51bWJlciI9PXR5cGVvZiB0KXtpZigic3RyaW5nIj09dHlwZW9mIGUpdGhyb3cgbmV3IFR5cGVFcnJvcignVGhlICJzdHJpbmciIGFyZ3VtZW50IG11c3QgYmUgb2YgdHlwZSBzdHJpbmcuIFJlY2VpdmVkIHR5cGUgbnVtYmVyJyk7cmV0dXJuIGIodCl9cmV0dXJuIGQodCxlLHIpfWZ1bmN0aW9uIGQodCxlLHIpe2lmKCJzdHJpbmciPT10eXBlb2YgdClyZXR1cm4gZnVuY3Rpb24odCxlKXtpZigic3RyaW5nIj09dHlwZW9mIGUmJiIiIT09ZXx8KGU9InV0ZjgiKSwheS5pc0VuY29kaW5nKGUpKXRocm93IG5ldyBUeXBlRXJyb3IoIlVua25vd24gZW5jb2Rpbmc6ICIrZSk7dmFyIHI9MHxBKHQsZSksbj1wKHIpLGk9bi53cml0ZSh0LGUpO3JldHVybiBpIT09ciYmKG49bi5zbGljZSgwLGkpKSxufSh0LGUpO2lmKEFycmF5QnVmZmVyLmlzVmlldyh0KSlyZXR1cm4gZnVuY3Rpb24odCl7aWYoZXQodCxVaW50OEFycmF5KSl7dmFyIGU9bmV3IFVpbnQ4QXJyYXkodCk7cmV0dXJuIHcoZS5idWZmZXIsZS5ieXRlT2Zmc2V0LGUuYnl0ZUxlbmd0aCl9cmV0dXJuIHYodCl9KHQpO2lmKG51bGw9PXQpdGhyb3cgbmV3IFR5cGVFcnJvcigiVGhlIGZpcnN0IGFyZ3VtZW50IG11c3QgYmUgb25lIG9mIHR5cGUgc3RyaW5nLCBCdWZmZXIsIEFycmF5QnVmZmVyLCBBcnJheSwgb3IgQXJyYXktbGlrZSBPYmplY3QuIFJlY2VpdmVkIHR5cGUgIit1KHQpKTtpZihldCh0LEFycmF5QnVmZmVyKXx8dCYmZXQodC5idWZmZXIsQXJyYXlCdWZmZXIpKXJldHVybiB3KHQsZSxyKTtpZigidW5kZWZpbmVkIiE9dHlwZW9mIFNoYXJlZEFycmF5QnVmZmVyJiYoZXQodCxTaGFyZWRBcnJheUJ1ZmZlcil8fHQmJmV0KHQuYnVmZmVyLFNoYXJlZEFycmF5QnVmZmVyKSkpcmV0dXJuIHcodCxlLHIpO2lmKCJudW1iZXIiPT10eXBlb2YgdCl0aHJvdyBuZXcgVHlwZUVycm9yKCdUaGUgInZhbHVlIiBhcmd1bWVudCBtdXN0IG5vdCBiZSBvZiB0eXBlIG51bWJlci4gUmVjZWl2ZWQgdHlwZSBudW1iZXInKTt2YXIgbj10LnZhbHVlT2YmJnQudmFsdWVPZigpO2lmKG51bGwhPW4mJm4hPT10KXJldHVybiB5LmZyb20obixlLHIpO3ZhciBpPWZ1bmN0aW9uKHQpe2lmKHkuaXNCdWZmZXIodCkpe3ZhciBlPTB8bSh0Lmxlbmd0aCkscj1wKGUpO3JldHVybiAwPT09ci5sZW5ndGh8fHQuY29weShyLDAsMCxlKSxyfXJldHVybiB2b2lkIDAhPT10Lmxlbmd0aD8ibnVtYmVyIiE9dHlwZW9mIHQubGVuZ3RofHxydCh0Lmxlbmd0aCk/cCgwKTp2KHQpOiJCdWZmZXIiPT09dC50eXBlJiZBcnJheS5pc0FycmF5KHQuZGF0YSk/dih0LmRhdGEpOnZvaWQgMH0odCk7aWYoaSlyZXR1cm4gaTtpZigidW5kZWZpbmVkIiE9dHlwZW9mIFN5bWJvbCYmbnVsbCE9U3ltYm9sLnRvUHJpbWl0aXZlJiYiZnVuY3Rpb24iPT10eXBlb2YgdFtTeW1ib2wudG9QcmltaXRpdmVdKXJldHVybiB5LmZyb20odFtTeW1ib2wudG9QcmltaXRpdmVdKCJzdHJpbmciKSxlLHIpO3Rocm93IG5ldyBUeXBlRXJyb3IoIlRoZSBmaXJzdCBhcmd1bWVudCBtdXN0IGJlIG9uZSBvZiB0eXBlIHN0cmluZywgQnVmZmVyLCBBcnJheUJ1ZmZlciwgQXJyYXksIG9yIEFycmF5LWxpa2UgT2JqZWN0LiBSZWNlaXZlZCB0eXBlICIrdSh0KSl9ZnVuY3Rpb24gZyh0KXtpZigibnVtYmVyIiE9dHlwZW9mIHQpdGhyb3cgbmV3IFR5cGVFcnJvcignInNpemUiIGFyZ3VtZW50IG11c3QgYmUgb2YgdHlwZSBudW1iZXInKTtpZih0PDApdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ1RoZSB2YWx1ZSAiJyt0KyciIGlzIGludmFsaWQgZm9yIG9wdGlvbiAic2l6ZSInKX1mdW5jdGlvbiBiKHQpe3JldHVybiBnKHQpLHAodDwwPzA6MHxtKHQpKX1mdW5jdGlvbiB2KHQpe2Zvcih2YXIgZT10Lmxlbmd0aDwwPzA6MHxtKHQubGVuZ3RoKSxyPXAoZSksbj0wO248ZTtuKz0xKXJbbl09MjU1JnRbbl07cmV0dXJuIHJ9ZnVuY3Rpb24gdyh0LGUscil7aWYoZTwwfHx0LmJ5dGVMZW5ndGg8ZSl0aHJvdyBuZXcgUmFuZ2VFcnJvcignIm9mZnNldCIgaXMgb3V0c2lkZSBvZiBidWZmZXIgYm91bmRzJyk7aWYodC5ieXRlTGVuZ3RoPGUrKHJ8fDApKXRocm93IG5ldyBSYW5nZUVycm9yKCcibGVuZ3RoIiBpcyBvdXRzaWRlIG9mIGJ1ZmZlciBib3VuZHMnKTt2YXIgbjtyZXR1cm4gbj12b2lkIDA9PT1lJiZ2b2lkIDA9PT1yP25ldyBVaW50OEFycmF5KHQpOnZvaWQgMD09PXI/bmV3IFVpbnQ4QXJyYXkodCxlKTpuZXcgVWludDhBcnJheSh0LGUsciksT2JqZWN0LnNldFByb3RvdHlwZU9mKG4seS5wcm90b3R5cGUpLG59ZnVuY3Rpb24gbSh0KXtpZih0Pj1sKXRocm93IG5ldyBSYW5nZUVycm9yKCJBdHRlbXB0IHRvIGFsbG9jYXRlIEJ1ZmZlciBsYXJnZXIgdGhhbiBtYXhpbXVtIHNpemU6IDB4IitsLnRvU3RyaW5nKDE2KSsiIGJ5dGVzIik7cmV0dXJuIDB8dH1mdW5jdGlvbiBBKHQsZSl7aWYoeS5pc0J1ZmZlcih0KSlyZXR1cm4gdC5sZW5ndGg7aWYoQXJyYXlCdWZmZXIuaXNWaWV3KHQpfHxldCh0LEFycmF5QnVmZmVyKSlyZXR1cm4gdC5ieXRlTGVuZ3RoO2lmKCJzdHJpbmciIT10eXBlb2YgdCl0aHJvdyBuZXcgVHlwZUVycm9yKCdUaGUgInN0cmluZyIgYXJndW1lbnQgbXVzdCBiZSBvbmUgb2YgdHlwZSBzdHJpbmcsIEJ1ZmZlciwgb3IgQXJyYXlCdWZmZXIuIFJlY2VpdmVkIHR5cGUgJyt1KHQpKTt2YXIgcj10Lmxlbmd0aCxuPWFyZ3VtZW50cy5sZW5ndGg+MiYmITA9PT1hcmd1bWVudHNbMl07aWYoIW4mJjA9PT1yKXJldHVybiAwO2Zvcih2YXIgaT0hMTs7KXN3aXRjaChlKXtjYXNlImFzY2lpIjpjYXNlImxhdGluMSI6Y2FzZSJiaW5hcnkiOnJldHVybiByO2Nhc2UidXRmOCI6Y2FzZSJ1dGYtOCI6cmV0dXJuICQodCkubGVuZ3RoO2Nhc2UidWNzMiI6Y2FzZSJ1Y3MtMiI6Y2FzZSJ1dGYxNmxlIjpjYXNlInV0Zi0xNmxlIjpyZXR1cm4gMipyO2Nhc2UiaGV4IjpyZXR1cm4gcj4+PjE7Y2FzZSJiYXNlNjQiOnJldHVybiBaKHQpLmxlbmd0aDtkZWZhdWx0OmlmKGkpcmV0dXJuIG4/LTE6JCh0KS5sZW5ndGg7ZT0oIiIrZSkudG9Mb3dlckNhc2UoKSxpPSEwfX1mdW5jdGlvbiBFKHQsZSxyKXt2YXIgbj0hMTtpZigodm9pZCAwPT09ZXx8ZTwwKSYmKGU9MCksZT50aGlzLmxlbmd0aClyZXR1cm4iIjtpZigodm9pZCAwPT09cnx8cj50aGlzLmxlbmd0aCkmJihyPXRoaXMubGVuZ3RoKSxyPD0wKXJldHVybiIiO2lmKChyPj4+PTApPD0oZT4+Pj0wKSlyZXR1cm4iIjtmb3IodHx8KHQ9InV0ZjgiKTs7KXN3aXRjaCh0KXtjYXNlImhleCI6cmV0dXJuIEModGhpcyxlLHIpO2Nhc2UidXRmOCI6Y2FzZSJ1dGYtOCI6cmV0dXJuIGoodGhpcyxlLHIpO2Nhc2UiYXNjaWkiOnJldHVybiBUKHRoaXMsZSxyKTtjYXNlImxhdGluMSI6Y2FzZSJiaW5hcnkiOnJldHVybiBSKHRoaXMsZSxyKTtjYXNlImJhc2U2NCI6cmV0dXJuIF8odGhpcyxlLHIpO2Nhc2UidWNzMiI6Y2FzZSJ1Y3MtMiI6Y2FzZSJ1dGYxNmxlIjpjYXNlInV0Zi0xNmxlIjpyZXR1cm4gTSh0aGlzLGUscik7ZGVmYXVsdDppZihuKXRocm93IG5ldyBUeXBlRXJyb3IoIlVua25vd24gZW5jb2Rpbmc6ICIrdCk7dD0odCsiIikudG9Mb3dlckNhc2UoKSxuPSEwfX1mdW5jdGlvbiBrKHQsZSxyKXt2YXIgbj10W2VdO3RbZV09dFtyXSx0W3JdPW59ZnVuY3Rpb24geCh0LGUscixuLGkpe2lmKDA9PT10Lmxlbmd0aClyZXR1cm4tMTtpZigic3RyaW5nIj09dHlwZW9mIHI/KG49cixyPTApOnI+MjE0NzQ4MzY0Nz9yPTIxNDc0ODM2NDc6cjwtMjE0NzQ4MzY0OCYmKHI9LTIxNDc0ODM2NDgpLHJ0KHI9K3IpJiYocj1pPzA6dC5sZW5ndGgtMSkscjwwJiYocj10Lmxlbmd0aCtyKSxyPj10Lmxlbmd0aCl7aWYoaSlyZXR1cm4tMTtyPXQubGVuZ3RoLTF9ZWxzZSBpZihyPDApe2lmKCFpKXJldHVybi0xO3I9MH1pZigic3RyaW5nIj09dHlwZW9mIGUmJihlPXkuZnJvbShlLG4pKSx5LmlzQnVmZmVyKGUpKXJldHVybiAwPT09ZS5sZW5ndGg/LTE6Tyh0LGUscixuLGkpO2lmKCJudW1iZXIiPT10eXBlb2YgZSlyZXR1cm4gZSY9MjU1LCJmdW5jdGlvbiI9PXR5cGVvZiBVaW50OEFycmF5LnByb3RvdHlwZS5pbmRleE9mP2k/VWludDhBcnJheS5wcm90b3R5cGUuaW5kZXhPZi5jYWxsKHQsZSxyKTpVaW50OEFycmF5LnByb3RvdHlwZS5sYXN0SW5kZXhPZi5jYWxsKHQsZSxyKTpPKHQsW2VdLHIsbixpKTt0aHJvdyBuZXcgVHlwZUVycm9yKCJ2YWwgbXVzdCBiZSBzdHJpbmcsIG51bWJlciBvciBCdWZmZXIiKX1mdW5jdGlvbiBPKHQsZSxyLG4saSl7dmFyIG8sYT0xLHM9dC5sZW5ndGgsdT1lLmxlbmd0aDtpZih2b2lkIDAhPT1uJiYoInVjczIiPT09KG49U3RyaW5nKG4pLnRvTG93ZXJDYXNlKCkpfHwidWNzLTIiPT09bnx8InV0ZjE2bGUiPT09bnx8InV0Zi0xNmxlIj09PW4pKXtpZih0Lmxlbmd0aDwyfHxlLmxlbmd0aDwyKXJldHVybi0xO2E9MixzLz0yLHUvPTIsci89Mn1mdW5jdGlvbiBoKHQsZSl7cmV0dXJuIDE9PT1hP3RbZV06dC5yZWFkVUludDE2QkUoZSphKX1pZihpKXt2YXIgZj0tMTtmb3Iobz1yO288cztvKyspaWYoaCh0LG8pPT09aChlLC0xPT09Zj8wOm8tZikpe2lmKC0xPT09ZiYmKGY9byksby1mKzE9PT11KXJldHVybiBmKmF9ZWxzZS0xIT09ZiYmKG8tPW8tZiksZj0tMX1lbHNlIGZvcihyK3U+cyYmKHI9cy11KSxvPXI7bz49MDtvLS0pe2Zvcih2YXIgYz0hMCxsPTA7bDx1O2wrKylpZihoKHQsbytsKSE9PWgoZSxsKSl7Yz0hMTticmVha31pZihjKXJldHVybiBvfXJldHVybi0xfWZ1bmN0aW9uIEkodCxlLHIsbil7cj1OdW1iZXIocil8fDA7dmFyIGk9dC5sZW5ndGgtcjtuPyhuPU51bWJlcihuKSk+aSYmKG49aSk6bj1pO3ZhciBvLGE9ZS5sZW5ndGg7Zm9yKG4+YS8yJiYobj1hLzIpLG89MDtvPG47KytvKXt2YXIgcz1wYXJzZUludChlLnN1YnN0cigyKm8sMiksMTYpO2lmKHJ0KHMpKXJldHVybiBvO3RbcitvXT1zfXJldHVybiBvfWZ1bmN0aW9uIFUodCxlLHIsbil7cmV0dXJuIHR0KCQoZSx0Lmxlbmd0aC1yKSx0LHIsbil9ZnVuY3Rpb24gUyh0LGUscixuKXtyZXR1cm4gdHQoZnVuY3Rpb24odCl7Zm9yKHZhciBlPVtdLHI9MDtyPHQubGVuZ3RoOysrcillLnB1c2goMjU1JnQuY2hhckNvZGVBdChyKSk7cmV0dXJuIGV9KGUpLHQscixuKX1mdW5jdGlvbiBMKHQsZSxyLG4pe3JldHVybiB0dChaKGUpLHQscixuKX1mdW5jdGlvbiBCKHQsZSxyLG4pe3JldHVybiB0dChmdW5jdGlvbih0LGUpe2Zvcih2YXIgcixuLGksbz1bXSxhPTA7YTx0Lmxlbmd0aCYmISgoZS09Mik8MCk7KythKW49KHI9dC5jaGFyQ29kZUF0KGEpKT4+OCxpPXIlMjU2LG8ucHVzaChpKSxvLnB1c2gobik7cmV0dXJuIG99KGUsdC5sZW5ndGgtciksdCxyLG4pfWZ1bmN0aW9uIF8odCxlLHIpe3JldHVybiAwPT09ZSYmcj09PXQubGVuZ3RoP2guZnJvbUJ5dGVBcnJheSh0KTpoLmZyb21CeXRlQXJyYXkodC5zbGljZShlLHIpKX1mdW5jdGlvbiBqKHQsZSxyKXtyPU1hdGgubWluKHQubGVuZ3RoLHIpO2Zvcih2YXIgbj1bXSxpPWU7aTxyOyl7dmFyIG89dFtpXSxhPW51bGwscz1vPjIzOT80Om8+MjIzPzM6bz4xOTE/MjoxO2lmKGkrczw9cil7dmFyIHU9dm9pZCAwLGg9dm9pZCAwLGY9dm9pZCAwLGM9dm9pZCAwO3N3aXRjaChzKXtjYXNlIDE6bzwxMjgmJihhPW8pO2JyZWFrO2Nhc2UgMjoxMjg9PSgxOTImKHU9dFtpKzFdKSkmJihjPSgzMSZvKTw8Nnw2MyZ1KT4xMjcmJihhPWMpO2JyZWFrO2Nhc2UgMzp1PXRbaSsxXSxoPXRbaSsyXSwxMjg9PSgxOTImdSkmJjEyOD09KDE5MiZoKSYmKGM9KDE1Jm8pPDwxMnwoNjMmdSk8PDZ8NjMmaCk+MjA0NyYmKGM8NTUyOTZ8fGM+NTczNDMpJiYoYT1jKTticmVhaztjYXNlIDQ6dT10W2krMV0saD10W2krMl0sZj10W2krM10sMTI4PT0oMTkyJnUpJiYxMjg9PSgxOTImaCkmJjEyOD09KDE5MiZmKSYmKGM9KDE1Jm8pPDwxOHwoNjMmdSk8PDEyfCg2MyZoKTw8Nnw2MyZmKT42NTUzNSYmYzwxMTE0MTEyJiYoYT1jKX19bnVsbD09PWE/KGE9NjU1MzMscz0xKTphPjY1NTM1JiYoYS09NjU1MzYsbi5wdXNoKGE+Pj4xMCYxMDIzfDU1Mjk2KSxhPTU2MzIwfDEwMjMmYSksbi5wdXNoKGEpLGkrPXN9cmV0dXJuIGZ1bmN0aW9uKHQpe3ZhciBlPXQubGVuZ3RoO2lmKGU8PVApcmV0dXJuIFN0cmluZy5mcm9tQ2hhckNvZGUuYXBwbHkoU3RyaW5nLHQpO2Zvcih2YXIgcj0iIixuPTA7bjxlOylyKz1TdHJpbmcuZnJvbUNoYXJDb2RlLmFwcGx5KFN0cmluZyx0LnNsaWNlKG4sbis9UCkpO3JldHVybiByfShuKX15LlRZUEVEX0FSUkFZX1NVUFBPUlQ9ZnVuY3Rpb24oKXt0cnl7dmFyIHQ9bmV3IFVpbnQ4QXJyYXkoMSksZT17Zm9vOmZ1bmN0aW9uKCl7cmV0dXJuIDQyfX07cmV0dXJuIE9iamVjdC5zZXRQcm90b3R5cGVPZihlLFVpbnQ4QXJyYXkucHJvdG90eXBlKSxPYmplY3Quc2V0UHJvdG90eXBlT2YodCxlKSw0Mj09PXQuZm9vKCl9Y2F0Y2godCl7cmV0dXJuITF9fSgpLHkuVFlQRURfQVJSQVlfU1VQUE9SVHx8InVuZGVmaW5lZCI9PXR5cGVvZiBjb25zb2xlfHwiZnVuY3Rpb24iIT10eXBlb2YgY29uc29sZS5lcnJvcnx8Y29uc29sZS5lcnJvcigiVGhpcyBicm93c2VyIGxhY2tzIHR5cGVkIGFycmF5IChVaW50OEFycmF5KSBzdXBwb3J0IHdoaWNoIGlzIHJlcXVpcmVkIGJ5IGBidWZmZXJgIHY1LnguIFVzZSBgYnVmZmVyYCB2NC54IGlmIHlvdSByZXF1aXJlIG9sZCBicm93c2VyIHN1cHBvcnQuIiksT2JqZWN0LmRlZmluZVByb3BlcnR5KHkucHJvdG90eXBlLCJwYXJlbnQiLHtlbnVtZXJhYmxlOiEwLGdldDpmdW5jdGlvbigpe2lmKHkuaXNCdWZmZXIodGhpcykpcmV0dXJuIHRoaXMuYnVmZmVyfX0pLE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh5LnByb3RvdHlwZSwib2Zmc2V0Iix7ZW51bWVyYWJsZTohMCxnZXQ6ZnVuY3Rpb24oKXtpZih5LmlzQnVmZmVyKHRoaXMpKXJldHVybiB0aGlzLmJ5dGVPZmZzZXR9fSkseS5wb29sU2l6ZT04MTkyLHkuZnJvbT1mdW5jdGlvbih0LGUscil7cmV0dXJuIGQodCxlLHIpfSxPYmplY3Quc2V0UHJvdG90eXBlT2YoeS5wcm90b3R5cGUsVWludDhBcnJheS5wcm90b3R5cGUpLE9iamVjdC5zZXRQcm90b3R5cGVPZih5LFVpbnQ4QXJyYXkpLHkuYWxsb2M9ZnVuY3Rpb24odCxlLHIpe3JldHVybiBmdW5jdGlvbih0LGUscil7cmV0dXJuIGcodCksdDw9MD9wKHQpOnZvaWQgMCE9PWU/InN0cmluZyI9PXR5cGVvZiByP3AodCkuZmlsbChlLHIpOnAodCkuZmlsbChlKTpwKHQpfSh0LGUscil9LHkuYWxsb2NVbnNhZmU9ZnVuY3Rpb24odCl7cmV0dXJuIGIodCl9LHkuYWxsb2NVbnNhZmVTbG93PWZ1bmN0aW9uKHQpe3JldHVybiBiKHQpfSx5LmlzQnVmZmVyPWZ1bmN0aW9uKHQpe3JldHVybiBudWxsIT10JiYhMD09PXQuX2lzQnVmZmVyJiZ0IT09eS5wcm90b3R5cGV9LHkuY29tcGFyZT1mdW5jdGlvbih0LGUpe2lmKGV0KHQsVWludDhBcnJheSkmJih0PXkuZnJvbSh0LHQub2Zmc2V0LHQuYnl0ZUxlbmd0aCkpLGV0KGUsVWludDhBcnJheSkmJihlPXkuZnJvbShlLGUub2Zmc2V0LGUuYnl0ZUxlbmd0aCkpLCF5LmlzQnVmZmVyKHQpfHwheS5pc0J1ZmZlcihlKSl0aHJvdyBuZXcgVHlwZUVycm9yKCdUaGUgImJ1ZjEiLCAiYnVmMiIgYXJndW1lbnRzIG11c3QgYmUgb25lIG9mIHR5cGUgQnVmZmVyIG9yIFVpbnQ4QXJyYXknKTtpZih0PT09ZSlyZXR1cm4gMDtmb3IodmFyIHI9dC5sZW5ndGgsbj1lLmxlbmd0aCxpPTAsbz1NYXRoLm1pbihyLG4pO2k8bzsrK2kpaWYodFtpXSE9PWVbaV0pe3I9dFtpXSxuPWVbaV07YnJlYWt9cmV0dXJuIHI8bj8tMTpuPHI/MTowfSx5LmlzRW5jb2Rpbmc9ZnVuY3Rpb24odCl7c3dpdGNoKFN0cmluZyh0KS50b0xvd2VyQ2FzZSgpKXtjYXNlImhleCI6Y2FzZSJ1dGY4IjpjYXNlInV0Zi04IjpjYXNlImFzY2lpIjpjYXNlImxhdGluMSI6Y2FzZSJiaW5hcnkiOmNhc2UiYmFzZTY0IjpjYXNlInVjczIiOmNhc2UidWNzLTIiOmNhc2UidXRmMTZsZSI6Y2FzZSJ1dGYtMTZsZSI6cmV0dXJuITA7ZGVmYXVsdDpyZXR1cm4hMX19LHkuY29uY2F0PWZ1bmN0aW9uKHQsZSl7aWYoIUFycmF5LmlzQXJyYXkodCkpdGhyb3cgbmV3IFR5cGVFcnJvcignImxpc3QiIGFyZ3VtZW50IG11c3QgYmUgYW4gQXJyYXkgb2YgQnVmZmVycycpO2lmKDA9PT10Lmxlbmd0aClyZXR1cm4geS5hbGxvYygwKTt2YXIgcjtpZih2b2lkIDA9PT1lKWZvcihlPTAscj0wO3I8dC5sZW5ndGg7KytyKWUrPXRbcl0ubGVuZ3RoO3ZhciBuPXkuYWxsb2NVbnNhZmUoZSksaT0wO2ZvcihyPTA7cjx0Lmxlbmd0aDsrK3Ipe3ZhciBvPXRbcl07aWYoZXQobyxVaW50OEFycmF5KSlpK28ubGVuZ3RoPm4ubGVuZ3RoPyh5LmlzQnVmZmVyKG8pfHwobz15LmZyb20obykpLG8uY29weShuLGkpKTpVaW50OEFycmF5LnByb3RvdHlwZS5zZXQuY2FsbChuLG8saSk7ZWxzZXtpZigheS5pc0J1ZmZlcihvKSl0aHJvdyBuZXcgVHlwZUVycm9yKCcibGlzdCIgYXJndW1lbnQgbXVzdCBiZSBhbiBBcnJheSBvZiBCdWZmZXJzJyk7by5jb3B5KG4saSl9aSs9by5sZW5ndGh9cmV0dXJuIG59LHkuYnl0ZUxlbmd0aD1BLHkucHJvdG90eXBlLl9pc0J1ZmZlcj0hMCx5LnByb3RvdHlwZS5zd2FwMTY9ZnVuY3Rpb24oKXt2YXIgdD10aGlzLmxlbmd0aDtpZih0JTIhPTApdGhyb3cgbmV3IFJhbmdlRXJyb3IoIkJ1ZmZlciBzaXplIG11c3QgYmUgYSBtdWx0aXBsZSBvZiAxNi1iaXRzIik7Zm9yKHZhciBlPTA7ZTx0O2UrPTIpayh0aGlzLGUsZSsxKTtyZXR1cm4gdGhpc30seS5wcm90b3R5cGUuc3dhcDMyPWZ1bmN0aW9uKCl7dmFyIHQ9dGhpcy5sZW5ndGg7aWYodCU0IT0wKXRocm93IG5ldyBSYW5nZUVycm9yKCJCdWZmZXIgc2l6ZSBtdXN0IGJlIGEgbXVsdGlwbGUgb2YgMzItYml0cyIpO2Zvcih2YXIgZT0wO2U8dDtlKz00KWsodGhpcyxlLGUrMyksayh0aGlzLGUrMSxlKzIpO3JldHVybiB0aGlzfSx5LnByb3RvdHlwZS5zd2FwNjQ9ZnVuY3Rpb24oKXt2YXIgdD10aGlzLmxlbmd0aDtpZih0JTghPTApdGhyb3cgbmV3IFJhbmdlRXJyb3IoIkJ1ZmZlciBzaXplIG11c3QgYmUgYSBtdWx0aXBsZSBvZiA2NC1iaXRzIik7Zm9yKHZhciBlPTA7ZTx0O2UrPTgpayh0aGlzLGUsZSs3KSxrKHRoaXMsZSsxLGUrNiksayh0aGlzLGUrMixlKzUpLGsodGhpcyxlKzMsZSs0KTtyZXR1cm4gdGhpc30seS5wcm90b3R5cGUudG9TdHJpbmc9ZnVuY3Rpb24oKXt2YXIgdD10aGlzLmxlbmd0aDtyZXR1cm4gMD09PXQ/IiI6MD09PWFyZ3VtZW50cy5sZW5ndGg/aih0aGlzLDAsdCk6RS5hcHBseSh0aGlzLGFyZ3VtZW50cyl9LHkucHJvdG90eXBlLnRvTG9jYWxlU3RyaW5nPXkucHJvdG90eXBlLnRvU3RyaW5nLHkucHJvdG90eXBlLmVxdWFscz1mdW5jdGlvbih0KXtpZigheS5pc0J1ZmZlcih0KSl0aHJvdyBuZXcgVHlwZUVycm9yKCJBcmd1bWVudCBtdXN0IGJlIGEgQnVmZmVyIik7cmV0dXJuIHRoaXM9PT10fHwwPT09eS5jb21wYXJlKHRoaXMsdCl9LHkucHJvdG90eXBlLmluc3BlY3Q9ZnVuY3Rpb24oKXt2YXIgdD0iIixyPWUuSVM7cmV0dXJuIHQ9dGhpcy50b1N0cmluZygiaGV4IiwwLHIpLnJlcGxhY2UoLyguezJ9KS9nLCIkMSAiKS50cmltKCksdGhpcy5sZW5ndGg+ciYmKHQrPSIgLi4uICIpLCI8QnVmZmVyICIrdCsiPiJ9LGMmJih5LnByb3RvdHlwZVtjXT15LnByb3RvdHlwZS5pbnNwZWN0KSx5LnByb3RvdHlwZS5jb21wYXJlPWZ1bmN0aW9uKHQsZSxyLG4saSl7aWYoZXQodCxVaW50OEFycmF5KSYmKHQ9eS5mcm9tKHQsdC5vZmZzZXQsdC5ieXRlTGVuZ3RoKSksIXkuaXNCdWZmZXIodCkpdGhyb3cgbmV3IFR5cGVFcnJvcignVGhlICJ0YXJnZXQiIGFyZ3VtZW50IG11c3QgYmUgb25lIG9mIHR5cGUgQnVmZmVyIG9yIFVpbnQ4QXJyYXkuIFJlY2VpdmVkIHR5cGUgJyt1KHQpKTtpZih2b2lkIDA9PT1lJiYoZT0wKSx2b2lkIDA9PT1yJiYocj10P3QubGVuZ3RoOjApLHZvaWQgMD09PW4mJihuPTApLHZvaWQgMD09PWkmJihpPXRoaXMubGVuZ3RoKSxlPDB8fHI+dC5sZW5ndGh8fG48MHx8aT50aGlzLmxlbmd0aCl0aHJvdyBuZXcgUmFuZ2VFcnJvcigib3V0IG9mIHJhbmdlIGluZGV4Iik7aWYobj49aSYmZT49cilyZXR1cm4gMDtpZihuPj1pKXJldHVybi0xO2lmKGU+PXIpcmV0dXJuIDE7aWYodGhpcz09PXQpcmV0dXJuIDA7Zm9yKHZhciBvPShpPj4+PTApLShuPj4+PTApLGE9KHI+Pj49MCktKGU+Pj49MCkscz1NYXRoLm1pbihvLGEpLGg9dGhpcy5zbGljZShuLGkpLGY9dC5zbGljZShlLHIpLGM9MDtjPHM7KytjKWlmKGhbY10hPT1mW2NdKXtvPWhbY10sYT1mW2NdO2JyZWFrfXJldHVybiBvPGE/LTE6YTxvPzE6MH0seS5wcm90b3R5cGUuaW5jbHVkZXM9ZnVuY3Rpb24odCxlLHIpe3JldHVybi0xIT09dGhpcy5pbmRleE9mKHQsZSxyKX0seS5wcm90b3R5cGUuaW5kZXhPZj1mdW5jdGlvbih0LGUscil7cmV0dXJuIHgodGhpcyx0LGUsciwhMCl9LHkucHJvdG90eXBlLmxhc3RJbmRleE9mPWZ1bmN0aW9uKHQsZSxyKXtyZXR1cm4geCh0aGlzLHQsZSxyLCExKX0seS5wcm90b3R5cGUud3JpdGU9ZnVuY3Rpb24odCxlLHIsbil7aWYodm9pZCAwPT09ZSluPSJ1dGY4IixyPXRoaXMubGVuZ3RoLGU9MDtlbHNlIGlmKHZvaWQgMD09PXImJiJzdHJpbmciPT10eXBlb2YgZSluPWUscj10aGlzLmxlbmd0aCxlPTA7ZWxzZXtpZighaXNGaW5pdGUoZSkpdGhyb3cgbmV3IEVycm9yKCJCdWZmZXIud3JpdGUoc3RyaW5nLCBlbmNvZGluZywgb2Zmc2V0WywgbGVuZ3RoXSkgaXMgbm8gbG9uZ2VyIHN1cHBvcnRlZCIpO2U+Pj49MCxpc0Zpbml0ZShyKT8ocj4+Pj0wLHZvaWQgMD09PW4mJihuPSJ1dGY4IikpOihuPXIscj12b2lkIDApfXZhciBpPXRoaXMubGVuZ3RoLWU7aWYoKHZvaWQgMD09PXJ8fHI+aSkmJihyPWkpLHQubGVuZ3RoPjAmJihyPDB8fGU8MCl8fGU+dGhpcy5sZW5ndGgpdGhyb3cgbmV3IFJhbmdlRXJyb3IoIkF0dGVtcHQgdG8gd3JpdGUgb3V0c2lkZSBidWZmZXIgYm91bmRzIik7bnx8KG49InV0ZjgiKTtmb3IodmFyIG89ITE7Oylzd2l0Y2gobil7Y2FzZSJoZXgiOnJldHVybiBJKHRoaXMsdCxlLHIpO2Nhc2UidXRmOCI6Y2FzZSJ1dGYtOCI6cmV0dXJuIFUodGhpcyx0LGUscik7Y2FzZSJhc2NpaSI6Y2FzZSJsYXRpbjEiOmNhc2UiYmluYXJ5IjpyZXR1cm4gUyh0aGlzLHQsZSxyKTtjYXNlImJhc2U2NCI6cmV0dXJuIEwodGhpcyx0LGUscik7Y2FzZSJ1Y3MyIjpjYXNlInVjcy0yIjpjYXNlInV0ZjE2bGUiOmNhc2UidXRmLTE2bGUiOnJldHVybiBCKHRoaXMsdCxlLHIpO2RlZmF1bHQ6aWYobyl0aHJvdyBuZXcgVHlwZUVycm9yKCJVbmtub3duIGVuY29kaW5nOiAiK24pO249KCIiK24pLnRvTG93ZXJDYXNlKCksbz0hMH19LHkucHJvdG90eXBlLnRvSlNPTj1mdW5jdGlvbigpe3JldHVybnt0eXBlOiJCdWZmZXIiLGRhdGE6QXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwodGhpcy5fYXJyfHx0aGlzLDApfX07dmFyIFA9NDA5NjtmdW5jdGlvbiBUKHQsZSxyKXt2YXIgbj0iIjtyPU1hdGgubWluKHQubGVuZ3RoLHIpO2Zvcih2YXIgaT1lO2k8cjsrK2kpbis9U3RyaW5nLmZyb21DaGFyQ29kZSgxMjcmdFtpXSk7cmV0dXJuIG59ZnVuY3Rpb24gUih0LGUscil7dmFyIG49IiI7cj1NYXRoLm1pbih0Lmxlbmd0aCxyKTtmb3IodmFyIGk9ZTtpPHI7KytpKW4rPVN0cmluZy5mcm9tQ2hhckNvZGUodFtpXSk7cmV0dXJuIG59ZnVuY3Rpb24gQyh0LGUscil7dmFyIG49dC5sZW5ndGg7KCFlfHxlPDApJiYoZT0wKSwoIXJ8fHI8MHx8cj5uKSYmKHI9bik7Zm9yKHZhciBpPSIiLG89ZTtvPHI7KytvKWkrPW50W3Rbb11dO3JldHVybiBpfWZ1bmN0aW9uIE0odCxlLHIpe2Zvcih2YXIgbj10LnNsaWNlKGUsciksaT0iIixvPTA7bzxuLmxlbmd0aC0xO28rPTIpaSs9U3RyaW5nLmZyb21DaGFyQ29kZShuW29dKzI1NipuW28rMV0pO3JldHVybiBpfWZ1bmN0aW9uIE4odCxlLHIpe2lmKHQlMSE9MHx8dDwwKXRocm93IG5ldyBSYW5nZUVycm9yKCJvZmZzZXQgaXMgbm90IHVpbnQiKTtpZih0K2U+cil0aHJvdyBuZXcgUmFuZ2VFcnJvcigiVHJ5aW5nIHRvIGFjY2VzcyBiZXlvbmQgYnVmZmVyIGxlbmd0aCIpfWZ1bmN0aW9uIEYodCxlLHIsbixpLG8pe2lmKCF5LmlzQnVmZmVyKHQpKXRocm93IG5ldyBUeXBlRXJyb3IoJyJidWZmZXIiIGFyZ3VtZW50IG11c3QgYmUgYSBCdWZmZXIgaW5zdGFuY2UnKTtpZihlPml8fGU8byl0aHJvdyBuZXcgUmFuZ2VFcnJvcignInZhbHVlIiBhcmd1bWVudCBpcyBvdXQgb2YgYm91bmRzJyk7aWYocituPnQubGVuZ3RoKXRocm93IG5ldyBSYW5nZUVycm9yKCJJbmRleCBvdXQgb2YgcmFuZ2UiKX1mdW5jdGlvbiBHKHQsZSxyLG4saSl7UShlLG4saSx0LHIsNyk7dmFyIG89TnVtYmVyKGUmQmlnSW50KDQyOTQ5NjcyOTUpKTt0W3IrK109byxvPj49OCx0W3IrK109byxvPj49OCx0W3IrK109byxvPj49OCx0W3IrK109bzt2YXIgYT1OdW1iZXIoZT4+QmlnSW50KDMyKSZCaWdJbnQoNDI5NDk2NzI5NSkpO3JldHVybiB0W3IrK109YSxhPj49OCx0W3IrK109YSxhPj49OCx0W3IrK109YSxhPj49OCx0W3IrK109YSxyfWZ1bmN0aW9uIHoodCxlLHIsbixpKXtRKGUsbixpLHQsciw3KTt2YXIgbz1OdW1iZXIoZSZCaWdJbnQoNDI5NDk2NzI5NSkpO3Rbcis3XT1vLG8+Pj04LHRbcis2XT1vLG8+Pj04LHRbcis1XT1vLG8+Pj04LHRbcis0XT1vO3ZhciBhPU51bWJlcihlPj5CaWdJbnQoMzIpJkJpZ0ludCg0Mjk0OTY3Mjk1KSk7cmV0dXJuIHRbciszXT1hLGE+Pj04LHRbcisyXT1hLGE+Pj04LHRbcisxXT1hLGE+Pj04LHRbcl09YSxyKzh9ZnVuY3Rpb24gRCh0LGUscixuLGksbyl7aWYocituPnQubGVuZ3RoKXRocm93IG5ldyBSYW5nZUVycm9yKCJJbmRleCBvdXQgb2YgcmFuZ2UiKTtpZihyPDApdGhyb3cgbmV3IFJhbmdlRXJyb3IoIkluZGV4IG91dCBvZiByYW5nZSIpfWZ1bmN0aW9uIFcodCxlLHIsbixpKXtyZXR1cm4gZT0rZSxyPj4+PTAsaXx8RCh0LDAsciw0KSxmLndyaXRlKHQsZSxyLG4sMjMsNCkscis0fWZ1bmN0aW9uIFkodCxlLHIsbixpKXtyZXR1cm4gZT0rZSxyPj4+PTAsaXx8RCh0LDAsciw4KSxmLndyaXRlKHQsZSxyLG4sNTIsOCkscis4fXkucHJvdG90eXBlLnNsaWNlPWZ1bmN0aW9uKHQsZSl7dmFyIHI9dGhpcy5sZW5ndGg7KHQ9fn50KTwwPyh0Kz1yKTwwJiYodD0wKTp0PnImJih0PXIpLChlPXZvaWQgMD09PWU/cjp+fmUpPDA/KGUrPXIpPDAmJihlPTApOmU+ciYmKGU9ciksZTx0JiYoZT10KTt2YXIgbj10aGlzLnN1YmFycmF5KHQsZSk7cmV0dXJuIE9iamVjdC5zZXRQcm90b3R5cGVPZihuLHkucHJvdG90eXBlKSxufSx5LnByb3RvdHlwZS5yZWFkVWludExFPXkucHJvdG90eXBlLnJlYWRVSW50TEU9ZnVuY3Rpb24odCxlLHIpe3Q+Pj49MCxlPj4+PTAscnx8Tih0LGUsdGhpcy5sZW5ndGgpO2Zvcih2YXIgbj10aGlzW3RdLGk9MSxvPTA7KytvPGUmJihpKj0yNTYpOyluKz10aGlzW3Qrb10qaTtyZXR1cm4gbn0seS5wcm90b3R5cGUucmVhZFVpbnRCRT15LnByb3RvdHlwZS5yZWFkVUludEJFPWZ1bmN0aW9uKHQsZSxyKXt0Pj4+PTAsZT4+Pj0wLHJ8fE4odCxlLHRoaXMubGVuZ3RoKTtmb3IodmFyIG49dGhpc1t0Ky0tZV0saT0xO2U+MCYmKGkqPTI1Nik7KW4rPXRoaXNbdCstLWVdKmk7cmV0dXJuIG59LHkucHJvdG90eXBlLnJlYWRVaW50OD15LnByb3RvdHlwZS5yZWFkVUludDg9ZnVuY3Rpb24odCxlKXtyZXR1cm4gdD4+Pj0wLGV8fE4odCwxLHRoaXMubGVuZ3RoKSx0aGlzW3RdfSx5LnByb3RvdHlwZS5yZWFkVWludDE2TEU9eS5wcm90b3R5cGUucmVhZFVJbnQxNkxFPWZ1bmN0aW9uKHQsZSl7cmV0dXJuIHQ+Pj49MCxlfHxOKHQsMix0aGlzLmxlbmd0aCksdGhpc1t0XXx0aGlzW3QrMV08PDh9LHkucHJvdG90eXBlLnJlYWRVaW50MTZCRT15LnByb3RvdHlwZS5yZWFkVUludDE2QkU9ZnVuY3Rpb24odCxlKXtyZXR1cm4gdD4+Pj0wLGV8fE4odCwyLHRoaXMubGVuZ3RoKSx0aGlzW3RdPDw4fHRoaXNbdCsxXX0seS5wcm90b3R5cGUucmVhZFVpbnQzMkxFPXkucHJvdG90eXBlLnJlYWRVSW50MzJMRT1mdW5jdGlvbih0LGUpe3JldHVybiB0Pj4+PTAsZXx8Tih0LDQsdGhpcy5sZW5ndGgpLCh0aGlzW3RdfHRoaXNbdCsxXTw8OHx0aGlzW3QrMl08PDE2KSsxNjc3NzIxNip0aGlzW3QrM119LHkucHJvdG90eXBlLnJlYWRVaW50MzJCRT15LnByb3RvdHlwZS5yZWFkVUludDMyQkU9ZnVuY3Rpb24odCxlKXtyZXR1cm4gdD4+Pj0wLGV8fE4odCw0LHRoaXMubGVuZ3RoKSwxNjc3NzIxNip0aGlzW3RdKyh0aGlzW3QrMV08PDE2fHRoaXNbdCsyXTw8OHx0aGlzW3QrM10pfSx5LnByb3RvdHlwZS5yZWFkQmlnVUludDY0TEU9aXQoKGZ1bmN0aW9uKHQpe1godD4+Pj0wLCJvZmZzZXQiKTt2YXIgZT10aGlzW3RdLHI9dGhpc1t0KzddO3ZvaWQgMCE9PWUmJnZvaWQgMCE9PXJ8fEgodCx0aGlzLmxlbmd0aC04KTt2YXIgbj1lK3RoaXNbKyt0XSpNYXRoLnBvdygyLDgpK3RoaXNbKyt0XSpNYXRoLnBvdygyLDE2KSt0aGlzWysrdF0qTWF0aC5wb3coMiwyNCksaT10aGlzWysrdF0rdGhpc1srK3RdKk1hdGgucG93KDIsOCkrdGhpc1srK3RdKk1hdGgucG93KDIsMTYpK3IqTWF0aC5wb3coMiwyNCk7cmV0dXJuIEJpZ0ludChuKSsoQmlnSW50KGkpPDxCaWdJbnQoMzIpKX0pKSx5LnByb3RvdHlwZS5yZWFkQmlnVUludDY0QkU9aXQoKGZ1bmN0aW9uKHQpe1godD4+Pj0wLCJvZmZzZXQiKTt2YXIgZT10aGlzW3RdLHI9dGhpc1t0KzddO3ZvaWQgMCE9PWUmJnZvaWQgMCE9PXJ8fEgodCx0aGlzLmxlbmd0aC04KTt2YXIgbj1lKk1hdGgucG93KDIsMjQpK3RoaXNbKyt0XSpNYXRoLnBvdygyLDE2KSt0aGlzWysrdF0qTWF0aC5wb3coMiw4KSt0aGlzWysrdF0saT10aGlzWysrdF0qTWF0aC5wb3coMiwyNCkrdGhpc1srK3RdKk1hdGgucG93KDIsMTYpK3RoaXNbKyt0XSpNYXRoLnBvdygyLDgpK3I7cmV0dXJuKEJpZ0ludChuKTw8QmlnSW50KDMyKSkrQmlnSW50KGkpfSkpLHkucHJvdG90eXBlLnJlYWRJbnRMRT1mdW5jdGlvbih0LGUscil7dD4+Pj0wLGU+Pj49MCxyfHxOKHQsZSx0aGlzLmxlbmd0aCk7Zm9yKHZhciBuPXRoaXNbdF0saT0xLG89MDsrK288ZSYmKGkqPTI1Nik7KW4rPXRoaXNbdCtvXSppO3JldHVybiBuPj0oaSo9MTI4KSYmKG4tPU1hdGgucG93KDIsOCplKSksbn0seS5wcm90b3R5cGUucmVhZEludEJFPWZ1bmN0aW9uKHQsZSxyKXt0Pj4+PTAsZT4+Pj0wLHJ8fE4odCxlLHRoaXMubGVuZ3RoKTtmb3IodmFyIG49ZSxpPTEsbz10aGlzW3QrLS1uXTtuPjAmJihpKj0yNTYpOylvKz10aGlzW3QrLS1uXSppO3JldHVybiBvPj0oaSo9MTI4KSYmKG8tPU1hdGgucG93KDIsOCplKSksb30seS5wcm90b3R5cGUucmVhZEludDg9ZnVuY3Rpb24odCxlKXtyZXR1cm4gdD4+Pj0wLGV8fE4odCwxLHRoaXMubGVuZ3RoKSwxMjgmdGhpc1t0XT8tMSooMjU1LXRoaXNbdF0rMSk6dGhpc1t0XX0seS5wcm90b3R5cGUucmVhZEludDE2TEU9ZnVuY3Rpb24odCxlKXt0Pj4+PTAsZXx8Tih0LDIsdGhpcy5sZW5ndGgpO3ZhciByPXRoaXNbdF18dGhpc1t0KzFdPDw4O3JldHVybiAzMjc2OCZyPzQyOTQ5MDE3NjB8cjpyfSx5LnByb3RvdHlwZS5yZWFkSW50MTZCRT1mdW5jdGlvbih0LGUpe3Q+Pj49MCxlfHxOKHQsMix0aGlzLmxlbmd0aCk7dmFyIHI9dGhpc1t0KzFdfHRoaXNbdF08PDg7cmV0dXJuIDMyNzY4JnI/NDI5NDkwMTc2MHxyOnJ9LHkucHJvdG90eXBlLnJlYWRJbnQzMkxFPWZ1bmN0aW9uKHQsZSl7cmV0dXJuIHQ+Pj49MCxlfHxOKHQsNCx0aGlzLmxlbmd0aCksdGhpc1t0XXx0aGlzW3QrMV08PDh8dGhpc1t0KzJdPDwxNnx0aGlzW3QrM108PDI0fSx5LnByb3RvdHlwZS5yZWFkSW50MzJCRT1mdW5jdGlvbih0LGUpe3JldHVybiB0Pj4+PTAsZXx8Tih0LDQsdGhpcy5sZW5ndGgpLHRoaXNbdF08PDI0fHRoaXNbdCsxXTw8MTZ8dGhpc1t0KzJdPDw4fHRoaXNbdCszXX0seS5wcm90b3R5cGUucmVhZEJpZ0ludDY0TEU9aXQoKGZ1bmN0aW9uKHQpe1godD4+Pj0wLCJvZmZzZXQiKTt2YXIgZT10aGlzW3RdLHI9dGhpc1t0KzddO3ZvaWQgMCE9PWUmJnZvaWQgMCE9PXJ8fEgodCx0aGlzLmxlbmd0aC04KTt2YXIgbj10aGlzW3QrNF0rdGhpc1t0KzVdKk1hdGgucG93KDIsOCkrdGhpc1t0KzZdKk1hdGgucG93KDIsMTYpKyhyPDwyNCk7cmV0dXJuKEJpZ0ludChuKTw8QmlnSW50KDMyKSkrQmlnSW50KGUrdGhpc1srK3RdKk1hdGgucG93KDIsOCkrdGhpc1srK3RdKk1hdGgucG93KDIsMTYpK3RoaXNbKyt0XSpNYXRoLnBvdygyLDI0KSl9KSkseS5wcm90b3R5cGUucmVhZEJpZ0ludDY0QkU9aXQoKGZ1bmN0aW9uKHQpe1godD4+Pj0wLCJvZmZzZXQiKTt2YXIgZT10aGlzW3RdLHI9dGhpc1t0KzddO3ZvaWQgMCE9PWUmJnZvaWQgMCE9PXJ8fEgodCx0aGlzLmxlbmd0aC04KTt2YXIgbj0oZTw8MjQpK3RoaXNbKyt0XSpNYXRoLnBvdygyLDE2KSt0aGlzWysrdF0qTWF0aC5wb3coMiw4KSt0aGlzWysrdF07cmV0dXJuKEJpZ0ludChuKTw8QmlnSW50KDMyKSkrQmlnSW50KHRoaXNbKyt0XSpNYXRoLnBvdygyLDI0KSt0aGlzWysrdF0qTWF0aC5wb3coMiwxNikrdGhpc1srK3RdKk1hdGgucG93KDIsOCkrcil9KSkseS5wcm90b3R5cGUucmVhZEZsb2F0TEU9ZnVuY3Rpb24odCxlKXtyZXR1cm4gdD4+Pj0wLGV8fE4odCw0LHRoaXMubGVuZ3RoKSxmLnJlYWQodGhpcyx0LCEwLDIzLDQpfSx5LnByb3RvdHlwZS5yZWFkRmxvYXRCRT1mdW5jdGlvbih0LGUpe3JldHVybiB0Pj4+PTAsZXx8Tih0LDQsdGhpcy5sZW5ndGgpLGYucmVhZCh0aGlzLHQsITEsMjMsNCl9LHkucHJvdG90eXBlLnJlYWREb3VibGVMRT1mdW5jdGlvbih0LGUpe3JldHVybiB0Pj4+PTAsZXx8Tih0LDgsdGhpcy5sZW5ndGgpLGYucmVhZCh0aGlzLHQsITAsNTIsOCl9LHkucHJvdG90eXBlLnJlYWREb3VibGVCRT1mdW5jdGlvbih0LGUpe3JldHVybiB0Pj4+PTAsZXx8Tih0LDgsdGhpcy5sZW5ndGgpLGYucmVhZCh0aGlzLHQsITEsNTIsOCl9LHkucHJvdG90eXBlLndyaXRlVWludExFPXkucHJvdG90eXBlLndyaXRlVUludExFPWZ1bmN0aW9uKHQsZSxyLG4pe3Q9K3QsZT4+Pj0wLHI+Pj49MCxufHxGKHRoaXMsdCxlLHIsTWF0aC5wb3coMiw4KnIpLTEsMCk7dmFyIGk9MSxvPTA7Zm9yKHRoaXNbZV09MjU1JnQ7KytvPHImJihpKj0yNTYpOyl0aGlzW2Urb109dC9pJjI1NTtyZXR1cm4gZStyfSx5LnByb3RvdHlwZS53cml0ZVVpbnRCRT15LnByb3RvdHlwZS53cml0ZVVJbnRCRT1mdW5jdGlvbih0LGUscixuKXt0PSt0LGU+Pj49MCxyPj4+PTAsbnx8Rih0aGlzLHQsZSxyLE1hdGgucG93KDIsOCpyKS0xLDApO3ZhciBpPXItMSxvPTE7Zm9yKHRoaXNbZStpXT0yNTUmdDstLWk+PTAmJihvKj0yNTYpOyl0aGlzW2UraV09dC9vJjI1NTtyZXR1cm4gZStyfSx5LnByb3RvdHlwZS53cml0ZVVpbnQ4PXkucHJvdG90eXBlLndyaXRlVUludDg9ZnVuY3Rpb24odCxlLHIpe3JldHVybiB0PSt0LGU+Pj49MCxyfHxGKHRoaXMsdCxlLDEsMjU1LDApLHRoaXNbZV09MjU1JnQsZSsxfSx5LnByb3RvdHlwZS53cml0ZVVpbnQxNkxFPXkucHJvdG90eXBlLndyaXRlVUludDE2TEU9ZnVuY3Rpb24odCxlLHIpe3JldHVybiB0PSt0LGU+Pj49MCxyfHxGKHRoaXMsdCxlLDIsNjU1MzUsMCksdGhpc1tlXT0yNTUmdCx0aGlzW2UrMV09dD4+PjgsZSsyfSx5LnByb3RvdHlwZS53cml0ZVVpbnQxNkJFPXkucHJvdG90eXBlLndyaXRlVUludDE2QkU9ZnVuY3Rpb24odCxlLHIpe3JldHVybiB0PSt0LGU+Pj49MCxyfHxGKHRoaXMsdCxlLDIsNjU1MzUsMCksdGhpc1tlXT10Pj4+OCx0aGlzW2UrMV09MjU1JnQsZSsyfSx5LnByb3RvdHlwZS53cml0ZVVpbnQzMkxFPXkucHJvdG90eXBlLndyaXRlVUludDMyTEU9ZnVuY3Rpb24odCxlLHIpe3JldHVybiB0PSt0LGU+Pj49MCxyfHxGKHRoaXMsdCxlLDQsNDI5NDk2NzI5NSwwKSx0aGlzW2UrM109dD4+PjI0LHRoaXNbZSsyXT10Pj4+MTYsdGhpc1tlKzFdPXQ+Pj44LHRoaXNbZV09MjU1JnQsZSs0fSx5LnByb3RvdHlwZS53cml0ZVVpbnQzMkJFPXkucHJvdG90eXBlLndyaXRlVUludDMyQkU9ZnVuY3Rpb24odCxlLHIpe3JldHVybiB0PSt0LGU+Pj49MCxyfHxGKHRoaXMsdCxlLDQsNDI5NDk2NzI5NSwwKSx0aGlzW2VdPXQ+Pj4yNCx0aGlzW2UrMV09dD4+PjE2LHRoaXNbZSsyXT10Pj4+OCx0aGlzW2UrM109MjU1JnQsZSs0fSx5LnByb3RvdHlwZS53cml0ZUJpZ1VJbnQ2NExFPWl0KChmdW5jdGlvbih0KXtyZXR1cm4gRyh0aGlzLHQsYXJndW1lbnRzLmxlbmd0aD4xJiZ2b2lkIDAhPT1hcmd1bWVudHNbMV0/YXJndW1lbnRzWzFdOjAsQmlnSW50KDApLEJpZ0ludCgiMHhmZmZmZmZmZmZmZmZmZmZmIikpfSkpLHkucHJvdG90eXBlLndyaXRlQmlnVUludDY0QkU9aXQoKGZ1bmN0aW9uKHQpe3JldHVybiB6KHRoaXMsdCxhcmd1bWVudHMubGVuZ3RoPjEmJnZvaWQgMCE9PWFyZ3VtZW50c1sxXT9hcmd1bWVudHNbMV06MCxCaWdJbnQoMCksQmlnSW50KCIweGZmZmZmZmZmZmZmZmZmZmYiKSl9KSkseS5wcm90b3R5cGUud3JpdGVJbnRMRT1mdW5jdGlvbih0LGUscixuKXtpZih0PSt0LGU+Pj49MCwhbil7dmFyIGk9TWF0aC5wb3coMiw4KnItMSk7Rih0aGlzLHQsZSxyLGktMSwtaSl9dmFyIG89MCxhPTEscz0wO2Zvcih0aGlzW2VdPTI1NSZ0OysrbzxyJiYoYSo9MjU2KTspdDwwJiYwPT09cyYmMCE9PXRoaXNbZStvLTFdJiYocz0xKSx0aGlzW2Urb109KHQvYXwwKS1zJjI1NTtyZXR1cm4gZStyfSx5LnByb3RvdHlwZS53cml0ZUludEJFPWZ1bmN0aW9uKHQsZSxyLG4pe2lmKHQ9K3QsZT4+Pj0wLCFuKXt2YXIgaT1NYXRoLnBvdygyLDgqci0xKTtGKHRoaXMsdCxlLHIsaS0xLC1pKX12YXIgbz1yLTEsYT0xLHM9MDtmb3IodGhpc1tlK29dPTI1NSZ0Oy0tbz49MCYmKGEqPTI1Nik7KXQ8MCYmMD09PXMmJjAhPT10aGlzW2UrbysxXSYmKHM9MSksdGhpc1tlK29dPSh0L2F8MCktcyYyNTU7cmV0dXJuIGUrcn0seS5wcm90b3R5cGUud3JpdGVJbnQ4PWZ1bmN0aW9uKHQsZSxyKXtyZXR1cm4gdD0rdCxlPj4+PTAscnx8Rih0aGlzLHQsZSwxLDEyNywtMTI4KSx0PDAmJih0PTI1NSt0KzEpLHRoaXNbZV09MjU1JnQsZSsxfSx5LnByb3RvdHlwZS53cml0ZUludDE2TEU9ZnVuY3Rpb24odCxlLHIpe3JldHVybiB0PSt0LGU+Pj49MCxyfHxGKHRoaXMsdCxlLDIsMzI3NjcsLTMyNzY4KSx0aGlzW2VdPTI1NSZ0LHRoaXNbZSsxXT10Pj4+OCxlKzJ9LHkucHJvdG90eXBlLndyaXRlSW50MTZCRT1mdW5jdGlvbih0LGUscil7cmV0dXJuIHQ9K3QsZT4+Pj0wLHJ8fEYodGhpcyx0LGUsMiwzMjc2NywtMzI3NjgpLHRoaXNbZV09dD4+PjgsdGhpc1tlKzFdPTI1NSZ0LGUrMn0seS5wcm90b3R5cGUud3JpdGVJbnQzMkxFPWZ1bmN0aW9uKHQsZSxyKXtyZXR1cm4gdD0rdCxlPj4+PTAscnx8Rih0aGlzLHQsZSw0LDIxNDc0ODM2NDcsLTIxNDc0ODM2NDgpLHRoaXNbZV09MjU1JnQsdGhpc1tlKzFdPXQ+Pj44LHRoaXNbZSsyXT10Pj4+MTYsdGhpc1tlKzNdPXQ+Pj4yNCxlKzR9LHkucHJvdG90eXBlLndyaXRlSW50MzJCRT1mdW5jdGlvbih0LGUscil7cmV0dXJuIHQ9K3QsZT4+Pj0wLHJ8fEYodGhpcyx0LGUsNCwyMTQ3NDgzNjQ3LC0yMTQ3NDgzNjQ4KSx0PDAmJih0PTQyOTQ5NjcyOTUrdCsxKSx0aGlzW2VdPXQ+Pj4yNCx0aGlzW2UrMV09dD4+PjE2LHRoaXNbZSsyXT10Pj4+OCx0aGlzW2UrM109MjU1JnQsZSs0fSx5LnByb3RvdHlwZS53cml0ZUJpZ0ludDY0TEU9aXQoKGZ1bmN0aW9uKHQpe3JldHVybiBHKHRoaXMsdCxhcmd1bWVudHMubGVuZ3RoPjEmJnZvaWQgMCE9PWFyZ3VtZW50c1sxXT9hcmd1bWVudHNbMV06MCwtQmlnSW50KCIweDgwMDAwMDAwMDAwMDAwMDAiKSxCaWdJbnQoIjB4N2ZmZmZmZmZmZmZmZmZmZiIpKX0pKSx5LnByb3RvdHlwZS53cml0ZUJpZ0ludDY0QkU9aXQoKGZ1bmN0aW9uKHQpe3JldHVybiB6KHRoaXMsdCxhcmd1bWVudHMubGVuZ3RoPjEmJnZvaWQgMCE9PWFyZ3VtZW50c1sxXT9hcmd1bWVudHNbMV06MCwtQmlnSW50KCIweDgwMDAwMDAwMDAwMDAwMDAiKSxCaWdJbnQoIjB4N2ZmZmZmZmZmZmZmZmZmZiIpKX0pKSx5LnByb3RvdHlwZS53cml0ZUZsb2F0TEU9ZnVuY3Rpb24odCxlLHIpe3JldHVybiBXKHRoaXMsdCxlLCEwLHIpfSx5LnByb3RvdHlwZS53cml0ZUZsb2F0QkU9ZnVuY3Rpb24odCxlLHIpe3JldHVybiBXKHRoaXMsdCxlLCExLHIpfSx5LnByb3RvdHlwZS53cml0ZURvdWJsZUxFPWZ1bmN0aW9uKHQsZSxyKXtyZXR1cm4gWSh0aGlzLHQsZSwhMCxyKX0seS5wcm90b3R5cGUud3JpdGVEb3VibGVCRT1mdW5jdGlvbih0LGUscil7cmV0dXJuIFkodGhpcyx0LGUsITEscil9LHkucHJvdG90eXBlLmNvcHk9ZnVuY3Rpb24odCxlLHIsbil7aWYoIXkuaXNCdWZmZXIodCkpdGhyb3cgbmV3IFR5cGVFcnJvcigiYXJndW1lbnQgc2hvdWxkIGJlIGEgQnVmZmVyIik7aWYocnx8KHI9MCksbnx8MD09PW58fChuPXRoaXMubGVuZ3RoKSxlPj10Lmxlbmd0aCYmKGU9dC5sZW5ndGgpLGV8fChlPTApLG4+MCYmbjxyJiYobj1yKSxuPT09cilyZXR1cm4gMDtpZigwPT09dC5sZW5ndGh8fDA9PT10aGlzLmxlbmd0aClyZXR1cm4gMDtpZihlPDApdGhyb3cgbmV3IFJhbmdlRXJyb3IoInRhcmdldFN0YXJ0IG91dCBvZiBib3VuZHMiKTtpZihyPDB8fHI+PXRoaXMubGVuZ3RoKXRocm93IG5ldyBSYW5nZUVycm9yKCJJbmRleCBvdXQgb2YgcmFuZ2UiKTtpZihuPDApdGhyb3cgbmV3IFJhbmdlRXJyb3IoInNvdXJjZUVuZCBvdXQgb2YgYm91bmRzIik7bj50aGlzLmxlbmd0aCYmKG49dGhpcy5sZW5ndGgpLHQubGVuZ3RoLWU8bi1yJiYobj10Lmxlbmd0aC1lK3IpO3ZhciBpPW4tcjtyZXR1cm4gdGhpcz09PXQmJiJmdW5jdGlvbiI9PXR5cGVvZiBVaW50OEFycmF5LnByb3RvdHlwZS5jb3B5V2l0aGluP3RoaXMuY29weVdpdGhpbihlLHIsbik6VWludDhBcnJheS5wcm90b3R5cGUuc2V0LmNhbGwodCx0aGlzLnN1YmFycmF5KHIsbiksZSksaX0seS5wcm90b3R5cGUuZmlsbD1mdW5jdGlvbih0LGUscixuKXtpZigic3RyaW5nIj09dHlwZW9mIHQpe2lmKCJzdHJpbmciPT10eXBlb2YgZT8obj1lLGU9MCxyPXRoaXMubGVuZ3RoKToic3RyaW5nIj09dHlwZW9mIHImJihuPXIscj10aGlzLmxlbmd0aCksdm9pZCAwIT09biYmInN0cmluZyIhPXR5cGVvZiBuKXRocm93IG5ldyBUeXBlRXJyb3IoImVuY29kaW5nIG11c3QgYmUgYSBzdHJpbmciKTtpZigic3RyaW5nIj09dHlwZW9mIG4mJiF5LmlzRW5jb2RpbmcobikpdGhyb3cgbmV3IFR5cGVFcnJvcigiVW5rbm93biBlbmNvZGluZzogIituKTtpZigxPT09dC5sZW5ndGgpe3ZhciBpPXQuY2hhckNvZGVBdCgwKTsoInV0ZjgiPT09biYmaTwxMjh8fCJsYXRpbjEiPT09bikmJih0PWkpfX1lbHNlIm51bWJlciI9PXR5cGVvZiB0P3QmPTI1NToiYm9vbGVhbiI9PXR5cGVvZiB0JiYodD1OdW1iZXIodCkpO2lmKGU8MHx8dGhpcy5sZW5ndGg8ZXx8dGhpcy5sZW5ndGg8cil0aHJvdyBuZXcgUmFuZ2VFcnJvcigiT3V0IG9mIHJhbmdlIGluZGV4Iik7aWYocjw9ZSlyZXR1cm4gdGhpczt2YXIgbztpZihlPj4+PTAscj12b2lkIDA9PT1yP3RoaXMubGVuZ3RoOnI+Pj4wLHR8fCh0PTApLCJudW1iZXIiPT10eXBlb2YgdClmb3Iobz1lO288cjsrK28pdGhpc1tvXT10O2Vsc2V7dmFyIGE9eS5pc0J1ZmZlcih0KT90OnkuZnJvbSh0LG4pLHM9YS5sZW5ndGg7aWYoMD09PXMpdGhyb3cgbmV3IFR5cGVFcnJvcignVGhlIHZhbHVlICInK3QrJyIgaXMgaW52YWxpZCBmb3IgYXJndW1lbnQgInZhbHVlIicpO2ZvcihvPTA7bzxyLWU7KytvKXRoaXNbbytlXT1hW28lc119cmV0dXJuIHRoaXN9O3ZhciBWPXt9O2Z1bmN0aW9uIHEodCxlLHIpe1ZbdF09ZnVuY3Rpb24ocil7ZnVuY3Rpb24gaSgpe3ZhciByO3JldHVybiBmdW5jdGlvbih0LGUpe2lmKCEodCBpbnN0YW5jZW9mIGUpKXRocm93IG5ldyBUeXBlRXJyb3IoIkNhbm5vdCBjYWxsIGEgY2xhc3MgYXMgYSBmdW5jdGlvbiIpfSh0aGlzLGkpLHI9ZnVuY3Rpb24odCxlLHIpe3JldHVybiBlPWEoZSksZnVuY3Rpb24odCxlKXtpZihlJiYoIm9iamVjdCI9PXUoZSl8fCJmdW5jdGlvbiI9PXR5cGVvZiBlKSlyZXR1cm4gZTtpZih2b2lkIDAhPT1lKXRocm93IG5ldyBUeXBlRXJyb3IoIkRlcml2ZWQgY29uc3RydWN0b3JzIG1heSBvbmx5IHJldHVybiBvYmplY3Qgb3IgdW5kZWZpbmVkIik7cmV0dXJuIGZ1bmN0aW9uKHQpe2lmKHZvaWQgMD09PXQpdGhyb3cgbmV3IFJlZmVyZW5jZUVycm9yKCJ0aGlzIGhhc24ndCBiZWVuIGluaXRpYWxpc2VkIC0gc3VwZXIoKSBoYXNuJ3QgYmVlbiBjYWxsZWQiKTtyZXR1cm4gdH0odCl9KHQsbygpP1JlZmxlY3QuY29uc3RydWN0KGUscnx8W10sYSh0KS5jb25zdHJ1Y3Rvcik6ZS5hcHBseSh0LHIpKX0odGhpcyxpKSxPYmplY3QuZGVmaW5lUHJvcGVydHkociwibWVzc2FnZSIse3ZhbHVlOmUuYXBwbHkocixhcmd1bWVudHMpLHdyaXRhYmxlOiEwLGNvbmZpZ3VyYWJsZTohMH0pLHIubmFtZT0iIi5jb25jYXQoci5uYW1lLCIgWyIpLmNvbmNhdCh0LCJdIiksci5zdGFjayxkZWxldGUgci5uYW1lLHJ9cmV0dXJuIGZ1bmN0aW9uKHQsZSl7aWYoImZ1bmN0aW9uIiE9dHlwZW9mIGUmJm51bGwhPT1lKXRocm93IG5ldyBUeXBlRXJyb3IoIlN1cGVyIGV4cHJlc3Npb24gbXVzdCBlaXRoZXIgYmUgbnVsbCBvciBhIGZ1bmN0aW9uIik7dC5wcm90b3R5cGU9T2JqZWN0LmNyZWF0ZShlJiZlLnByb3RvdHlwZSx7Y29uc3RydWN0b3I6e3ZhbHVlOnQsd3JpdGFibGU6ITAsY29uZmlndXJhYmxlOiEwfX0pLE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0LCJwcm90b3R5cGUiLHt3cml0YWJsZTohMX0pLGUmJnModCxlKX0oaSxyKSxoPWksKGY9W3trZXk6ImNvZGUiLGdldDpmdW5jdGlvbigpe3JldHVybiB0fSxzZXQ6ZnVuY3Rpb24odCl7T2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsImNvZGUiLHtjb25maWd1cmFibGU6ITAsZW51bWVyYWJsZTohMCx2YWx1ZTp0LHdyaXRhYmxlOiEwfSl9fSx7a2V5OiJ0b1N0cmluZyIsdmFsdWU6ZnVuY3Rpb24oKXtyZXR1cm4iIi5jb25jYXQodGhpcy5uYW1lLCIgWyIpLmNvbmNhdCh0LCJdOiAiKS5jb25jYXQodGhpcy5tZXNzYWdlKX19XSkmJm4oaC5wcm90b3R5cGUsZiksT2JqZWN0LmRlZmluZVByb3BlcnR5KGgsInByb3RvdHlwZSIse3dyaXRhYmxlOiExfSksaDt2YXIgaCxmfShyKX1mdW5jdGlvbiBKKHQpe2Zvcih2YXIgZT0iIixyPXQubGVuZ3RoLG49Ii0iPT09dFswXT8xOjA7cj49bis0O3ItPTMpZT0iXyIuY29uY2F0KHQuc2xpY2Uoci0zLHIpKS5jb25jYXQoZSk7cmV0dXJuIiIuY29uY2F0KHQuc2xpY2UoMCxyKSkuY29uY2F0KGUpfWZ1bmN0aW9uIFEodCxlLHIsbixpLG8pe2lmKHQ+cnx8dDxlKXt2YXIgYSxzPSJiaWdpbnQiPT10eXBlb2YgZT8ibiI6IiI7dGhyb3cgYT1vPjM/MD09PWV8fGU9PT1CaWdJbnQoMCk/Ij49IDAiLmNvbmNhdChzLCIgYW5kIDwgMiIpLmNvbmNhdChzLCIgKiogIikuY29uY2F0KDgqKG8rMSkpLmNvbmNhdChzKToiPj0gLSgyIi5jb25jYXQocywiICoqICIpLmNvbmNhdCg4KihvKzEpLTEpLmNvbmNhdChzLCIpIGFuZCA8IDIgKiogIikrIiIuY29uY2F0KDgqKG8rMSktMSkuY29uY2F0KHMpOiI+PSAiLmNvbmNhdChlKS5jb25jYXQocywiIGFuZCA8PSAiKS5jb25jYXQocikuY29uY2F0KHMpLG5ldyBWLkVSUl9PVVRfT0ZfUkFOR0UoInZhbHVlIixhLHQpfSFmdW5jdGlvbih0LGUscil7WChlLCJvZmZzZXQiKSx2b2lkIDAhPT10W2VdJiZ2b2lkIDAhPT10W2Urcl18fEgoZSx0Lmxlbmd0aC0ocisxKSl9KG4saSxvKX1mdW5jdGlvbiBYKHQsZSl7aWYoIm51bWJlciIhPXR5cGVvZiB0KXRocm93IG5ldyBWLkVSUl9JTlZBTElEX0FSR19UWVBFKGUsIm51bWJlciIsdCl9ZnVuY3Rpb24gSCh0LGUscil7aWYoTWF0aC5mbG9vcih0KSE9PXQpdGhyb3cgWCh0LHIpLG5ldyBWLkVSUl9PVVRfT0ZfUkFOR0Uocnx8Im9mZnNldCIsImFuIGludGVnZXIiLHQpO2lmKGU8MCl0aHJvdyBuZXcgVi5FUlJfQlVGRkVSX09VVF9PRl9CT1VORFM7dGhyb3cgbmV3IFYuRVJSX09VVF9PRl9SQU5HRShyfHwib2Zmc2V0IiwiPj0gIi5jb25jYXQocj8xOjAsIiBhbmQgPD0gIikuY29uY2F0KGUpLHQpfXEoIkVSUl9CVUZGRVJfT1VUX09GX0JPVU5EUyIsKGZ1bmN0aW9uKHQpe3JldHVybiB0PyIiLmNvbmNhdCh0LCIgaXMgb3V0c2lkZSBvZiBidWZmZXIgYm91bmRzIik6IkF0dGVtcHQgdG8gYWNjZXNzIG1lbW9yeSBvdXRzaWRlIGJ1ZmZlciBib3VuZHMifSksUmFuZ2VFcnJvcikscSgiRVJSX0lOVkFMSURfQVJHX1RZUEUiLChmdW5jdGlvbih0LGUpe3JldHVybidUaGUgIicuY29uY2F0KHQsJyIgYXJndW1lbnQgbXVzdCBiZSBvZiB0eXBlIG51bWJlci4gUmVjZWl2ZWQgdHlwZSAnKS5jb25jYXQodShlKSl9KSxUeXBlRXJyb3IpLHEoIkVSUl9PVVRfT0ZfUkFOR0UiLChmdW5jdGlvbih0LGUscil7dmFyIG49J1RoZSB2YWx1ZSBvZiAiJy5jb25jYXQodCwnIiBpcyBvdXQgb2YgcmFuZ2UuJyksaT1yO3JldHVybiBOdW1iZXIuaXNJbnRlZ2VyKHIpJiZNYXRoLmFicyhyKT5NYXRoLnBvdygyLDMyKT9pPUooU3RyaW5nKHIpKToiYmlnaW50Ij09dHlwZW9mIHImJihpPVN0cmluZyhyKSwocj5NYXRoLnBvdyhCaWdJbnQoMiksQmlnSW50KDMyKSl8fHI8LU1hdGgucG93KEJpZ0ludCgyKSxCaWdJbnQoMzIpKSkmJihpPUooaSkpLGkrPSJuIiksbisiIEl0IG11c3QgYmUgIi5jb25jYXQoZSwiLiBSZWNlaXZlZCAiKS5jb25jYXQoaSl9KSxSYW5nZUVycm9yKTt2YXIgSz0vW14rLzAtOUEtWmEtei1fXS9nO2Z1bmN0aW9uICQodCxlKXt2YXIgcjtlPWV8fDEvMDtmb3IodmFyIG49dC5sZW5ndGgsaT1udWxsLG89W10sYT0wO2E8bjsrK2Epe2lmKChyPXQuY2hhckNvZGVBdChhKSk+NTUyOTUmJnI8NTczNDQpe2lmKCFpKXtpZihyPjU2MzE5KXsoZS09Myk+LTEmJm8ucHVzaCgyMzksMTkxLDE4OSk7Y29udGludWV9aWYoYSsxPT09bil7KGUtPTMpPi0xJiZvLnB1c2goMjM5LDE5MSwxODkpO2NvbnRpbnVlfWk9cjtjb250aW51ZX1pZihyPDU2MzIwKXsoZS09Myk+LTEmJm8ucHVzaCgyMzksMTkxLDE4OSksaT1yO2NvbnRpbnVlfXI9NjU1MzYrKGktNTUyOTY8PDEwfHItNTYzMjApfWVsc2UgaSYmKGUtPTMpPi0xJiZvLnB1c2goMjM5LDE5MSwxODkpO2lmKGk9bnVsbCxyPDEyOCl7aWYoKGUtPTEpPDApYnJlYWs7by5wdXNoKHIpfWVsc2UgaWYocjwyMDQ4KXtpZigoZS09Mik8MClicmVhaztvLnB1c2gocj4+NnwxOTIsNjMmcnwxMjgpfWVsc2UgaWYocjw2NTUzNil7aWYoKGUtPTMpPDApYnJlYWs7by5wdXNoKHI+PjEyfDIyNCxyPj42JjYzfDEyOCw2MyZyfDEyOCl9ZWxzZXtpZighKHI8MTExNDExMikpdGhyb3cgbmV3IEVycm9yKCJJbnZhbGlkIGNvZGUgcG9pbnQiKTtpZigoZS09NCk8MClicmVhaztvLnB1c2gocj4+MTh8MjQwLHI+PjEyJjYzfDEyOCxyPj42JjYzfDEyOCw2MyZyfDEyOCl9fXJldHVybiBvfWZ1bmN0aW9uIFoodCl7cmV0dXJuIGgudG9CeXRlQXJyYXkoZnVuY3Rpb24odCl7aWYoKHQ9KHQ9dC5zcGxpdCgiPSIpWzBdKS50cmltKCkucmVwbGFjZShLLCIiKSkubGVuZ3RoPDIpcmV0dXJuIiI7Zm9yKDt0Lmxlbmd0aCU0IT0wOyl0Kz0iPSI7cmV0dXJuIHR9KHQpKX1mdW5jdGlvbiB0dCh0LGUscixuKXt2YXIgaTtmb3IoaT0wO2k8biYmIShpK3I+PWUubGVuZ3RofHxpPj10Lmxlbmd0aCk7KytpKWVbaStyXT10W2ldO3JldHVybiBpfWZ1bmN0aW9uIGV0KHQsZSl7cmV0dXJuIHQgaW5zdGFuY2VvZiBlfHxudWxsIT10JiZudWxsIT10LmNvbnN0cnVjdG9yJiZudWxsIT10LmNvbnN0cnVjdG9yLm5hbWUmJnQuY29uc3RydWN0b3IubmFtZT09PWUubmFtZX1mdW5jdGlvbiBydCh0KXtyZXR1cm4gdCE9dH12YXIgbnQ9ZnVuY3Rpb24oKXtmb3IodmFyIHQ9IjAxMjM0NTY3ODlhYmNkZWYiLGU9bmV3IEFycmF5KDI1Nikscj0wO3I8MTY7KytyKWZvcih2YXIgbj0xNipyLGk9MDtpPDE2OysraSllW24raV09dFtyXSt0W2ldO3JldHVybiBlfSgpO2Z1bmN0aW9uIGl0KHQpe3JldHVybiJ1bmRlZmluZWQiPT10eXBlb2YgQmlnSW50P290OnR9ZnVuY3Rpb24gb3QoKXt0aHJvdyBuZXcgRXJyb3IoIkJpZ0ludCBub3Qgc3VwcG9ydGVkIil9fSw2MTM6KHQsZSxyKT0+eyJ1c2Ugc3RyaWN0IjtmdW5jdGlvbiBuKHQsZSl7KG51bGw9PWV8fGU+dC5sZW5ndGgpJiYoZT10Lmxlbmd0aCk7Zm9yKHZhciByPTAsbj1BcnJheShlKTtyPGU7cisrKW5bcl09dFtyXTtyZXR1cm4gbn1mdW5jdGlvbiBpKHQpe3JldHVybiBuZXcgUHJvbWlzZSgoZnVuY3Rpb24oZSxyKXt0Lm9uY29tcGxldGU9dC5vbnN1Y2Nlc3M9ZnVuY3Rpb24oKXtyZXR1cm4gZSh0LnJlc3VsdCl9LHQub25hYm9ydD10Lm9uZXJyb3I9ZnVuY3Rpb24oKXtyZXR1cm4gcih0LmVycm9yKX19KSl9ZnVuY3Rpb24gbyh0LGUpe3ZhciByPWluZGV4ZWREQi5vcGVuKHQpO3Iub251cGdyYWRlbmVlZGVkPWZ1bmN0aW9uKCl7cmV0dXJuIHIucmVzdWx0LmNyZWF0ZU9iamVjdFN0b3JlKGUpfTt2YXIgbj1pKHIpO3JldHVybiBmdW5jdGlvbih0LHIpe3JldHVybiBuLnRoZW4oKGZ1bmN0aW9uKG4pe3JldHVybiByKG4udHJhbnNhY3Rpb24oZSx0KS5vYmplY3RTdG9yZShlKSl9KSl9fXZhciBhO2Z1bmN0aW9uIHMoKXtyZXR1cm4gYXx8KGE9bygia2V5dmFsLXN0b3JlIiwia2V5dmFsIikpLGF9ZnVuY3Rpb24gdSh0KXtyZXR1cm4oYXJndW1lbnRzLmxlbmd0aD4xJiZ2b2lkIDAhPT1hcmd1bWVudHNbMV0/YXJndW1lbnRzWzFdOnMoKSkoInJlYWRvbmx5IiwoZnVuY3Rpb24oZSl7cmV0dXJuIGkoZS5nZXQodCkpfSkpfWZ1bmN0aW9uIGgodCxlKXtyZXR1cm4oYXJndW1lbnRzLmxlbmd0aD4yJiZ2b2lkIDAhPT1hcmd1bWVudHNbMl0/YXJndW1lbnRzWzJdOnMoKSkoInJlYWR3cml0ZSIsKGZ1bmN0aW9uKHIpe3JldHVybiByLnB1dChlLHQpLGkoci50cmFuc2FjdGlvbil9KSl9ZnVuY3Rpb24gZih0KXtyZXR1cm4oYXJndW1lbnRzLmxlbmd0aD4xJiZ2b2lkIDAhPT1hcmd1bWVudHNbMV0/YXJndW1lbnRzWzFdOnMoKSkoInJlYWR3cml0ZSIsKGZ1bmN0aW9uKGUpe3JldHVybiB0LmZvckVhY2goKGZ1bmN0aW9uKHQpe3JldHVybiBlLnB1dCh0WzFdLHRbMF0pfSkpLGkoZS50cmFuc2FjdGlvbil9KSl9ZnVuY3Rpb24gYyh0KXtyZXR1cm4oYXJndW1lbnRzLmxlbmd0aD4xJiZ2b2lkIDAhPT1hcmd1bWVudHNbMV0/YXJndW1lbnRzWzFdOnMoKSkoInJlYWRvbmx5IiwoZnVuY3Rpb24oZSl7cmV0dXJuIFByb21pc2UuYWxsKHQubWFwKChmdW5jdGlvbih0KXtyZXR1cm4gaShlLmdldCh0KSl9KSkpfSkpfWZ1bmN0aW9uIGwodCxlKXtyZXR1cm4oYXJndW1lbnRzLmxlbmd0aD4yJiZ2b2lkIDAhPT1hcmd1bWVudHNbMl0/YXJndW1lbnRzWzJdOnMoKSkoInJlYWR3cml0ZSIsKGZ1bmN0aW9uKHIpe3JldHVybiBuZXcgUHJvbWlzZSgoZnVuY3Rpb24obixvKXtyLmdldCh0KS5vbnN1Y2Nlc3M9ZnVuY3Rpb24oKXt0cnl7ci5wdXQoZSh0aGlzLnJlc3VsdCksdCksbihpKHIudHJhbnNhY3Rpb24pKX1jYXRjaCh0KXtvKHQpfX19KSl9KSl9ZnVuY3Rpb24gcCh0KXtyZXR1cm4oYXJndW1lbnRzLmxlbmd0aD4xJiZ2b2lkIDAhPT1hcmd1bWVudHNbMV0/YXJndW1lbnRzWzFdOnMoKSkoInJlYWR3cml0ZSIsKGZ1bmN0aW9uKGUpe3JldHVybiBlLmRlbGV0ZSh0KSxpKGUudHJhbnNhY3Rpb24pfSkpfWZ1bmN0aW9uIHkodCl7cmV0dXJuKGFyZ3VtZW50cy5sZW5ndGg+MSYmdm9pZCAwIT09YXJndW1lbnRzWzFdP2FyZ3VtZW50c1sxXTpzKCkpKCJyZWFkd3JpdGUiLChmdW5jdGlvbihlKXtyZXR1cm4gdC5mb3JFYWNoKChmdW5jdGlvbih0KXtyZXR1cm4gZS5kZWxldGUodCl9KSksaShlLnRyYW5zYWN0aW9uKX0pKX1mdW5jdGlvbiBkKCl7cmV0dXJuKGFyZ3VtZW50cy5sZW5ndGg+MCYmdm9pZCAwIT09YXJndW1lbnRzWzBdP2FyZ3VtZW50c1swXTpzKCkpKCJyZWFkd3JpdGUiLChmdW5jdGlvbih0KXtyZXR1cm4gdC5jbGVhcigpLGkodC50cmFuc2FjdGlvbil9KSl9ZnVuY3Rpb24gZyh0LGUpe3JldHVybiB0Lm9wZW5DdXJzb3IoKS5vbnN1Y2Nlc3M9ZnVuY3Rpb24oKXt0aGlzLnJlc3VsdCYmKGUodGhpcy5yZXN1bHQpLHRoaXMucmVzdWx0LmNvbnRpbnVlKCkpfSxpKHQudHJhbnNhY3Rpb24pfWZ1bmN0aW9uIGIoKXtyZXR1cm4oYXJndW1lbnRzLmxlbmd0aD4wJiZ2b2lkIDAhPT1hcmd1bWVudHNbMF0/YXJndW1lbnRzWzBdOnMoKSkoInJlYWRvbmx5IiwoZnVuY3Rpb24odCl7aWYodC5nZXRBbGxLZXlzKXJldHVybiBpKHQuZ2V0QWxsS2V5cygpKTt2YXIgZT1bXTtyZXR1cm4gZyh0LChmdW5jdGlvbih0KXtyZXR1cm4gZS5wdXNoKHQua2V5KX0pKS50aGVuKChmdW5jdGlvbigpe3JldHVybiBlfSkpfSkpfWZ1bmN0aW9uIHYoKXtyZXR1cm4oYXJndW1lbnRzLmxlbmd0aD4wJiZ2b2lkIDAhPT1hcmd1bWVudHNbMF0/YXJndW1lbnRzWzBdOnMoKSkoInJlYWRvbmx5IiwoZnVuY3Rpb24odCl7aWYodC5nZXRBbGwpcmV0dXJuIGkodC5nZXRBbGwoKSk7dmFyIGU9W107cmV0dXJuIGcodCwoZnVuY3Rpb24odCl7cmV0dXJuIGUucHVzaCh0LnZhbHVlKX0pKS50aGVuKChmdW5jdGlvbigpe3JldHVybiBlfSkpfSkpfWZ1bmN0aW9uIHcoKXt2YXIgdD1hcmd1bWVudHMubGVuZ3RoPjAmJnZvaWQgMCE9PWFyZ3VtZW50c1swXT9hcmd1bWVudHNbMF06cygpO3JldHVybiB0KCJyZWFkb25seSIsKGZ1bmN0aW9uKGUpe2lmKGUuZ2V0QWxsJiZlLmdldEFsbEtleXMpcmV0dXJuIFByb21pc2UuYWxsKFtpKGUuZ2V0QWxsS2V5cygpKSxpKGUuZ2V0QWxsKCkpXSkudGhlbigoZnVuY3Rpb24odCl7dmFyIGUscixpPShyPTIsZnVuY3Rpb24odCl7aWYoQXJyYXkuaXNBcnJheSh0KSlyZXR1cm4gdH0oZT10KXx8ZnVuY3Rpb24odCxlKXt2YXIgcj1udWxsPT10P251bGw6InVuZGVmaW5lZCIhPXR5cGVvZiBTeW1ib2wmJnRbU3ltYm9sLml0ZXJhdG9yXXx8dFsiQEBpdGVyYXRvciJdO2lmKG51bGwhPXIpe3ZhciBuLGksbyxhLHM9W10sdT0hMCxoPSExO3RyeXtpZihvPShyPXIuY2FsbCh0KSkubmV4dCwwPT09ZSl7aWYoT2JqZWN0KHIpIT09cilyZXR1cm47dT0hMX1lbHNlIGZvcig7ISh1PShuPW8uY2FsbChyKSkuZG9uZSkmJihzLnB1c2gobi52YWx1ZSkscy5sZW5ndGghPT1lKTt1PSEwKTt9Y2F0Y2godCl7aD0hMCxpPXR9ZmluYWxseXt0cnl7aWYoIXUmJm51bGwhPXIucmV0dXJuJiYoYT1yLnJldHVybigpLE9iamVjdChhKSE9PWEpKXJldHVybn1maW5hbGx5e2lmKGgpdGhyb3cgaX19cmV0dXJuIHN9fShlLHIpfHxmdW5jdGlvbih0LGUpe2lmKHQpe2lmKCJzdHJpbmciPT10eXBlb2YgdClyZXR1cm4gbih0LGUpO3ZhciByPXt9LnRvU3RyaW5nLmNhbGwodCkuc2xpY2UoOCwtMSk7cmV0dXJuIk9iamVjdCI9PT1yJiZ0LmNvbnN0cnVjdG9yJiYocj10LmNvbnN0cnVjdG9yLm5hbWUpLCJNYXAiPT09cnx8IlNldCI9PT1yP0FycmF5LmZyb20odCk6IkFyZ3VtZW50cyI9PT1yfHwvXig/OlVpfEkpbnQoPzo4fDE2fDMyKSg/OkNsYW1wZWQpP0FycmF5JC8udGVzdChyKT9uKHQsZSk6dm9pZCAwfX0oZSxyKXx8ZnVuY3Rpb24oKXt0aHJvdyBuZXcgVHlwZUVycm9yKCJJbnZhbGlkIGF0dGVtcHQgdG8gZGVzdHJ1Y3R1cmUgbm9uLWl0ZXJhYmxlIGluc3RhbmNlLlxuSW4gb3JkZXIgdG8gYmUgaXRlcmFibGUsIG5vbi1hcnJheSBvYmplY3RzIG11c3QgaGF2ZSBhIFtTeW1ib2wuaXRlcmF0b3JdKCkgbWV0aG9kLiIpfSgpKSxvPWlbMF0sYT1pWzFdO3JldHVybiBvLm1hcCgoZnVuY3Rpb24odCxlKXtyZXR1cm5bdCxhW2VdXX0pKX0pKTt2YXIgcj1bXTtyZXR1cm4gdCgicmVhZG9ubHkiLChmdW5jdGlvbih0KXtyZXR1cm4gZyh0LChmdW5jdGlvbih0KXtyZXR1cm4gci5wdXNoKFt0LmtleSx0LnZhbHVlXSl9KSkudGhlbigoZnVuY3Rpb24oKXtyZXR1cm4gcn0pKX0pKX0pKX1yLnIoZSksci5kKGUse2NsZWFyOigpPT5kLGNyZWF0ZVN0b3JlOigpPT5vLGRlbDooKT0+cCxkZWxNYW55OigpPT55LGVudHJpZXM6KCk9PncsZ2V0OigpPT51LGdldE1hbnk6KCk9PmMsa2V5czooKT0+Yixwcm9taXNpZnlSZXF1ZXN0OigpPT5pLHNldDooKT0+aCxzZXRNYW55OigpPT5mLHVwZGF0ZTooKT0+bCx2YWx1ZXM6KCk9PnZ9KX0sNjcwOnQ9PnsidXNlIHN0cmljdCI7dC5leHBvcnRzPXt0ZXh0OiEwLGJsb2NrczohMSxsYXlvdXRCbG9ja3M6ITEsaG9jcjohMSx0c3Y6ITEsYm94OiExLHVubHY6ITEsb3NkOiExLHBkZjohMSxpbWFnZUNvbG9yOiExLGltYWdlR3JleTohMSxpbWFnZUJpbmFyeTohMSxkZWJ1ZzohMX19LDc2ODoodCxlKT0+eyJ1c2Ugc3RyaWN0IjtlLmJ5dGVMZW5ndGg9ZnVuY3Rpb24odCl7dmFyIGU9cyh0KSxyPWVbMF0sbj1lWzFdO3JldHVybiAzKihyK24pLzQtbn0sZS50b0J5dGVBcnJheT1mdW5jdGlvbih0KXt2YXIgZSxyLG89cyh0KSxhPW9bMF0sdT1vWzFdLGg9bmV3IGkoZnVuY3Rpb24odCxlLHIpe3JldHVybiAzKihlK3IpLzQtcn0oMCxhLHUpKSxmPTAsYz11PjA/YS00OmE7Zm9yKHI9MDtyPGM7cis9NCllPW5bdC5jaGFyQ29kZUF0KHIpXTw8MTh8blt0LmNoYXJDb2RlQXQocisxKV08PDEyfG5bdC5jaGFyQ29kZUF0KHIrMildPDw2fG5bdC5jaGFyQ29kZUF0KHIrMyldLGhbZisrXT1lPj4xNiYyNTUsaFtmKytdPWU+PjgmMjU1LGhbZisrXT0yNTUmZTtyZXR1cm4gMj09PXUmJihlPW5bdC5jaGFyQ29kZUF0KHIpXTw8MnxuW3QuY2hhckNvZGVBdChyKzEpXT4+NCxoW2YrK109MjU1JmUpLDE9PT11JiYoZT1uW3QuY2hhckNvZGVBdChyKV08PDEwfG5bdC5jaGFyQ29kZUF0KHIrMSldPDw0fG5bdC5jaGFyQ29kZUF0KHIrMildPj4yLGhbZisrXT1lPj44JjI1NSxoW2YrK109MjU1JmUpLGh9LGUuZnJvbUJ5dGVBcnJheT1mdW5jdGlvbih0KXtmb3IodmFyIGUsbj10Lmxlbmd0aCxpPW4lMyxvPVtdLGE9MTYzODMscz0wLGg9bi1pO3M8aDtzKz1hKW8ucHVzaCh1KHQscyxzK2E+aD9oOnMrYSkpO3JldHVybiAxPT09aT8oZT10W24tMV0sby5wdXNoKHJbZT4+Ml0rcltlPDw0JjYzXSsiPT0iKSk6Mj09PWkmJihlPSh0W24tMl08PDgpK3Rbbi0xXSxvLnB1c2gocltlPj4xMF0rcltlPj40JjYzXStyW2U8PDImNjNdKyI9IikpLG8uam9pbigiIil9O2Zvcih2YXIgcj1bXSxuPVtdLGk9InVuZGVmaW5lZCIhPXR5cGVvZiBVaW50OEFycmF5P1VpbnQ4QXJyYXk6QXJyYXksbz0iQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODkrLyIsYT0wO2E8NjQ7KythKXJbYV09b1thXSxuW28uY2hhckNvZGVBdChhKV09YTtmdW5jdGlvbiBzKHQpe3ZhciBlPXQubGVuZ3RoO2lmKGUlND4wKXRocm93IG5ldyBFcnJvcigiSW52YWxpZCBzdHJpbmcuIExlbmd0aCBtdXN0IGJlIGEgbXVsdGlwbGUgb2YgNCIpO3ZhciByPXQuaW5kZXhPZigiPSIpO3JldHVybi0xPT09ciYmKHI9ZSksW3Iscj09PWU/MDo0LXIlNF19ZnVuY3Rpb24gdSh0LGUsbil7Zm9yKHZhciBpLG8sYT1bXSxzPWU7czxuO3MrPTMpaT0odFtzXTw8MTYmMTY3MTE2ODApKyh0W3MrMV08PDgmNjUyODApKygyNTUmdFtzKzJdKSxhLnB1c2goclsobz1pKT4+MTgmNjNdK3Jbbz4+MTImNjNdK3Jbbz4+NiY2M10rcls2MyZvXSk7cmV0dXJuIGEuam9pbigiIil9blsiLSIuY2hhckNvZGVBdCgwKV09NjIsblsiXyIuY2hhckNvZGVBdCgwKV09NjN9LDc3MzoodCxlKT0+e2UucmVhZD1mdW5jdGlvbih0LGUscixuLGkpe3ZhciBvLGEscz04Kmktbi0xLHU9KDE8PHMpLTEsaD11Pj4xLGY9LTcsYz1yP2ktMTowLGw9cj8tMToxLHA9dFtlK2NdO2ZvcihjKz1sLG89cCYoMTw8LWYpLTEscD4+PS1mLGYrPXM7Zj4wO289MjU2Km8rdFtlK2NdLGMrPWwsZi09OCk7Zm9yKGE9byYoMTw8LWYpLTEsbz4+PS1mLGYrPW47Zj4wO2E9MjU2KmErdFtlK2NdLGMrPWwsZi09OCk7aWYoMD09PW8pbz0xLWg7ZWxzZXtpZihvPT09dSlyZXR1cm4gYT9OYU46MS8wKihwPy0xOjEpO2ErPU1hdGgucG93KDIsbiksby09aH1yZXR1cm4ocD8tMToxKSphKk1hdGgucG93KDIsby1uKX0sZS53cml0ZT1mdW5jdGlvbih0LGUscixuLGksbyl7dmFyIGEscyx1LGg9OCpvLWktMSxmPSgxPDxoKS0xLGM9Zj4+MSxsPTIzPT09aT9NYXRoLnBvdygyLC0yNCktTWF0aC5wb3coMiwtNzcpOjAscD1uPzA6by0xLHk9bj8xOi0xLGQ9ZTwwfHwwPT09ZSYmMS9lPDA/MTowO2ZvcihlPU1hdGguYWJzKGUpLGlzTmFOKGUpfHxlPT09MS8wPyhzPWlzTmFOKGUpPzE6MCxhPWYpOihhPU1hdGguZmxvb3IoTWF0aC5sb2coZSkvTWF0aC5MTjIpLGUqKHU9TWF0aC5wb3coMiwtYSkpPDEmJihhLS0sdSo9MiksKGUrPWErYz49MT9sL3U6bCpNYXRoLnBvdygyLDEtYykpKnU+PTImJihhKyssdS89MiksYStjPj1mPyhzPTAsYT1mKTphK2M+PTE/KHM9KGUqdS0xKSpNYXRoLnBvdygyLGkpLGErPWMpOihzPWUqTWF0aC5wb3coMixjLTEpKk1hdGgucG93KDIsaSksYT0wKSk7aT49ODt0W3IrcF09MjU1JnMscCs9eSxzLz0yNTYsaS09OCk7Zm9yKGE9YTw8aXxzLGgrPWk7aD4wO3RbcitwXT0yNTUmYSxwKz15LGEvPTI1NixoLT04KTt0W3IrcC15XXw9MTI4KmR9fSw3OTc6KHQsZSxyKT0+eyJ1c2Ugc3RyaWN0Ijt2YXIgbj1yKDYxMyksaT1uLnNldCxvPW4uZ2V0LGE9bi5kZWw7dC5leHBvcnRzPXtyZWFkQ2FjaGU6byx3cml0ZUNhY2hlOmksZGVsZXRlQ2FjaGU6YSxjaGVja0NhY2hlOmZ1bmN0aW9uKHQpe3JldHVybiBvKHQpLnRoZW4oKGZ1bmN0aW9uKHQpe3JldHVybiB2b2lkIDAhPT10fSkpfX19LDgzNDoodCxlLHIpPT57dmFyIG49cig1NDUpLmhwO2Z1bmN0aW9uIGkodCxlKXtpZih0aGlzLnBvcz0wLHRoaXMuYnVmZmVyPXQsdGhpcy5pc193aXRoX2FscGhhPSEhZSx0aGlzLmJvdHRvbV91cD0hMCx0aGlzLmZsYWc9dGhpcy5idWZmZXIudG9TdHJpbmcoInV0Zi04IiwwLHRoaXMucG9zKz0yKSwiQk0iIT10aGlzLmZsYWcpdGhyb3cgbmV3IEVycm9yKCJJbnZhbGlkIEJNUCBGaWxlIik7dGhpcy5wYXJzZUhlYWRlcigpLHRoaXMucGFyc2VSR0JBKCl9aS5wcm90b3R5cGUucGFyc2VIZWFkZXI9ZnVuY3Rpb24oKXtpZih0aGlzLmZpbGVTaXplPXRoaXMuYnVmZmVyLnJlYWRVSW50MzJMRSh0aGlzLnBvcyksdGhpcy5wb3MrPTQsdGhpcy5yZXNlcnZlZD10aGlzLmJ1ZmZlci5yZWFkVUludDMyTEUodGhpcy5wb3MpLHRoaXMucG9zKz00LHRoaXMub2Zmc2V0PXRoaXMuYnVmZmVyLnJlYWRVSW50MzJMRSh0aGlzLnBvcyksdGhpcy5wb3MrPTQsdGhpcy5oZWFkZXJTaXplPXRoaXMuYnVmZmVyLnJlYWRVSW50MzJMRSh0aGlzLnBvcyksdGhpcy5wb3MrPTQsdGhpcy53aWR0aD10aGlzLmJ1ZmZlci5yZWFkVUludDMyTEUodGhpcy5wb3MpLHRoaXMucG9zKz00LHRoaXMuaGVpZ2h0PXRoaXMuYnVmZmVyLnJlYWRJbnQzMkxFKHRoaXMucG9zKSx0aGlzLnBvcys9NCx0aGlzLnBsYW5lcz10aGlzLmJ1ZmZlci5yZWFkVUludDE2TEUodGhpcy5wb3MpLHRoaXMucG9zKz0yLHRoaXMuYml0UFA9dGhpcy5idWZmZXIucmVhZFVJbnQxNkxFKHRoaXMucG9zKSx0aGlzLnBvcys9Mix0aGlzLmNvbXByZXNzPXRoaXMuYnVmZmVyLnJlYWRVSW50MzJMRSh0aGlzLnBvcyksdGhpcy5wb3MrPTQsdGhpcy5yYXdTaXplPXRoaXMuYnVmZmVyLnJlYWRVSW50MzJMRSh0aGlzLnBvcyksdGhpcy5wb3MrPTQsdGhpcy5ocj10aGlzLmJ1ZmZlci5yZWFkVUludDMyTEUodGhpcy5wb3MpLHRoaXMucG9zKz00LHRoaXMudnI9dGhpcy5idWZmZXIucmVhZFVJbnQzMkxFKHRoaXMucG9zKSx0aGlzLnBvcys9NCx0aGlzLmNvbG9ycz10aGlzLmJ1ZmZlci5yZWFkVUludDMyTEUodGhpcy5wb3MpLHRoaXMucG9zKz00LHRoaXMuaW1wb3J0YW50Q29sb3JzPXRoaXMuYnVmZmVyLnJlYWRVSW50MzJMRSh0aGlzLnBvcyksdGhpcy5wb3MrPTQsMTY9PT10aGlzLmJpdFBQJiZ0aGlzLmlzX3dpdGhfYWxwaGEmJih0aGlzLmJpdFBQPTE1KSx0aGlzLmJpdFBQPDE1KXt2YXIgdD0wPT09dGhpcy5jb2xvcnM/MTw8dGhpcy5iaXRQUDp0aGlzLmNvbG9yczt0aGlzLnBhbGV0dGU9bmV3IEFycmF5KHQpO2Zvcih2YXIgZT0wO2U8dDtlKyspe3ZhciByPXRoaXMuYnVmZmVyLnJlYWRVSW50OCh0aGlzLnBvcysrKSxuPXRoaXMuYnVmZmVyLnJlYWRVSW50OCh0aGlzLnBvcysrKSxpPXRoaXMuYnVmZmVyLnJlYWRVSW50OCh0aGlzLnBvcysrKSxvPXRoaXMuYnVmZmVyLnJlYWRVSW50OCh0aGlzLnBvcysrKTt0aGlzLnBhbGV0dGVbZV09e3JlZDppLGdyZWVuOm4sYmx1ZTpyLHF1YWQ6b319fXRoaXMuaGVpZ2h0PDAmJih0aGlzLmhlaWdodCo9LTEsdGhpcy5ib3R0b21fdXA9ITEpfSxpLnByb3RvdHlwZS5wYXJzZVJHQkE9ZnVuY3Rpb24oKXt2YXIgdD0iYml0Iit0aGlzLmJpdFBQLGU9dGhpcy53aWR0aCp0aGlzLmhlaWdodCo0O3RoaXMuZGF0YT1uZXcgbihlKSx0aGlzW3RdKCl9LGkucHJvdG90eXBlLmJpdDE9ZnVuY3Rpb24oKXt2YXIgdD1NYXRoLmNlaWwodGhpcy53aWR0aC84KSxlPXQlNCxyPXRoaXMuaGVpZ2h0Pj0wP3RoaXMuaGVpZ2h0LTE6LXRoaXMuaGVpZ2h0O2ZvcihyPXRoaXMuaGVpZ2h0LTE7cj49MDtyLS0pe2Zvcih2YXIgbj10aGlzLmJvdHRvbV91cD9yOnRoaXMuaGVpZ2h0LTEtcixpPTA7aTx0O2krKylmb3IodmFyIG89dGhpcy5idWZmZXIucmVhZFVJbnQ4KHRoaXMucG9zKyspLGE9bip0aGlzLndpZHRoKjQrOCppKjQscz0wO3M8OCYmOCppK3M8dGhpcy53aWR0aDtzKyspe3ZhciB1PXRoaXMucGFsZXR0ZVtvPj43LXMmMV07dGhpcy5kYXRhW2ErNCpzXT0wLHRoaXMuZGF0YVthKzQqcysxXT11LmJsdWUsdGhpcy5kYXRhW2ErNCpzKzJdPXUuZ3JlZW4sdGhpcy5kYXRhW2ErNCpzKzNdPXUucmVkfTAhPWUmJih0aGlzLnBvcys9NC1lKX19LGkucHJvdG90eXBlLmJpdDQ9ZnVuY3Rpb24oKXtpZigyPT10aGlzLmNvbXByZXNzKXt2YXIgdD1mdW5jdGlvbih0KXt2YXIgcj10aGlzLnBhbGV0dGVbdF07dGhpcy5kYXRhW2VdPTAsdGhpcy5kYXRhW2UrMV09ci5ibHVlLHRoaXMuZGF0YVtlKzJdPXIuZ3JlZW4sdGhpcy5kYXRhW2UrM109ci5yZWQsZSs9NH07dGhpcy5kYXRhLmZpbGwoMjU1KTtmb3IodmFyIGU9MCxyPXRoaXMuYm90dG9tX3VwP3RoaXMuaGVpZ2h0LTE6MCxuPSExO2U8dGhpcy5kYXRhLmxlbmd0aDspe3ZhciBpPXRoaXMuYnVmZmVyLnJlYWRVSW50OCh0aGlzLnBvcysrKSxvPXRoaXMuYnVmZmVyLnJlYWRVSW50OCh0aGlzLnBvcysrKTtpZigwPT1pKXtpZigwPT1vKXt0aGlzLmJvdHRvbV91cD9yLS06cisrLGU9cip0aGlzLndpZHRoKjQsbj0hMTtjb250aW51ZX1pZigxPT1vKWJyZWFrO2lmKDI9PW8pe3ZhciBhPXRoaXMuYnVmZmVyLnJlYWRVSW50OCh0aGlzLnBvcysrKSxzPXRoaXMuYnVmZmVyLnJlYWRVSW50OCh0aGlzLnBvcysrKTt0aGlzLmJvdHRvbV91cD9yLT1zOnIrPXMsZSs9cyp0aGlzLndpZHRoKjQrNCphfWVsc2V7Zm9yKHZhciB1PXRoaXMuYnVmZmVyLnJlYWRVSW50OCh0aGlzLnBvcysrKSxoPTA7aDxvO2grKyl0LmNhbGwodGhpcyxuPzE1JnU6KDI0MCZ1KT4+NCksMSZoJiZoKzE8byYmKHU9dGhpcy5idWZmZXIucmVhZFVJbnQ4KHRoaXMucG9zKyspKSxuPSFuOzE9PShvKzE+PjEmMSkmJnRoaXMucG9zKyt9fWVsc2UgZm9yKGg9MDtoPGk7aCsrKXQuY2FsbCh0aGlzLG4/MTUmbzooMjQwJm8pPj40KSxuPSFufX1lbHNle3ZhciBmPU1hdGguY2VpbCh0aGlzLndpZHRoLzIpLGM9ZiU0O2ZvcihzPXRoaXMuaGVpZ2h0LTE7cz49MDtzLS0pe3ZhciBsPXRoaXMuYm90dG9tX3VwP3M6dGhpcy5oZWlnaHQtMS1zO2ZvcihhPTA7YTxmO2ErKyl7bz10aGlzLmJ1ZmZlci5yZWFkVUludDgodGhpcy5wb3MrKyksZT1sKnRoaXMud2lkdGgqNCsyKmEqNDt2YXIgcD1vPj40LHk9MTUmbyxkPXRoaXMucGFsZXR0ZVtwXTtpZih0aGlzLmRhdGFbZV09MCx0aGlzLmRhdGFbZSsxXT1kLmJsdWUsdGhpcy5kYXRhW2UrMl09ZC5ncmVlbix0aGlzLmRhdGFbZSszXT1kLnJlZCwyKmErMT49dGhpcy53aWR0aClicmVhaztkPXRoaXMucGFsZXR0ZVt5XSx0aGlzLmRhdGFbZSs0XT0wLHRoaXMuZGF0YVtlKzQrMV09ZC5ibHVlLHRoaXMuZGF0YVtlKzQrMl09ZC5ncmVlbix0aGlzLmRhdGFbZSs0KzNdPWQucmVkfTAhPWMmJih0aGlzLnBvcys9NC1jKX19fSxpLnByb3RvdHlwZS5iaXQ4PWZ1bmN0aW9uKCl7aWYoMT09dGhpcy5jb21wcmVzcyl7dmFyIHQ9ZnVuY3Rpb24odCl7dmFyIHI9dGhpcy5wYWxldHRlW3RdO3RoaXMuZGF0YVtlXT0wLHRoaXMuZGF0YVtlKzFdPXIuYmx1ZSx0aGlzLmRhdGFbZSsyXT1yLmdyZWVuLHRoaXMuZGF0YVtlKzNdPXIucmVkLGUrPTR9O3RoaXMuZGF0YS5maWxsKDI1NSk7Zm9yKHZhciBlPTAscj10aGlzLmJvdHRvbV91cD90aGlzLmhlaWdodC0xOjA7ZTx0aGlzLmRhdGEubGVuZ3RoOyl7dmFyIG49dGhpcy5idWZmZXIucmVhZFVJbnQ4KHRoaXMucG9zKyspLGk9dGhpcy5idWZmZXIucmVhZFVJbnQ4KHRoaXMucG9zKyspO2lmKDA9PW4pe2lmKDA9PWkpe3RoaXMuYm90dG9tX3VwP3ItLTpyKyssZT1yKnRoaXMud2lkdGgqNDtjb250aW51ZX1pZigxPT1pKWJyZWFrO2lmKDI9PWkpe3ZhciBvPXRoaXMuYnVmZmVyLnJlYWRVSW50OCh0aGlzLnBvcysrKSxhPXRoaXMuYnVmZmVyLnJlYWRVSW50OCh0aGlzLnBvcysrKTt0aGlzLmJvdHRvbV91cD9yLT1hOnIrPWEsZSs9YSp0aGlzLndpZHRoKjQrNCpvfWVsc2V7Zm9yKHZhciBzPTA7czxpO3MrKyl7dmFyIHU9dGhpcy5idWZmZXIucmVhZFVJbnQ4KHRoaXMucG9zKyspO3QuY2FsbCh0aGlzLHUpfSEwJmkmJnRoaXMucG9zKyt9fWVsc2UgZm9yKHM9MDtzPG47cysrKXQuY2FsbCh0aGlzLGkpfX1lbHNle3ZhciBoPXRoaXMud2lkdGglNDtmb3IoYT10aGlzLmhlaWdodC0xO2E+PTA7YS0tKXt2YXIgZj10aGlzLmJvdHRvbV91cD9hOnRoaXMuaGVpZ2h0LTEtYTtmb3Iobz0wO288dGhpcy53aWR0aDtvKyspaWYoaT10aGlzLmJ1ZmZlci5yZWFkVUludDgodGhpcy5wb3MrKyksZT1mKnRoaXMud2lkdGgqNCs0Km8saTx0aGlzLnBhbGV0dGUubGVuZ3RoKXt2YXIgYz10aGlzLnBhbGV0dGVbaV07dGhpcy5kYXRhW2VdPTAsdGhpcy5kYXRhW2UrMV09Yy5ibHVlLHRoaXMuZGF0YVtlKzJdPWMuZ3JlZW4sdGhpcy5kYXRhW2UrM109Yy5yZWR9ZWxzZSB0aGlzLmRhdGFbZV09MCx0aGlzLmRhdGFbZSsxXT0yNTUsdGhpcy5kYXRhW2UrMl09MjU1LHRoaXMuZGF0YVtlKzNdPTI1NTswIT1oJiYodGhpcy5wb3MrPTQtaCl9fX0saS5wcm90b3R5cGUuYml0MTU9ZnVuY3Rpb24oKXtmb3IodmFyIHQ9dGhpcy53aWR0aCUzLGU9cGFyc2VJbnQoIjExMTExIiwyKSxyPXRoaXMuaGVpZ2h0LTE7cj49MDtyLS0pe2Zvcih2YXIgbj10aGlzLmJvdHRvbV91cD9yOnRoaXMuaGVpZ2h0LTEtcixpPTA7aTx0aGlzLndpZHRoO2krKyl7dmFyIG89dGhpcy5idWZmZXIucmVhZFVJbnQxNkxFKHRoaXMucG9zKTt0aGlzLnBvcys9Mjt2YXIgYT0obyZlKS9lKjI1NXwwLHM9KG8+PjUmZSkvZSoyNTV8MCx1PShvPj4xMCZlKS9lKjI1NXwwLGg9bz4+MTU/MjU1OjAsZj1uKnRoaXMud2lkdGgqNCs0Kmk7dGhpcy5kYXRhW2ZdPWgsdGhpcy5kYXRhW2YrMV09YSx0aGlzLmRhdGFbZisyXT1zLHRoaXMuZGF0YVtmKzNdPXV9dGhpcy5wb3MrPXR9fSxpLnByb3RvdHlwZS5iaXQxNj1mdW5jdGlvbigpe3ZhciB0PXRoaXMud2lkdGglMioyO3RoaXMubWFza1JlZD0zMTc0NCx0aGlzLm1hc2tHcmVlbj05OTIsdGhpcy5tYXNrQmx1ZT0zMSx0aGlzLm1hc2swPTAsMz09dGhpcy5jb21wcmVzcyYmKHRoaXMubWFza1JlZD10aGlzLmJ1ZmZlci5yZWFkVUludDMyTEUodGhpcy5wb3MpLHRoaXMucG9zKz00LHRoaXMubWFza0dyZWVuPXRoaXMuYnVmZmVyLnJlYWRVSW50MzJMRSh0aGlzLnBvcyksdGhpcy5wb3MrPTQsdGhpcy5tYXNrQmx1ZT10aGlzLmJ1ZmZlci5yZWFkVUludDMyTEUodGhpcy5wb3MpLHRoaXMucG9zKz00LHRoaXMubWFzazA9dGhpcy5idWZmZXIucmVhZFVJbnQzMkxFKHRoaXMucG9zKSx0aGlzLnBvcys9NCk7Zm9yKHZhciBlPVswLDAsMF0scj0wO3I8MTY7cisrKXRoaXMubWFza1JlZD4+ciYxJiZlWzBdKyssdGhpcy5tYXNrR3JlZW4+PnImMSYmZVsxXSsrLHRoaXMubWFza0JsdWU+PnImMSYmZVsyXSsrO2VbMV0rPWVbMF0sZVsyXSs9ZVsxXSxlWzBdPTgtZVswXSxlWzFdLT04LGVbMl0tPTg7Zm9yKHZhciBuPXRoaXMuaGVpZ2h0LTE7bj49MDtuLS0pe2Zvcih2YXIgaT10aGlzLmJvdHRvbV91cD9uOnRoaXMuaGVpZ2h0LTEtbixvPTA7bzx0aGlzLndpZHRoO28rKyl7dmFyIGE9dGhpcy5idWZmZXIucmVhZFVJbnQxNkxFKHRoaXMucG9zKTt0aGlzLnBvcys9Mjt2YXIgcz0oYSZ0aGlzLm1hc2tCbHVlKTw8ZVswXSx1PShhJnRoaXMubWFza0dyZWVuKT4+ZVsxXSxoPShhJnRoaXMubWFza1JlZCk+PmVbMl0sZj1pKnRoaXMud2lkdGgqNCs0Km87dGhpcy5kYXRhW2ZdPTAsdGhpcy5kYXRhW2YrMV09cyx0aGlzLmRhdGFbZisyXT11LHRoaXMuZGF0YVtmKzNdPWh9dGhpcy5wb3MrPXR9fSxpLnByb3RvdHlwZS5iaXQyND1mdW5jdGlvbigpe2Zvcih2YXIgdD10aGlzLmhlaWdodC0xO3Q+PTA7dC0tKXtmb3IodmFyIGU9dGhpcy5ib3R0b21fdXA/dDp0aGlzLmhlaWdodC0xLXQscj0wO3I8dGhpcy53aWR0aDtyKyspe3ZhciBuPXRoaXMuYnVmZmVyLnJlYWRVSW50OCh0aGlzLnBvcysrKSxpPXRoaXMuYnVmZmVyLnJlYWRVSW50OCh0aGlzLnBvcysrKSxvPXRoaXMuYnVmZmVyLnJlYWRVSW50OCh0aGlzLnBvcysrKSxhPWUqdGhpcy53aWR0aCo0KzQqcjt0aGlzLmRhdGFbYV09MCx0aGlzLmRhdGFbYSsxXT1uLHRoaXMuZGF0YVthKzJdPWksdGhpcy5kYXRhW2ErM109b310aGlzLnBvcys9dGhpcy53aWR0aCU0fX0saS5wcm90b3R5cGUuYml0MzI9ZnVuY3Rpb24oKXtpZigzPT10aGlzLmNvbXByZXNzKXt0aGlzLm1hc2tSZWQ9dGhpcy5idWZmZXIucmVhZFVJbnQzMkxFKHRoaXMucG9zKSx0aGlzLnBvcys9NCx0aGlzLm1hc2tHcmVlbj10aGlzLmJ1ZmZlci5yZWFkVUludDMyTEUodGhpcy5wb3MpLHRoaXMucG9zKz00LHRoaXMubWFza0JsdWU9dGhpcy5idWZmZXIucmVhZFVJbnQzMkxFKHRoaXMucG9zKSx0aGlzLnBvcys9NCx0aGlzLm1hc2swPXRoaXMuYnVmZmVyLnJlYWRVSW50MzJMRSh0aGlzLnBvcyksdGhpcy5wb3MrPTQ7Zm9yKHZhciB0PXRoaXMuaGVpZ2h0LTE7dD49MDt0LS0pZm9yKHZhciBlPXRoaXMuYm90dG9tX3VwP3Q6dGhpcy5oZWlnaHQtMS10LHI9MDtyPHRoaXMud2lkdGg7cisrKXt2YXIgbj10aGlzLmJ1ZmZlci5yZWFkVUludDgodGhpcy5wb3MrKyksaT10aGlzLmJ1ZmZlci5yZWFkVUludDgodGhpcy5wb3MrKyksbz10aGlzLmJ1ZmZlci5yZWFkVUludDgodGhpcy5wb3MrKyksYT10aGlzLmJ1ZmZlci5yZWFkVUludDgodGhpcy5wb3MrKykscz1lKnRoaXMud2lkdGgqNCs0KnI7dGhpcy5kYXRhW3NdPW4sdGhpcy5kYXRhW3MrMV09aSx0aGlzLmRhdGFbcysyXT1vLHRoaXMuZGF0YVtzKzNdPWF9fWVsc2UgZm9yKHQ9dGhpcy5oZWlnaHQtMTt0Pj0wO3QtLSlmb3IoZT10aGlzLmJvdHRvbV91cD90OnRoaXMuaGVpZ2h0LTEtdCxyPTA7cjx0aGlzLndpZHRoO3IrKylpPXRoaXMuYnVmZmVyLnJlYWRVSW50OCh0aGlzLnBvcysrKSxvPXRoaXMuYnVmZmVyLnJlYWRVSW50OCh0aGlzLnBvcysrKSxhPXRoaXMuYnVmZmVyLnJlYWRVSW50OCh0aGlzLnBvcysrKSxuPXRoaXMuYnVmZmVyLnJlYWRVSW50OCh0aGlzLnBvcysrKSxzPWUqdGhpcy53aWR0aCo0KzQqcix0aGlzLmRhdGFbc109bix0aGlzLmRhdGFbcysxXT1pLHRoaXMuZGF0YVtzKzJdPW8sdGhpcy5kYXRhW3MrM109YX0saS5wcm90b3R5cGUuZ2V0RGF0YT1mdW5jdGlvbigpe3JldHVybiB0aGlzLmRhdGF9LHQuZXhwb3J0cz1mdW5jdGlvbih0KXtyZXR1cm4gbmV3IGkodCl9fSw5Mzg6dD0+eyJ1c2Ugc3RyaWN0IjtmdW5jdGlvbiBlKHQpe3JldHVybiBlPSJmdW5jdGlvbiI9PXR5cGVvZiBTeW1ib2wmJiJzeW1ib2wiPT10eXBlb2YgU3ltYm9sLml0ZXJhdG9yP2Z1bmN0aW9uKHQpe3JldHVybiB0eXBlb2YgdH06ZnVuY3Rpb24odCl7cmV0dXJuIHQmJiJmdW5jdGlvbiI9PXR5cGVvZiBTeW1ib2wmJnQuY29uc3RydWN0b3I9PT1TeW1ib2wmJnQhPT1TeW1ib2wucHJvdG90eXBlPyJzeW1ib2wiOnR5cGVvZiB0fSxlKHQpfXQuZXhwb3J0cz1mdW5jdGlvbih0KXt2YXIgcj17fTtyZXR1cm4idW5kZWZpbmVkIiE9dHlwZW9mIFdvcmtlckdsb2JhbFNjb3BlP3IudHlwZT0id2Vid29ya2VyIjoib2JqZWN0Ij09PSgidW5kZWZpbmVkIj09dHlwZW9mIGRvY3VtZW50PyJ1bmRlZmluZWQiOmUoZG9jdW1lbnQpKT9yLnR5cGU9ImJyb3dzZXIiOiJvYmplY3QiPT09KCJ1bmRlZmluZWQiPT10eXBlb2YgcHJvY2Vzcz8idW5kZWZpbmVkIjplKHByb2Nlc3MpKSYmKHIudHlwZT0ibm9kZSIpLHZvaWQgMD09PXQ/cjpyW3RdfX0sOTY4OmZ1bmN0aW9uKHQsZSxyKXsidXNlIHN0cmljdCI7dmFyIG49dGhpcztmdW5jdGlvbiBpKHQpe3JldHVybiBpPSJmdW5jdGlvbiI9PXR5cGVvZiBTeW1ib2wmJiJzeW1ib2wiPT10eXBlb2YgU3ltYm9sLml0ZXJhdG9yP2Z1bmN0aW9uKHQpe3JldHVybiB0eXBlb2YgdH06ZnVuY3Rpb24odCl7cmV0dXJuIHQmJiJmdW5jdGlvbiI9PXR5cGVvZiBTeW1ib2wmJnQuY29uc3RydWN0b3I9PT1TeW1ib2wmJnQhPT1TeW1ib2wucHJvdG90eXBlPyJzeW1ib2wiOnR5cGVvZiB0fSxpKHQpfWZ1bmN0aW9uIG8odCxlKXt2YXIgcj1PYmplY3Qua2V5cyh0KTtpZihPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKXt2YXIgbj1PYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKHQpO2UmJihuPW4uZmlsdGVyKChmdW5jdGlvbihlKXtyZXR1cm4gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcih0LGUpLmVudW1lcmFibGV9KSkpLHIucHVzaC5hcHBseShyLG4pfXJldHVybiByfWZ1bmN0aW9uIGEodCl7Zm9yKHZhciBlPTE7ZTxhcmd1bWVudHMubGVuZ3RoO2UrKyl7dmFyIHI9bnVsbCE9YXJndW1lbnRzW2VdP2FyZ3VtZW50c1tlXTp7fTtlJTI/byhPYmplY3QociksITApLmZvckVhY2goKGZ1bmN0aW9uKGUpe3ModCxlLHJbZV0pfSkpOk9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzP09iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKHQsT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMocikpOm8oT2JqZWN0KHIpKS5mb3JFYWNoKChmdW5jdGlvbihlKXtPYmplY3QuZGVmaW5lUHJvcGVydHkodCxlLE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IocixlKSl9KSl9cmV0dXJuIHR9ZnVuY3Rpb24gcyh0LGUscil7cmV0dXJuKGU9ZnVuY3Rpb24odCl7dmFyIGU9ZnVuY3Rpb24odCl7aWYoIm9iamVjdCIhPWkodCl8fCF0KXJldHVybiB0O3ZhciBlPXRbU3ltYm9sLnRvUHJpbWl0aXZlXTtpZih2b2lkIDAhPT1lKXt2YXIgcj1lLmNhbGwodCwic3RyaW5nIik7aWYoIm9iamVjdCIhPWkocikpcmV0dXJuIHI7dGhyb3cgbmV3IFR5cGVFcnJvcigiQEB0b1ByaW1pdGl2ZSBtdXN0IHJldHVybiBhIHByaW1pdGl2ZSB2YWx1ZS4iKX1yZXR1cm4gU3RyaW5nKHQpfSh0KTtyZXR1cm4ic3ltYm9sIj09aShlKT9lOmUrIiJ9KGUpKWluIHQ/T2JqZWN0LmRlZmluZVByb3BlcnR5KHQsZSx7dmFsdWU6cixlbnVtZXJhYmxlOiEwLGNvbmZpZ3VyYWJsZTohMCx3cml0YWJsZTohMH0pOnRbZV09cix0fWZ1bmN0aW9uIHUodCxlKXsobnVsbD09ZXx8ZT50Lmxlbmd0aCkmJihlPXQubGVuZ3RoKTtmb3IodmFyIHI9MCxuPUFycmF5KGUpO3I8ZTtyKyspbltyXT10W3JdO3JldHVybiBufWZ1bmN0aW9uIGgoKXtoPWZ1bmN0aW9uKCl7cmV0dXJuIGV9O3ZhciB0LGU9e30scj1PYmplY3QucHJvdG90eXBlLG49ci5oYXNPd25Qcm9wZXJ0eSxvPU9iamVjdC5kZWZpbmVQcm9wZXJ0eXx8ZnVuY3Rpb24odCxlLHIpe3RbZV09ci52YWx1ZX0sYT0iZnVuY3Rpb24iPT10eXBlb2YgU3ltYm9sP1N5bWJvbDp7fSxzPWEuaXRlcmF0b3J8fCJAQGl0ZXJhdG9yIix1PWEuYXN5bmNJdGVyYXRvcnx8IkBAYXN5bmNJdGVyYXRvciIsZj1hLnRvU3RyaW5nVGFnfHwiQEB0b1N0cmluZ1RhZyI7ZnVuY3Rpb24gYyh0LGUscil7cmV0dXJuIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0LGUse3ZhbHVlOnIsZW51bWVyYWJsZTohMCxjb25maWd1cmFibGU6ITAsd3JpdGFibGU6ITB9KSx0W2VdfXRyeXtjKHt9LCIiKX1jYXRjaCh0KXtjPWZ1bmN0aW9uKHQsZSxyKXtyZXR1cm4gdFtlXT1yfX1mdW5jdGlvbiBsKHQsZSxyLG4pe3ZhciBpPWUmJmUucHJvdG90eXBlIGluc3RhbmNlb2Ygdz9lOncsYT1PYmplY3QuY3JlYXRlKGkucHJvdG90eXBlKSxzPW5ldyBqKG58fFtdKTtyZXR1cm4gbyhhLCJfaW52b2tlIix7dmFsdWU6Uyh0LHIscyl9KSxhfWZ1bmN0aW9uIHAodCxlLHIpe3RyeXtyZXR1cm57dHlwZToibm9ybWFsIixhcmc6dC5jYWxsKGUscil9fWNhdGNoKHQpe3JldHVybnt0eXBlOiJ0aHJvdyIsYXJnOnR9fX1lLndyYXA9bDt2YXIgeT0ic3VzcGVuZGVkU3RhcnQiLGQ9InN1c3BlbmRlZFlpZWxkIixnPSJleGVjdXRpbmciLGI9ImNvbXBsZXRlZCIsdj17fTtmdW5jdGlvbiB3KCl7fWZ1bmN0aW9uIG0oKXt9ZnVuY3Rpb24gQSgpe312YXIgRT17fTtjKEUscywoZnVuY3Rpb24oKXtyZXR1cm4gdGhpc30pKTt2YXIgaz1PYmplY3QuZ2V0UHJvdG90eXBlT2YseD1rJiZrKGsoUChbXSkpKTt4JiZ4IT09ciYmbi5jYWxsKHgscykmJihFPXgpO3ZhciBPPUEucHJvdG90eXBlPXcucHJvdG90eXBlPU9iamVjdC5jcmVhdGUoRSk7ZnVuY3Rpb24gSSh0KXtbIm5leHQiLCJ0aHJvdyIsInJldHVybiJdLmZvckVhY2goKGZ1bmN0aW9uKGUpe2ModCxlLChmdW5jdGlvbih0KXtyZXR1cm4gdGhpcy5faW52b2tlKGUsdCl9KSl9KSl9ZnVuY3Rpb24gVSh0LGUpe2Z1bmN0aW9uIHIobyxhLHMsdSl7dmFyIGg9cCh0W29dLHQsYSk7aWYoInRocm93IiE9PWgudHlwZSl7dmFyIGY9aC5hcmcsYz1mLnZhbHVlO3JldHVybiBjJiYib2JqZWN0Ij09aShjKSYmbi5jYWxsKGMsIl9fYXdhaXQiKT9lLnJlc29sdmUoYy5fX2F3YWl0KS50aGVuKChmdW5jdGlvbih0KXtyKCJuZXh0Iix0LHMsdSl9KSwoZnVuY3Rpb24odCl7cigidGhyb3ciLHQscyx1KX0pKTplLnJlc29sdmUoYykudGhlbigoZnVuY3Rpb24odCl7Zi52YWx1ZT10LHMoZil9KSwoZnVuY3Rpb24odCl7cmV0dXJuIHIoInRocm93Iix0LHMsdSl9KSl9dShoLmFyZyl9dmFyIGE7byh0aGlzLCJfaW52b2tlIix7dmFsdWU6ZnVuY3Rpb24odCxuKXtmdW5jdGlvbiBpKCl7cmV0dXJuIG5ldyBlKChmdW5jdGlvbihlLGkpe3IodCxuLGUsaSl9KSl9cmV0dXJuIGE9YT9hLnRoZW4oaSxpKTppKCl9fSl9ZnVuY3Rpb24gUyhlLHIsbil7dmFyIGk9eTtyZXR1cm4gZnVuY3Rpb24obyxhKXtpZihpPT09Zyl0aHJvdyBFcnJvcigiR2VuZXJhdG9yIGlzIGFscmVhZHkgcnVubmluZyIpO2lmKGk9PT1iKXtpZigidGhyb3ciPT09byl0aHJvdyBhO3JldHVybnt2YWx1ZTp0LGRvbmU6ITB9fWZvcihuLm1ldGhvZD1vLG4uYXJnPWE7Oyl7dmFyIHM9bi5kZWxlZ2F0ZTtpZihzKXt2YXIgdT1MKHMsbik7aWYodSl7aWYodT09PXYpY29udGludWU7cmV0dXJuIHV9fWlmKCJuZXh0Ij09PW4ubWV0aG9kKW4uc2VudD1uLl9zZW50PW4uYXJnO2Vsc2UgaWYoInRocm93Ij09PW4ubWV0aG9kKXtpZihpPT09eSl0aHJvdyBpPWIsbi5hcmc7bi5kaXNwYXRjaEV4Y2VwdGlvbihuLmFyZyl9ZWxzZSJyZXR1cm4iPT09bi5tZXRob2QmJm4uYWJydXB0KCJyZXR1cm4iLG4uYXJnKTtpPWc7dmFyIGg9cChlLHIsbik7aWYoIm5vcm1hbCI9PT1oLnR5cGUpe2lmKGk9bi5kb25lP2I6ZCxoLmFyZz09PXYpY29udGludWU7cmV0dXJue3ZhbHVlOmguYXJnLGRvbmU6bi5kb25lfX0idGhyb3ciPT09aC50eXBlJiYoaT1iLG4ubWV0aG9kPSJ0aHJvdyIsbi5hcmc9aC5hcmcpfX19ZnVuY3Rpb24gTChlLHIpe3ZhciBuPXIubWV0aG9kLGk9ZS5pdGVyYXRvcltuXTtpZihpPT09dClyZXR1cm4gci5kZWxlZ2F0ZT1udWxsLCJ0aHJvdyI9PT1uJiZlLml0ZXJhdG9yLnJldHVybiYmKHIubWV0aG9kPSJyZXR1cm4iLHIuYXJnPXQsTChlLHIpLCJ0aHJvdyI9PT1yLm1ldGhvZCl8fCJyZXR1cm4iIT09biYmKHIubWV0aG9kPSJ0aHJvdyIsci5hcmc9bmV3IFR5cGVFcnJvcigiVGhlIGl0ZXJhdG9yIGRvZXMgbm90IHByb3ZpZGUgYSAnIituKyInIG1ldGhvZCIpKSx2O3ZhciBvPXAoaSxlLml0ZXJhdG9yLHIuYXJnKTtpZigidGhyb3ciPT09by50eXBlKXJldHVybiByLm1ldGhvZD0idGhyb3ciLHIuYXJnPW8uYXJnLHIuZGVsZWdhdGU9bnVsbCx2O3ZhciBhPW8uYXJnO3JldHVybiBhP2EuZG9uZT8ocltlLnJlc3VsdE5hbWVdPWEudmFsdWUsci5uZXh0PWUubmV4dExvYywicmV0dXJuIiE9PXIubWV0aG9kJiYoci5tZXRob2Q9Im5leHQiLHIuYXJnPXQpLHIuZGVsZWdhdGU9bnVsbCx2KTphOihyLm1ldGhvZD0idGhyb3ciLHIuYXJnPW5ldyBUeXBlRXJyb3IoIml0ZXJhdG9yIHJlc3VsdCBpcyBub3QgYW4gb2JqZWN0Iiksci5kZWxlZ2F0ZT1udWxsLHYpfWZ1bmN0aW9uIEIodCl7dmFyIGU9e3RyeUxvYzp0WzBdfTsxIGluIHQmJihlLmNhdGNoTG9jPXRbMV0pLDIgaW4gdCYmKGUuZmluYWxseUxvYz10WzJdLGUuYWZ0ZXJMb2M9dFszXSksdGhpcy50cnlFbnRyaWVzLnB1c2goZSl9ZnVuY3Rpb24gXyh0KXt2YXIgZT10LmNvbXBsZXRpb258fHt9O2UudHlwZT0ibm9ybWFsIixkZWxldGUgZS5hcmcsdC5jb21wbGV0aW9uPWV9ZnVuY3Rpb24gaih0KXt0aGlzLnRyeUVudHJpZXM9W3t0cnlMb2M6InJvb3QifV0sdC5mb3JFYWNoKEIsdGhpcyksdGhpcy5yZXNldCghMCl9ZnVuY3Rpb24gUChlKXtpZihlfHwiIj09PWUpe3ZhciByPWVbc107aWYocilyZXR1cm4gci5jYWxsKGUpO2lmKCJmdW5jdGlvbiI9PXR5cGVvZiBlLm5leHQpcmV0dXJuIGU7aWYoIWlzTmFOKGUubGVuZ3RoKSl7dmFyIG89LTEsYT1mdW5jdGlvbiByKCl7Zm9yKDsrK288ZS5sZW5ndGg7KWlmKG4uY2FsbChlLG8pKXJldHVybiByLnZhbHVlPWVbb10sci5kb25lPSExLHI7cmV0dXJuIHIudmFsdWU9dCxyLmRvbmU9ITAscn07cmV0dXJuIGEubmV4dD1hfX10aHJvdyBuZXcgVHlwZUVycm9yKGkoZSkrIiBpcyBub3QgaXRlcmFibGUiKX1yZXR1cm4gbS5wcm90b3R5cGU9QSxvKE8sImNvbnN0cnVjdG9yIix7dmFsdWU6QSxjb25maWd1cmFibGU6ITB9KSxvKEEsImNvbnN0cnVjdG9yIix7dmFsdWU6bSxjb25maWd1cmFibGU6ITB9KSxtLmRpc3BsYXlOYW1lPWMoQSxmLCJHZW5lcmF0b3JGdW5jdGlvbiIpLGUuaXNHZW5lcmF0b3JGdW5jdGlvbj1mdW5jdGlvbih0KXt2YXIgZT0iZnVuY3Rpb24iPT10eXBlb2YgdCYmdC5jb25zdHJ1Y3RvcjtyZXR1cm4hIWUmJihlPT09bXx8IkdlbmVyYXRvckZ1bmN0aW9uIj09PShlLmRpc3BsYXlOYW1lfHxlLm5hbWUpKX0sZS5tYXJrPWZ1bmN0aW9uKHQpe3JldHVybiBPYmplY3Quc2V0UHJvdG90eXBlT2Y/T2JqZWN0LnNldFByb3RvdHlwZU9mKHQsQSk6KHQuX19wcm90b19fPUEsYyh0LGYsIkdlbmVyYXRvckZ1bmN0aW9uIikpLHQucHJvdG90eXBlPU9iamVjdC5jcmVhdGUoTyksdH0sZS5hd3JhcD1mdW5jdGlvbih0KXtyZXR1cm57X19hd2FpdDp0fX0sSShVLnByb3RvdHlwZSksYyhVLnByb3RvdHlwZSx1LChmdW5jdGlvbigpe3JldHVybiB0aGlzfSkpLGUuQXN5bmNJdGVyYXRvcj1VLGUuYXN5bmM9ZnVuY3Rpb24odCxyLG4saSxvKXt2b2lkIDA9PT1vJiYobz1Qcm9taXNlKTt2YXIgYT1uZXcgVShsKHQscixuLGkpLG8pO3JldHVybiBlLmlzR2VuZXJhdG9yRnVuY3Rpb24ocik/YTphLm5leHQoKS50aGVuKChmdW5jdGlvbih0KXtyZXR1cm4gdC5kb25lP3QudmFsdWU6YS5uZXh0KCl9KSl9LEkoTyksYyhPLGYsIkdlbmVyYXRvciIpLGMoTyxzLChmdW5jdGlvbigpe3JldHVybiB0aGlzfSkpLGMoTywidG9TdHJpbmciLChmdW5jdGlvbigpe3JldHVybiJbb2JqZWN0IEdlbmVyYXRvcl0ifSkpLGUua2V5cz1mdW5jdGlvbih0KXt2YXIgZT1PYmplY3QodCkscj1bXTtmb3IodmFyIG4gaW4gZSlyLnB1c2gobik7cmV0dXJuIHIucmV2ZXJzZSgpLGZ1bmN0aW9uIHQoKXtmb3IoO3IubGVuZ3RoOyl7dmFyIG49ci5wb3AoKTtpZihuIGluIGUpcmV0dXJuIHQudmFsdWU9bix0LmRvbmU9ITEsdH1yZXR1cm4gdC5kb25lPSEwLHR9fSxlLnZhbHVlcz1QLGoucHJvdG90eXBlPXtjb25zdHJ1Y3RvcjpqLHJlc2V0OmZ1bmN0aW9uKGUpe2lmKHRoaXMucHJldj0wLHRoaXMubmV4dD0wLHRoaXMuc2VudD10aGlzLl9zZW50PXQsdGhpcy5kb25lPSExLHRoaXMuZGVsZWdhdGU9bnVsbCx0aGlzLm1ldGhvZD0ibmV4dCIsdGhpcy5hcmc9dCx0aGlzLnRyeUVudHJpZXMuZm9yRWFjaChfKSwhZSlmb3IodmFyIHIgaW4gdGhpcykidCI9PT1yLmNoYXJBdCgwKSYmbi5jYWxsKHRoaXMscikmJiFpc05hTigrci5zbGljZSgxKSkmJih0aGlzW3JdPXQpfSxzdG9wOmZ1bmN0aW9uKCl7dGhpcy5kb25lPSEwO3ZhciB0PXRoaXMudHJ5RW50cmllc1swXS5jb21wbGV0aW9uO2lmKCJ0aHJvdyI9PT10LnR5cGUpdGhyb3cgdC5hcmc7cmV0dXJuIHRoaXMucnZhbH0sZGlzcGF0Y2hFeGNlcHRpb246ZnVuY3Rpb24oZSl7aWYodGhpcy5kb25lKXRocm93IGU7dmFyIHI9dGhpcztmdW5jdGlvbiBpKG4saSl7cmV0dXJuIHMudHlwZT0idGhyb3ciLHMuYXJnPWUsci5uZXh0PW4saSYmKHIubWV0aG9kPSJuZXh0IixyLmFyZz10KSwhIWl9Zm9yKHZhciBvPXRoaXMudHJ5RW50cmllcy5sZW5ndGgtMTtvPj0wOy0tbyl7dmFyIGE9dGhpcy50cnlFbnRyaWVzW29dLHM9YS5jb21wbGV0aW9uO2lmKCJyb290Ij09PWEudHJ5TG9jKXJldHVybiBpKCJlbmQiKTtpZihhLnRyeUxvYzw9dGhpcy5wcmV2KXt2YXIgdT1uLmNhbGwoYSwiY2F0Y2hMb2MiKSxoPW4uY2FsbChhLCJmaW5hbGx5TG9jIik7aWYodSYmaCl7aWYodGhpcy5wcmV2PGEuY2F0Y2hMb2MpcmV0dXJuIGkoYS5jYXRjaExvYywhMCk7aWYodGhpcy5wcmV2PGEuZmluYWxseUxvYylyZXR1cm4gaShhLmZpbmFsbHlMb2MpfWVsc2UgaWYodSl7aWYodGhpcy5wcmV2PGEuY2F0Y2hMb2MpcmV0dXJuIGkoYS5jYXRjaExvYywhMCl9ZWxzZXtpZighaCl0aHJvdyBFcnJvcigidHJ5IHN0YXRlbWVudCB3aXRob3V0IGNhdGNoIG9yIGZpbmFsbHkiKTtpZih0aGlzLnByZXY8YS5maW5hbGx5TG9jKXJldHVybiBpKGEuZmluYWxseUxvYyl9fX19LGFicnVwdDpmdW5jdGlvbih0LGUpe2Zvcih2YXIgcj10aGlzLnRyeUVudHJpZXMubGVuZ3RoLTE7cj49MDstLXIpe3ZhciBpPXRoaXMudHJ5RW50cmllc1tyXTtpZihpLnRyeUxvYzw9dGhpcy5wcmV2JiZuLmNhbGwoaSwiZmluYWxseUxvYyIpJiZ0aGlzLnByZXY8aS5maW5hbGx5TG9jKXt2YXIgbz1pO2JyZWFrfX1vJiYoImJyZWFrIj09PXR8fCJjb250aW51ZSI9PT10KSYmby50cnlMb2M8PWUmJmU8PW8uZmluYWxseUxvYyYmKG89bnVsbCk7dmFyIGE9bz9vLmNvbXBsZXRpb246e307cmV0dXJuIGEudHlwZT10LGEuYXJnPWUsbz8odGhpcy5tZXRob2Q9Im5leHQiLHRoaXMubmV4dD1vLmZpbmFsbHlMb2Msdik6dGhpcy5jb21wbGV0ZShhKX0sY29tcGxldGU6ZnVuY3Rpb24odCxlKXtpZigidGhyb3ciPT09dC50eXBlKXRocm93IHQuYXJnO3JldHVybiJicmVhayI9PT10LnR5cGV8fCJjb250aW51ZSI9PT10LnR5cGU/dGhpcy5uZXh0PXQuYXJnOiJyZXR1cm4iPT09dC50eXBlPyh0aGlzLnJ2YWw9dGhpcy5hcmc9dC5hcmcsdGhpcy5tZXRob2Q9InJldHVybiIsdGhpcy5uZXh0PSJlbmQiKToibm9ybWFsIj09PXQudHlwZSYmZSYmKHRoaXMubmV4dD1lKSx2fSxmaW5pc2g6ZnVuY3Rpb24odCl7Zm9yKHZhciBlPXRoaXMudHJ5RW50cmllcy5sZW5ndGgtMTtlPj0wOy0tZSl7dmFyIHI9dGhpcy50cnlFbnRyaWVzW2VdO2lmKHIuZmluYWxseUxvYz09PXQpcmV0dXJuIHRoaXMuY29tcGxldGUoci5jb21wbGV0aW9uLHIuYWZ0ZXJMb2MpLF8ociksdn19LGNhdGNoOmZ1bmN0aW9uKHQpe2Zvcih2YXIgZT10aGlzLnRyeUVudHJpZXMubGVuZ3RoLTE7ZT49MDstLWUpe3ZhciByPXRoaXMudHJ5RW50cmllc1tlXTtpZihyLnRyeUxvYz09PXQpe3ZhciBuPXIuY29tcGxldGlvbjtpZigidGhyb3ciPT09bi50eXBlKXt2YXIgaT1uLmFyZztfKHIpfXJldHVybiBpfX10aHJvdyBFcnJvcigiaWxsZWdhbCBjYXRjaCBhdHRlbXB0Iil9LGRlbGVnYXRlWWllbGQ6ZnVuY3Rpb24oZSxyLG4pe3JldHVybiB0aGlzLmRlbGVnYXRlPXtpdGVyYXRvcjpQKGUpLHJlc3VsdE5hbWU6cixuZXh0TG9jOm59LCJuZXh0Ij09PXRoaXMubWV0aG9kJiYodGhpcy5hcmc9dCksdn19LGV9ZnVuY3Rpb24gZih0LGUscixuLGksbyxhKXt0cnl7dmFyIHM9dFtvXShhKSx1PXMudmFsdWV9Y2F0Y2godCl7cmV0dXJuIHZvaWQgcih0KX1zLmRvbmU/ZSh1KTpQcm9taXNlLnJlc29sdmUodSkudGhlbihuLGkpfWZ1bmN0aW9uIGModCl7cmV0dXJuIGZ1bmN0aW9uKCl7dmFyIGU9dGhpcyxyPWFyZ3VtZW50cztyZXR1cm4gbmV3IFByb21pc2UoKGZ1bmN0aW9uKG4saSl7dmFyIG89dC5hcHBseShlLHIpO2Z1bmN0aW9uIGEodCl7ZihvLG4saSxhLHMsIm5leHQiLHQpfWZ1bmN0aW9uIHModCl7ZihvLG4saSxhLHMsInRocm93Iix0KX1hKHZvaWQgMCl9KSl9fXIoMzApO3ZhciBsLHAseSxkLGc9cig0NDMpLGI9cigzMzQpLHY9cig5MzgpKCJ0eXBlIiksdz1yKDMyOSksbT1yKDY3MCksQT1yKDY1KSxFPUEubG9nLGs9QS5zZXRMb2dnaW5nLHg9cig5NzEpLE89bnVsbCxJPXt9LFU9e30sUz0hMSxMPWZ1bmN0aW9uKCl7dmFyIHQ9YyhoKCkubWFyaygoZnVuY3Rpb24gdChlLHIpe3ZhciBuLGksbyxhLHMsdSxmLGM7cmV0dXJuIGgoKS53cmFwKChmdW5jdGlvbih0KXtmb3IoOzspc3dpdGNoKHQucHJldj10Lm5leHQpe2Nhc2UgMDppZihuPWUud29ya2VySWQsaT1lLmpvYklkLG89ZS5wYXlsb2FkLm9wdGlvbnMsYT1vLmxzdG1Pbmx5LHM9by5jb3JlUGF0aCx1PW8ubG9nZ2luZyxrKHUpLGY9ImluaXRpYWxpemluZyB0ZXNzZXJhY3QiLGwpe3QubmV4dD0xMTticmVha31yZXR1cm4gdC5uZXh0PTYsSS5nZXRDb3JlKGEscyxyKTtjYXNlIDY6Yz10LnNlbnQsci5wcm9ncmVzcyh7d29ya2VySWQ6bixzdGF0dXM6Zixwcm9ncmVzczowfSksYyh7VGVzc2VyYWN0UHJvZ3Jlc3M6ZnVuY3Rpb24odCl7cC5wcm9ncmVzcyh7d29ya2VySWQ6bixqb2JJZDppLHN0YXR1czoicmVjb2duaXppbmcgdGV4dCIscHJvZ3Jlc3M6TWF0aC5tYXgoMCwodC0zMCkvNzApfSl9fSkudGhlbigoZnVuY3Rpb24odCl7bD10LHIucHJvZ3Jlc3Moe3dvcmtlcklkOm4sc3RhdHVzOmYscHJvZ3Jlc3M6MX0pLHIucmVzb2x2ZSh7bG9hZGVkOiEwfSl9KSksdC5uZXh0PTEyO2JyZWFrO2Nhc2UgMTE6ci5yZXNvbHZlKHtsb2FkZWQ6ITB9KTtjYXNlIDEyOmNhc2UiZW5kIjpyZXR1cm4gdC5zdG9wKCl9fSksdCl9KSkpO3JldHVybiBmdW5jdGlvbihlLHIpe3JldHVybiB0LmFwcGx5KHRoaXMsYXJndW1lbnRzKX19KCksQj1mdW5jdGlvbigpe3ZhciB0PWMoaCgpLm1hcmsoKGZ1bmN0aW9uIHQoZSxyKXt2YXIgbixpLG8sYSxzO3JldHVybiBoKCkud3JhcCgoZnVuY3Rpb24odCl7Zm9yKDs7KXN3aXRjaCh0LnByZXY9dC5uZXh0KXtjYXNlIDA6aT1lLndvcmtlcklkLG89ZS5wYXlsb2FkLGE9by5tZXRob2Qscz1vLmFyZ3MsRSgiWyIuY29uY2F0KGksIl06IEZTLiIpLmNvbmNhdChhKSksci5yZXNvbHZlKChuPWwuRlMpW2FdLmFwcGx5KG4sZnVuY3Rpb24odCl7aWYoQXJyYXkuaXNBcnJheSh0KSlyZXR1cm4gdSh0KX0oaD1zKXx8ZnVuY3Rpb24odCl7aWYoInVuZGVmaW5lZCIhPXR5cGVvZiBTeW1ib2wmJm51bGwhPXRbU3ltYm9sLml0ZXJhdG9yXXx8bnVsbCE9dFsiQEBpdGVyYXRvciJdKXJldHVybiBBcnJheS5mcm9tKHQpfShoKXx8ZnVuY3Rpb24odCxlKXtpZih0KXtpZigic3RyaW5nIj09dHlwZW9mIHQpcmV0dXJuIHUodCxlKTt2YXIgcj17fS50b1N0cmluZy5jYWxsKHQpLnNsaWNlKDgsLTEpO3JldHVybiJPYmplY3QiPT09ciYmdC5jb25zdHJ1Y3RvciYmKHI9dC5jb25zdHJ1Y3Rvci5uYW1lKSwiTWFwIj09PXJ8fCJTZXQiPT09cj9BcnJheS5mcm9tKHQpOiJBcmd1bWVudHMiPT09cnx8L14oPzpVaXxJKW50KD86OHwxNnwzMikoPzpDbGFtcGVkKT9BcnJheSQvLnRlc3Qocik/dSh0LGUpOnZvaWQgMH19KGgpfHxmdW5jdGlvbigpe3Rocm93IG5ldyBUeXBlRXJyb3IoIkludmFsaWQgYXR0ZW1wdCB0byBzcHJlYWQgbm9uLWl0ZXJhYmxlIGluc3RhbmNlLlxuSW4gb3JkZXIgdG8gYmUgaXRlcmFibGUsIG5vbi1hcnJheSBvYmplY3RzIG11c3QgaGF2ZSBhIFtTeW1ib2wuaXRlcmF0b3JdKCkgbWV0aG9kLiIpfSgpKSk7Y2FzZSAzOmNhc2UiZW5kIjpyZXR1cm4gdC5zdG9wKCl9dmFyIGh9KSx0KX0pKSk7cmV0dXJuIGZ1bmN0aW9uKGUscil7cmV0dXJuIHQuYXBwbHkodGhpcyxhcmd1bWVudHMpfX0oKSxfPWZ1bmN0aW9uKCl7dmFyIHQ9YyhoKCkubWFyaygoZnVuY3Rpb24gdChlLHIpe3ZhciBuLGksbyxhLHMsdSxmLHAsYix3LG0sQSxrLHgsTztyZXR1cm4gaCgpLndyYXAoKGZ1bmN0aW9uKHQpe2Zvcig7Oylzd2l0Y2godC5wcmV2PXQubmV4dCl7Y2FzZSAwOnJldHVybiBuPWUud29ya2VySWQsaT1lLnBheWxvYWQsbz1pLmxhbmdzLGE9aS5vcHRpb25zLHM9YS5sYW5nUGF0aCx1PWEuZGF0YVBhdGgsZj1hLmNhY2hlUGF0aCxwPWEuY2FjaGVNZXRob2QsYj1hLmd6aXAsdz12b2lkIDA9PT1ifHxiLG09YS5sc3RtT25seSx5PW8sZD17bGFuZ1BhdGg6cyxkYXRhUGF0aDp1LGNhY2hlUGF0aDpmLGNhY2hlTWV0aG9kOnAsZ3ppcDp3LGxzdG1Pbmx5Om19LEE9ImxvYWRpbmcgbGFuZ3VhZ2UgdHJhaW5lZGRhdGEiLGs9InN0cmluZyI9PXR5cGVvZiBvP28uc3BsaXQoIisiKTpvLHg9MCxPPWZ1bmN0aW9uKCl7dmFyIHQ9YyhoKCkubWFyaygoZnVuY3Rpb24gdChlKXt2YXIgaSxvLGEsYyx5LGQsYixPLFU7cmV0dXJuIGgoKS53cmFwKChmdW5jdGlvbih0KXtmb3IoOzspc3dpdGNoKHQucHJldj10Lm5leHQpe2Nhc2UgMDpyZXR1cm4gaT0ic3RyaW5nIj09dHlwZW9mIGU/ZTplLmNvZGUsbz1bInJlZnJlc2giLCJub25lIl0uaW5jbHVkZXMocCk/ZnVuY3Rpb24oKXtyZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCl9OkkucmVhZENhY2hlLGE9bnVsbCxjPSExLHQucHJldj00LHQubmV4dD03LG8oIiIuY29uY2F0KGZ8fCIuIiwiLyIpLmNvbmNhdChpLCIudHJhaW5lZGRhdGEiKSk7Y2FzZSA3OmlmKHZvaWQgMD09PSh5PXQuc2VudCkpe3QubmV4dD0xNDticmVha31FKCJbIi5jb25jYXQobiwiXTogTG9hZCAiKS5jb25jYXQoaSwiLnRyYWluZWRkYXRhIGZyb20gY2FjaGUiKSksYT15LFM9ITAsdC5uZXh0PTE1O2JyZWFrO2Nhc2UgMTQ6dGhyb3cgRXJyb3IoIk5vdCBmb3VuZCBpbiBjYWNoZSIpO2Nhc2UgMTU6dC5uZXh0PTQ1O2JyZWFrO2Nhc2UgMTc6aWYodC5wcmV2PTE3LHQudDA9dC5jYXRjaCg0KSxjPSEwLEUoIlsiLmNvbmNhdChuLCJdOiBMb2FkICIpLmNvbmNhdChpLCIudHJhaW5lZGRhdGEgZnJvbSAiKS5jb25jYXQocykpLCJzdHJpbmciIT10eXBlb2YgZSl7dC5uZXh0PTQ0O2JyZWFrfWlmKGQ9bnVsbCxiPXN8fCJodHRwczovL2Nkbi5qc2RlbGl2ci5uZXQvbnBtL0B0ZXNzZXJhY3QuanMtZGF0YS8iLmNvbmNhdChpLG0/Ii80LjAuMF9iZXN0X2ludCI6Ii80LjAuMCIpLCgibm9kZSIhPT12fHxnKGIpfHxiLnN0YXJ0c1dpdGgoIm1vei1leHRlbnNpb246Ly8iKXx8Yi5zdGFydHNXaXRoKCJjaHJvbWUtZXh0ZW5zaW9uOi8vIil8fGIuc3RhcnRzV2l0aCgiZmlsZTovLyIpKSYmKGQ9Yi5yZXBsYWNlKC9cLyQvLCIiKSksbnVsbD09PWQpe3QubmV4dD0zOTticmVha31yZXR1cm4gTz0iIi5jb25jYXQoZCwiLyIpLmNvbmNhdChpLCIudHJhaW5lZGRhdGEiKS5jb25jYXQodz8iLmd6IjoiIiksdC5uZXh0PTI5LCgid2Vid29ya2VyIj09PXY/ZmV0Y2g6SS5mZXRjaCkoTyk7Y2FzZSAyOTppZigoVT10LnNlbnQpLm9rKXt0Lm5leHQ9MzI7YnJlYWt9dGhyb3cgRXJyb3IoIk5ldHdvcmsgZXJyb3Igd2hpbGUgZmV0Y2hpbmcgIi5jb25jYXQoTywiLiBSZXNwb25zZSBjb2RlOiAiKS5jb25jYXQoVS5zdGF0dXMpKTtjYXNlIDMyOnJldHVybiB0LnQxPVVpbnQ4QXJyYXksdC5uZXh0PTM1LFUuYXJyYXlCdWZmZXIoKTtjYXNlIDM1OnQudDI9dC5zZW50LGE9bmV3IHQudDEodC50MiksdC5uZXh0PTQyO2JyZWFrO2Nhc2UgMzk6cmV0dXJuIHQubmV4dD00MSxJLnJlYWRDYWNoZSgiIi5jb25jYXQoYiwiLyIpLmNvbmNhdChpLCIudHJhaW5lZGRhdGEiKS5jb25jYXQodz8iLmd6IjoiIikpO2Nhc2UgNDE6YT10LnNlbnQ7Y2FzZSA0Mjp0Lm5leHQ9NDU7YnJlYWs7Y2FzZSA0NDphPWUuZGF0YTtjYXNlIDQ1OmlmKHgrPS41L2subGVuZ3RoLHImJnIucHJvZ3Jlc3Moe3dvcmtlcklkOm4sc3RhdHVzOkEscHJvZ3Jlc3M6eH0pLCgzMT09PWFbMF0mJjEzOT09PWFbMV18fDMxPT09YVsxXSYmMTM5PT09YVswXSkmJihhPUkuZ3VuemlwKGEpKSxsKXtpZih1KXRyeXtsLkZTLm1rZGlyKHUpfWNhdGNoKHQpe3ImJnIucmVqZWN0KHQudG9TdHJpbmcoKSl9bC5GUy53cml0ZUZpbGUoIiIuY29uY2F0KHV8fCIuIiwiLyIpLmNvbmNhdChpLCIudHJhaW5lZGRhdGEiKSxhKX1pZighY3x8IVsid3JpdGUiLCJyZWZyZXNoIix2b2lkIDBdLmluY2x1ZGVzKHApKXt0Lm5leHQ9NjA7YnJlYWt9cmV0dXJuIHQucHJldj01MSx0Lm5leHQ9NTQsSS53cml0ZUNhY2hlKCIiLmNvbmNhdChmfHwiLiIsIi8iKS5jb25jYXQoaSwiLnRyYWluZWRkYXRhIiksYSk7Y2FzZSA1NDp0Lm5leHQ9NjA7YnJlYWs7Y2FzZSA1Njp0LnByZXY9NTYsdC50Mz10LmNhdGNoKDUxKSxFKCJbIi5jb25jYXQobiwiXTogRmFpbGVkIHRvIHdyaXRlICIpLmNvbmNhdChpLCIudHJhaW5lZGRhdGEgdG8gY2FjaGUgZHVlIHRvIGVycm9yOiIpKSxFKHQudDMudG9TdHJpbmcoKSk7Y2FzZSA2MDp4Kz0uNS9rLmxlbmd0aCwxMDA9PT1NYXRoLnJvdW5kKDEwMCp4KSYmKHg9MSksciYmci5wcm9ncmVzcyh7d29ya2VySWQ6bixzdGF0dXM6QSxwcm9ncmVzczp4fSk7Y2FzZSA2MzpjYXNlImVuZCI6cmV0dXJuIHQuc3RvcCgpfX0pLHQsbnVsbCxbWzQsMTddLFs1MSw1Nl1dKX0pKSk7cmV0dXJuIGZ1bmN0aW9uKGUpe3JldHVybiB0LmFwcGx5KHRoaXMsYXJndW1lbnRzKX19KCksciYmci5wcm9ncmVzcyh7d29ya2VySWQ6bixzdGF0dXM6QSxwcm9ncmVzczowfSksdC5wcmV2PTgsdC5uZXh0PTExLFByb21pc2UuYWxsKGsubWFwKE8pKTtjYXNlIDExOnImJnIucmVzb2x2ZShvKSx0Lm5leHQ9MTc7YnJlYWs7Y2FzZSAxNDp0LnByZXY9MTQsdC50MD10LmNhdGNoKDgpLHImJnIucmVqZWN0KHQudDAudG9TdHJpbmcoKSk7Y2FzZSAxNzpjYXNlImVuZCI6cmV0dXJuIHQuc3RvcCgpfX0pLHQsbnVsbCxbWzgsMTRdXSl9KSkpO3JldHVybiBmdW5jdGlvbihlLHIpe3JldHVybiB0LmFwcGx5KHRoaXMsYXJndW1lbnRzKX19KCksaj1mdW5jdGlvbigpe3ZhciB0PWMoaCgpLm1hcmsoKGZ1bmN0aW9uIHQoZSxyKXt2YXIgbixpLG87cmV0dXJuIGgoKS53cmFwKChmdW5jdGlvbih0KXtmb3IoOzspc3dpdGNoKHQucHJldj10Lm5leHQpe2Nhc2UgMDpuPWUucGF5bG9hZC5wYXJhbXMsaT1bImFtYmlnc19kZWJ1Z19sZXZlbCIsInVzZXJfd29yZHNfc3VmZml4IiwidXNlcl9wYXR0ZXJuc19zdWZmaXgiLCJ1c2VyX3BhdHRlcm5zX3N1ZmZpeCIsImxvYWRfc3lzdGVtX2Rhd2ciLCJsb2FkX2ZyZXFfZGF3ZyIsImxvYWRfdW5hbWJpZ19kYXdnIiwibG9hZF9wdW5jX2Rhd2ciLCJsb2FkX251bWJlcl9kYXdnIiwibG9hZF9iaWdyYW1fZGF3ZyIsInRlc3NlZGl0X29jcl9lbmdpbmVfbW9kZSIsInRlc3NlZGl0X2luaXRfY29uZmlnX29ubHkiLCJsYW5ndWFnZV9tb2RlbF9uZ3JhbV9vbiIsImxhbmd1YWdlX21vZGVsX3VzZV9zaWdtb2lkYWxfY2VydGFpbnR5Il0sKG89T2JqZWN0LmtleXMobikuZmlsdGVyKChmdW5jdGlvbih0KXtyZXR1cm4gaS5pbmNsdWRlcyh0KX0pKS5qb2luKCIsICIpKS5sZW5ndGg+MCYmY29uc29sZS5sb2coIkF0dGVtcHRlZCB0byBzZXQgcGFyYW1ldGVycyB0aGF0IGNhbiBvbmx5IGJlIHNldCBkdXJpbmcgaW5pdGlhbGl6YXRpb246ICIuY29uY2F0KG8pKSxPYmplY3Qua2V5cyhuKS5maWx0ZXIoKGZ1bmN0aW9uKHQpe3JldHVybiF0LnN0YXJ0c1dpdGgoInRlc3Nqc18iKX0pKS5mb3JFYWNoKChmdW5jdGlvbih0KXtPLlNldFZhcmlhYmxlKHQsblt0XSl9KSksVT1hKGEoe30sVSksbiksdm9pZCAwIT09ciYmci5yZXNvbHZlKFUpO2Nhc2UgNzpjYXNlImVuZCI6cmV0dXJuIHQuc3RvcCgpfX0pLHQpfSkpKTtyZXR1cm4gZnVuY3Rpb24oZSxyKXtyZXR1cm4gdC5hcHBseSh0aGlzLGFyZ3VtZW50cyl9fSgpLFA9ZnVuY3Rpb24oKXt2YXIgdD1jKGgoKS5tYXJrKChmdW5jdGlvbiB0KGUscil7dmFyIG4sbyxhLHMsdSxmLGMscCxnLGIsdix3LG0sQTtyZXR1cm4gaCgpLndyYXAoKGZ1bmN0aW9uKHQpe2Zvcig7Oylzd2l0Y2godC5wcmV2PXQubmV4dCl7Y2FzZSAwOmlmKG49ZS53b3JrZXJJZCxvPWUucGF5bG9hZCxhPW8ubGFuZ3Mscz1vLm9lbSx1PW8uY29uZmlnLGY9InN0cmluZyI9PXR5cGVvZiBhP2E6YS5tYXAoKGZ1bmN0aW9uKHQpe3JldHVybiJzdHJpbmciPT10eXBlb2YgdD90OnQuZGF0YX0pKS5qb2luKCIrIiksYz0iaW5pdGlhbGl6aW5nIGFwaSIsdC5wcmV2PTMsci5wcm9ncmVzcyh7d29ya2VySWQ6bixzdGF0dXM6Yyxwcm9ncmVzczowfSksbnVsbCE9PU8mJk8uRW5kKCksdSYmIm9iamVjdCI9PT1pKHUpJiZPYmplY3Qua2V5cyh1KS5sZW5ndGg+MD9nPUpTT04uc3RyaW5naWZ5KHUpLnJlcGxhY2UoLywvZywiXG4iKS5yZXBsYWNlKC86L2csIiAiKS5yZXBsYWNlKC9bIid7fV0vZywiIik6dSYmInN0cmluZyI9PXR5cGVvZiB1JiYoZz11KSwic3RyaW5nIj09dHlwZW9mIGcmJihwPSIvY29uZmlnIixsLkZTLndyaXRlRmlsZShwLGcpKSxPPW5ldyBsLlRlc3NCYXNlQVBJLC0xIT09KGI9Ty5Jbml0KG51bGwsZixzLHApKSl7dC5uZXh0PTMwO2JyZWFrfWlmKCFbIndyaXRlIiwicmVmcmVzaCIsdm9pZCAwXS5pbmNsdWRlcyhkLmNhY2hlTWV0aG9kKSl7dC5uZXh0PTMwO2JyZWFrfXJldHVybiB2PWYuc3BsaXQoIisiKSx3PXYubWFwKChmdW5jdGlvbih0KXtyZXR1cm4gSS5kZWxldGVDYWNoZSgiIi5jb25jYXQoZC5jYWNoZVBhdGh8fCIuIiwiLyIpLmNvbmNhdCh0LCIudHJhaW5lZGRhdGEiKSl9KSksdC5uZXh0PTE2LFByb21pc2UuYWxsKHcpO2Nhc2UgMTY6aWYobT1sLkZTLnJlYWRGaWxlKCIvZGVidWdEZXYudHh0Iix7ZW5jb2Rpbmc6InV0ZjgiLGZsYWdzOiJhKyJ9KSwhU3x8IS9jb21wb25lbnRzIGFyZSBub3QgcHJlc2VudC8udGVzdChtKSl7dC5uZXh0PTMwO2JyZWFrfXJldHVybiBFKCJEYXRhIGZyb20gY2FjaGUgbWlzc2luZyByZXF1ZXN0ZWQgT0VNIG1vZGVsLiBBdHRlbXB0aW5nIHRvIHJlZnJlc2ggY2FjaGUgd2l0aCBuZXcgbGFuZ3VhZ2UgZGF0YS4iKSx0Lm5leHQ9MjEsXyh7d29ya2VySWQ6bixwYXlsb2FkOntsYW5nczp5LG9wdGlvbnM6ZH19KTtjYXNlIDIxOmlmKC0xIT09KGI9Ty5Jbml0KG51bGwsZixzLHApKSl7dC5uZXh0PTI5O2JyZWFrfXJldHVybiBFKCJMYW5ndWFnZSBkYXRhIHJlZnJlc2ggZmFpbGVkLiIpLEE9di5tYXAoKGZ1bmN0aW9uKHQpe3JldHVybiBJLmRlbGV0ZUNhY2hlKCIiLmNvbmNhdChkLmNhY2hlUGF0aHx8Ii4iLCIvIikuY29uY2F0KHQsIi50cmFpbmVkZGF0YSIpKX0pKSx0Lm5leHQ9MjcsUHJvbWlzZS5hbGwoQSk7Y2FzZSAyNzp0Lm5leHQ9MzA7YnJlYWs7Y2FzZSAyOTpFKCJMYW5ndWFnZSBkYXRhIHJlZnJlc2ggc3VjY2Vzc2Z1bC4iKTtjYXNlIDMwOi0xPT09YiYmci5yZWplY3QoImluaXRpYWxpemF0aW9uIGZhaWxlZCIpLHIucHJvZ3Jlc3Moe3dvcmtlcklkOm4sc3RhdHVzOmMscHJvZ3Jlc3M6MX0pLHIucmVzb2x2ZSgpLHQubmV4dD0zODticmVhaztjYXNlIDM1OnQucHJldj0zNSx0LnQwPXQuY2F0Y2goMyksci5yZWplY3QodC50MC50b1N0cmluZygpKTtjYXNlIDM4OmNhc2UiZW5kIjpyZXR1cm4gdC5zdG9wKCl9fSksdCxudWxsLFtbMywzNV1dKX0pKSk7cmV0dXJuIGZ1bmN0aW9uKGUscil7cmV0dXJuIHQuYXBwbHkodGhpcyxhcmd1bWVudHMpfX0oKSxUPWZ1bmN0aW9uKHQpe2Zvcih2YXIgZT1KU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KG0pKSxyPVsiaW1hZ2VDb2xvciIsImltYWdlR3JleSIsImltYWdlQmluYXJ5IiwibGF5b3V0QmxvY2tzIiwiZGVidWciXSxuPTAsaT0wLG89T2JqZWN0LmtleXModCk7aTxvLmxlbmd0aDtpKyspe3ZhciBhPW9baV07ZVthXT10W2FdfWZvcih2YXIgcz0wLHU9T2JqZWN0LmtleXMoZSk7czx1Lmxlbmd0aDtzKyspe3ZhciBoPXVbc107ZVtoXSYmKHIuaW5jbHVkZXMoaCl8fChuKz0xKSl9cmV0dXJue3dvcmtpbmdPdXRwdXQ6ZSxza2lwUmVjb2duaXRpb246MD09PW59fSxSPVsicmVjdGFuZ2xlIiwicGRmVGl0bGUiLCJwZGZUZXh0T25seSIsInJvdGF0ZUF1dG8iLCJyb3RhdGVSYWRpYW5zIl0sQz1mdW5jdGlvbigpe3ZhciB0PWMoaCgpLm1hcmsoKGZ1bmN0aW9uIHQoZSxyKXt2YXIgbixvLGEscyx1LGYsYyxwLHksZCxnLHYsbSxBLGssSSxVLFMsTCxCLF8sajtyZXR1cm4gaCgpLndyYXAoKGZ1bmN0aW9uKHQpe2Zvcig7Oylzd2l0Y2godC5wcmV2PXQubmV4dCl7Y2FzZSAwOm49ZS5wYXlsb2FkLG89bi5pbWFnZSxhPW4ub3B0aW9ucyxzPW4ub3V0cHV0O3RyeXtpZih1PXt9LCJvYmplY3QiPT09aShhKSYmT2JqZWN0LmtleXMoYSkubGVuZ3RoPjApZm9yKGY9MCxjPU9iamVjdC5rZXlzKGEpO2Y8Yy5sZW5ndGg7ZisrKShwPWNbZl0pLnN0YXJ0c1dpdGgoInRlc3Nqc18iKXx8Ui5pbmNsdWRlcyhwKXx8KHVbcF09YVtwXSk7aWYocy5kZWJ1ZyYmKHUuZGVidWdfZmlsZT0iL2RlYnVnSW50ZXJuYWwudHh0IixsLkZTLndyaXRlRmlsZSgiL2RlYnVnSW50ZXJuYWwudHh0IiwiIikpLE9iamVjdC5rZXlzKHUpLmxlbmd0aD4wKWZvcihPLlNhdmVQYXJhbWV0ZXJzKCkseT0wLGQ9T2JqZWN0LmtleXModSk7eTxkLmxlbmd0aDt5KyspZz1kW3ldLE8uU2V0VmFyaWFibGUoZyx1W2ddKTt2PVQocyksbT12LndvcmtpbmdPdXRwdXQsQT12LnNraXBSZWNvZ25pdGlvbixhLnJvdGF0ZUF1dG8/KEk9Ty5HZXRQYWdlU2VnTW9kZSgpLFU9ITEsW3guQVVUTyx4LkFVVE9fT05MWSx4Lk9TRF0uaW5jbHVkZXMoU3RyaW5nKEkpKXx8KFU9ITAsTy5TZXRWYXJpYWJsZSgidGVzc2VkaXRfcGFnZXNlZ19tb2RlIixTdHJpbmcoeC5BVVRPKSkpLHcobCxPLG8pLE8uRmluZExpbmVzKCksUz1PLkdldEdyYWRpZW50P08uR2V0R3JhZGllbnQoKTpPLkdldEFuZ2xlKCksVSYmTy5TZXRWYXJpYWJsZSgidGVzc2VkaXRfcGFnZXNlZ19tb2RlIixTdHJpbmcoSSkpLE1hdGguYWJzKFMpPj0uMDA1P3cobCxPLG8saz1TKTooVSYmdyhsLE8sbyksaz0wKSk6KGs9YS5yb3RhdGVSYWRpYW5zfHwwLHcobCxPLG8saykpLCJvYmplY3QiPT09aShMPWEucmVjdGFuZ2xlKSYmTy5TZXRSZWN0YW5nbGUoTC5sZWZ0LEwudG9wLEwud2lkdGgsTC5oZWlnaHQpLEE/KHMubGF5b3V0QmxvY2tzJiZPLkFuYWx5c2VMYXlvdXQoKSxFKCJTa2lwcGluZyByZWNvZ25pdGlvbjogYWxsIG91dHB1dCBvcHRpb25zIHJlcXVpcmluZyByZWNvZ25pdGlvbiBhcmUgZGlzYWJsZWQuIikpOk8uUmVjb2duaXplKG51bGwpLEI9YS5wZGZUaXRsZSxfPWEucGRmVGV4dE9ubHksKGo9YihsLE8sbSx7cGRmVGl0bGU6QixwZGZUZXh0T25seTpfLHNraXBSZWNvZ25pdGlvbjpBfSkpLnJvdGF0ZVJhZGlhbnM9ayxzLmRlYnVnJiZsLkZTLnVubGluaygiL2RlYnVnSW50ZXJuYWwudHh0IiksT2JqZWN0LmtleXModSkubGVuZ3RoPjAmJk8uUmVzdG9yZVBhcmFtZXRlcnMoKSxyLnJlc29sdmUoail9Y2F0Y2godCl7ci5yZWplY3QodC50b1N0cmluZygpKX1jYXNlIDI6Y2FzZSJlbmQiOnJldHVybiB0LnN0b3AoKX19KSx0KX0pKSk7cmV0dXJuIGZ1bmN0aW9uKGUscil7cmV0dXJuIHQuYXBwbHkodGhpcyxhcmd1bWVudHMpfX0oKSxNPWZ1bmN0aW9uKCl7dmFyIHQ9YyhoKCkubWFyaygoZnVuY3Rpb24gdChlLHIpe3ZhciBuLGksbyxhLHM7cmV0dXJuIGgoKS53cmFwKChmdW5jdGlvbih0KXtmb3IoOzspc3dpdGNoKHQucHJldj10Lm5leHQpe2Nhc2UgMDpuPWUucGF5bG9hZC5pbWFnZTt0cnl7dyhsLE8sbiksaT1uZXcgbC5PU1Jlc3VsdHMsTy5EZXRlY3RPUyhpKT8obz1pLmJlc3RfcmVzdWx0LGE9by5vcmllbnRhdGlvbl9pZCxzPW8uc2NyaXB0X2lkLHIucmVzb2x2ZSh7dGVzc2VyYWN0X3NjcmlwdF9pZDpzLHNjcmlwdDppLnVuaWNoYXJzZXQuZ2V0X3NjcmlwdF9mcm9tX3NjcmlwdF9pZChzKSxzY3JpcHRfY29uZmlkZW5jZTpvLnNjb25maWRlbmNlLG9yaWVudGF0aW9uX2RlZ3JlZXM6WzAsMjcwLDE4MCw5MF1bYV0sb3JpZW50YXRpb25fY29uZmlkZW5jZTpvLm9jb25maWRlbmNlfSkpOnIucmVzb2x2ZSh7dGVzc2VyYWN0X3NjcmlwdF9pZDpudWxsLHNjcmlwdDpudWxsLHNjcmlwdF9jb25maWRlbmNlOm51bGwsb3JpZW50YXRpb25fZGVncmVlczpudWxsLG9yaWVudGF0aW9uX2NvbmZpZGVuY2U6bnVsbH0pfWNhdGNoKHQpe3IucmVqZWN0KHQudG9TdHJpbmcoKSl9Y2FzZSAyOmNhc2UiZW5kIjpyZXR1cm4gdC5zdG9wKCl9fSksdCl9KSkpO3JldHVybiBmdW5jdGlvbihlLHIpe3JldHVybiB0LmFwcGx5KHRoaXMsYXJndW1lbnRzKX19KCksTj1mdW5jdGlvbigpe3ZhciB0PWMoaCgpLm1hcmsoKGZ1bmN0aW9uIHQoZSxyKXtyZXR1cm4gaCgpLndyYXAoKGZ1bmN0aW9uKHQpe2Zvcig7Oylzd2l0Y2godC5wcmV2PXQubmV4dCl7Y2FzZSAwOnRyeXtudWxsIT09TyYmTy5FbmQoKSxyLnJlc29sdmUoe3Rlcm1pbmF0ZWQ6ITB9KX1jYXRjaCh0KXtyLnJlamVjdCh0LnRvU3RyaW5nKCkpfWNhc2UgMTpjYXNlImVuZCI6cmV0dXJuIHQuc3RvcCgpfX0pLHQpfSkpKTtyZXR1cm4gZnVuY3Rpb24oZSxyKXtyZXR1cm4gdC5hcHBseSh0aGlzLGFyZ3VtZW50cyl9fSgpO2UuZGlzcGF0Y2hIYW5kbGVycz1mdW5jdGlvbih0LGUpe3ZhciByPWZ1bmN0aW9uKHIsbil7dmFyIGk9e2pvYklkOnQuam9iSWQsd29ya2VySWQ6dC53b3JrZXJJZCxhY3Rpb246dC5hY3Rpb259O2UoYShhKHt9LGkpLHt9LHtzdGF0dXM6cixkYXRhOm59KSl9O3IucmVzb2x2ZT1yLmJpbmQobiwicmVzb2x2ZSIpLHIucmVqZWN0PXIuYmluZChuLCJyZWplY3QiKSxyLnByb2dyZXNzPXIuYmluZChuLCJwcm9ncmVzcyIpLHA9cix7bG9hZDpMLEZTOkIsbG9hZExhbmd1YWdlOl8saW5pdGlhbGl6ZTpQLHNldFBhcmFtZXRlcnM6aixyZWNvZ25pemU6QyxkZXRlY3Q6TSx0ZXJtaW5hdGU6Tn1bdC5hY3Rpb25dKHQscikuY2F0Y2goKGZ1bmN0aW9uKHQpe3JldHVybiByLnJlamVjdCh0LnRvU3RyaW5nKCkpfSkpfSxlLnNldEFkYXB0ZXI9ZnVuY3Rpb24odCl7ST10fX0sOTcxOnQ9PnsidXNlIHN0cmljdCI7dC5leHBvcnRzPXtPU0RfT05MWToiMCIsQVVUT19PU0Q6IjEiLEFVVE9fT05MWToiMiIsQVVUTzoiMyIsU0lOR0xFX0NPTFVNTjoiNCIsU0lOR0xFX0JMT0NLX1ZFUlRfVEVYVDoiNSIsU0lOR0xFX0JMT0NLOiI2IixTSU5HTEVfTElORToiNyIsU0lOR0xFX1dPUkQ6IjgiLENJUkNMRV9XT1JEOiI5IixTSU5HTEVfQ0hBUjoiMTAiLFNQQVJTRV9URVhUOiIxMSIsU1BBUlNFX1RFWFRfT1NEOiIxMiIsUkFXX0xJTkU6IjEzIn19LDk3NjoodCxlLHIpPT57InVzZSBzdHJpY3QiO2Z1bmN0aW9uIG4oKXtuPWZ1bmN0aW9uKCl7cmV0dXJuIGV9O3ZhciB0LGU9e30scj1PYmplY3QucHJvdG90eXBlLG89ci5oYXNPd25Qcm9wZXJ0eSxhPU9iamVjdC5kZWZpbmVQcm9wZXJ0eXx8ZnVuY3Rpb24odCxlLHIpe3RbZV09ci52YWx1ZX0scz0iZnVuY3Rpb24iPT10eXBlb2YgU3ltYm9sP1N5bWJvbDp7fSx1PXMuaXRlcmF0b3J8fCJAQGl0ZXJhdG9yIixoPXMuYXN5bmNJdGVyYXRvcnx8IkBAYXN5bmNJdGVyYXRvciIsZj1zLnRvU3RyaW5nVGFnfHwiQEB0b1N0cmluZ1RhZyI7ZnVuY3Rpb24gYyh0LGUscil7cmV0dXJuIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0LGUse3ZhbHVlOnIsZW51bWVyYWJsZTohMCxjb25maWd1cmFibGU6ITAsd3JpdGFibGU6ITB9KSx0W2VdfXRyeXtjKHt9LCIiKX1jYXRjaCh0KXtjPWZ1bmN0aW9uKHQsZSxyKXtyZXR1cm4gdFtlXT1yfX1mdW5jdGlvbiBsKHQsZSxyLG4pe3ZhciBpPWUmJmUucHJvdG90eXBlIGluc3RhbmNlb2Ygdz9lOncsbz1PYmplY3QuY3JlYXRlKGkucHJvdG90eXBlKSxzPW5ldyBqKG58fFtdKTtyZXR1cm4gYShvLCJfaW52b2tlIix7dmFsdWU6Uyh0LHIscyl9KSxvfWZ1bmN0aW9uIHAodCxlLHIpe3RyeXtyZXR1cm57dHlwZToibm9ybWFsIixhcmc6dC5jYWxsKGUscil9fWNhdGNoKHQpe3JldHVybnt0eXBlOiJ0aHJvdyIsYXJnOnR9fX1lLndyYXA9bDt2YXIgeT0ic3VzcGVuZGVkU3RhcnQiLGQ9InN1c3BlbmRlZFlpZWxkIixnPSJleGVjdXRpbmciLGI9ImNvbXBsZXRlZCIsdj17fTtmdW5jdGlvbiB3KCl7fWZ1bmN0aW9uIG0oKXt9ZnVuY3Rpb24gQSgpe312YXIgRT17fTtjKEUsdSwoZnVuY3Rpb24oKXtyZXR1cm4gdGhpc30pKTt2YXIgaz1PYmplY3QuZ2V0UHJvdG90eXBlT2YseD1rJiZrKGsoUChbXSkpKTt4JiZ4IT09ciYmby5jYWxsKHgsdSkmJihFPXgpO3ZhciBPPUEucHJvdG90eXBlPXcucHJvdG90eXBlPU9iamVjdC5jcmVhdGUoRSk7ZnVuY3Rpb24gSSh0KXtbIm5leHQiLCJ0aHJvdyIsInJldHVybiJdLmZvckVhY2goKGZ1bmN0aW9uKGUpe2ModCxlLChmdW5jdGlvbih0KXtyZXR1cm4gdGhpcy5faW52b2tlKGUsdCl9KSl9KSl9ZnVuY3Rpb24gVSh0LGUpe2Z1bmN0aW9uIHIobixhLHMsdSl7dmFyIGg9cCh0W25dLHQsYSk7aWYoInRocm93IiE9PWgudHlwZSl7dmFyIGY9aC5hcmcsYz1mLnZhbHVlO3JldHVybiBjJiYib2JqZWN0Ij09aShjKSYmby5jYWxsKGMsIl9fYXdhaXQiKT9lLnJlc29sdmUoYy5fX2F3YWl0KS50aGVuKChmdW5jdGlvbih0KXtyKCJuZXh0Iix0LHMsdSl9KSwoZnVuY3Rpb24odCl7cigidGhyb3ciLHQscyx1KX0pKTplLnJlc29sdmUoYykudGhlbigoZnVuY3Rpb24odCl7Zi52YWx1ZT10LHMoZil9KSwoZnVuY3Rpb24odCl7cmV0dXJuIHIoInRocm93Iix0LHMsdSl9KSl9dShoLmFyZyl9dmFyIG47YSh0aGlzLCJfaW52b2tlIix7dmFsdWU6ZnVuY3Rpb24odCxpKXtmdW5jdGlvbiBvKCl7cmV0dXJuIG5ldyBlKChmdW5jdGlvbihlLG4pe3IodCxpLGUsbil9KSl9cmV0dXJuIG49bj9uLnRoZW4obyxvKTpvKCl9fSl9ZnVuY3Rpb24gUyhlLHIsbil7dmFyIGk9eTtyZXR1cm4gZnVuY3Rpb24obyxhKXtpZihpPT09Zyl0aHJvdyBFcnJvcigiR2VuZXJhdG9yIGlzIGFscmVhZHkgcnVubmluZyIpO2lmKGk9PT1iKXtpZigidGhyb3ciPT09byl0aHJvdyBhO3JldHVybnt2YWx1ZTp0LGRvbmU6ITB9fWZvcihuLm1ldGhvZD1vLG4uYXJnPWE7Oyl7dmFyIHM9bi5kZWxlZ2F0ZTtpZihzKXt2YXIgdT1MKHMsbik7aWYodSl7aWYodT09PXYpY29udGludWU7cmV0dXJuIHV9fWlmKCJuZXh0Ij09PW4ubWV0aG9kKW4uc2VudD1uLl9zZW50PW4uYXJnO2Vsc2UgaWYoInRocm93Ij09PW4ubWV0aG9kKXtpZihpPT09eSl0aHJvdyBpPWIsbi5hcmc7bi5kaXNwYXRjaEV4Y2VwdGlvbihuLmFyZyl9ZWxzZSJyZXR1cm4iPT09bi5tZXRob2QmJm4uYWJydXB0KCJyZXR1cm4iLG4uYXJnKTtpPWc7dmFyIGg9cChlLHIsbik7aWYoIm5vcm1hbCI9PT1oLnR5cGUpe2lmKGk9bi5kb25lP2I6ZCxoLmFyZz09PXYpY29udGludWU7cmV0dXJue3ZhbHVlOmguYXJnLGRvbmU6bi5kb25lfX0idGhyb3ciPT09aC50eXBlJiYoaT1iLG4ubWV0aG9kPSJ0aHJvdyIsbi5hcmc9aC5hcmcpfX19ZnVuY3Rpb24gTChlLHIpe3ZhciBuPXIubWV0aG9kLGk9ZS5pdGVyYXRvcltuXTtpZihpPT09dClyZXR1cm4gci5kZWxlZ2F0ZT1udWxsLCJ0aHJvdyI9PT1uJiZlLml0ZXJhdG9yLnJldHVybiYmKHIubWV0aG9kPSJyZXR1cm4iLHIuYXJnPXQsTChlLHIpLCJ0aHJvdyI9PT1yLm1ldGhvZCl8fCJyZXR1cm4iIT09biYmKHIubWV0aG9kPSJ0aHJvdyIsci5hcmc9bmV3IFR5cGVFcnJvcigiVGhlIGl0ZXJhdG9yIGRvZXMgbm90IHByb3ZpZGUgYSAnIituKyInIG1ldGhvZCIpKSx2O3ZhciBvPXAoaSxlLml0ZXJhdG9yLHIuYXJnKTtpZigidGhyb3ciPT09by50eXBlKXJldHVybiByLm1ldGhvZD0idGhyb3ciLHIuYXJnPW8uYXJnLHIuZGVsZWdhdGU9bnVsbCx2O3ZhciBhPW8uYXJnO3JldHVybiBhP2EuZG9uZT8ocltlLnJlc3VsdE5hbWVdPWEudmFsdWUsci5uZXh0PWUubmV4dExvYywicmV0dXJuIiE9PXIubWV0aG9kJiYoci5tZXRob2Q9Im5leHQiLHIuYXJnPXQpLHIuZGVsZWdhdGU9bnVsbCx2KTphOihyLm1ldGhvZD0idGhyb3ciLHIuYXJnPW5ldyBUeXBlRXJyb3IoIml0ZXJhdG9yIHJlc3VsdCBpcyBub3QgYW4gb2JqZWN0Iiksci5kZWxlZ2F0ZT1udWxsLHYpfWZ1bmN0aW9uIEIodCl7dmFyIGU9e3RyeUxvYzp0WzBdfTsxIGluIHQmJihlLmNhdGNoTG9jPXRbMV0pLDIgaW4gdCYmKGUuZmluYWxseUxvYz10WzJdLGUuYWZ0ZXJMb2M9dFszXSksdGhpcy50cnlFbnRyaWVzLnB1c2goZSl9ZnVuY3Rpb24gXyh0KXt2YXIgZT10LmNvbXBsZXRpb258fHt9O2UudHlwZT0ibm9ybWFsIixkZWxldGUgZS5hcmcsdC5jb21wbGV0aW9uPWV9ZnVuY3Rpb24gaih0KXt0aGlzLnRyeUVudHJpZXM9W3t0cnlMb2M6InJvb3QifV0sdC5mb3JFYWNoKEIsdGhpcyksdGhpcy5yZXNldCghMCl9ZnVuY3Rpb24gUChlKXtpZihlfHwiIj09PWUpe3ZhciByPWVbdV07aWYocilyZXR1cm4gci5jYWxsKGUpO2lmKCJmdW5jdGlvbiI9PXR5cGVvZiBlLm5leHQpcmV0dXJuIGU7aWYoIWlzTmFOKGUubGVuZ3RoKSl7dmFyIG49LTEsYT1mdW5jdGlvbiByKCl7Zm9yKDsrK248ZS5sZW5ndGg7KWlmKG8uY2FsbChlLG4pKXJldHVybiByLnZhbHVlPWVbbl0sci5kb25lPSExLHI7cmV0dXJuIHIudmFsdWU9dCxyLmRvbmU9ITAscn07cmV0dXJuIGEubmV4dD1hfX10aHJvdyBuZXcgVHlwZUVycm9yKGkoZSkrIiBpcyBub3QgaXRlcmFibGUiKX1yZXR1cm4gbS5wcm90b3R5cGU9QSxhKE8sImNvbnN0cnVjdG9yIix7dmFsdWU6QSxjb25maWd1cmFibGU6ITB9KSxhKEEsImNvbnN0cnVjdG9yIix7dmFsdWU6bSxjb25maWd1cmFibGU6ITB9KSxtLmRpc3BsYXlOYW1lPWMoQSxmLCJHZW5lcmF0b3JGdW5jdGlvbiIpLGUuaXNHZW5lcmF0b3JGdW5jdGlvbj1mdW5jdGlvbih0KXt2YXIgZT0iZnVuY3Rpb24iPT10eXBlb2YgdCYmdC5jb25zdHJ1Y3RvcjtyZXR1cm4hIWUmJihlPT09bXx8IkdlbmVyYXRvckZ1bmN0aW9uIj09PShlLmRpc3BsYXlOYW1lfHxlLm5hbWUpKX0sZS5tYXJrPWZ1bmN0aW9uKHQpe3JldHVybiBPYmplY3Quc2V0UHJvdG90eXBlT2Y/T2JqZWN0LnNldFByb3RvdHlwZU9mKHQsQSk6KHQuX19wcm90b19fPUEsYyh0LGYsIkdlbmVyYXRvckZ1bmN0aW9uIikpLHQucHJvdG90eXBlPU9iamVjdC5jcmVhdGUoTyksdH0sZS5hd3JhcD1mdW5jdGlvbih0KXtyZXR1cm57X19hd2FpdDp0fX0sSShVLnByb3RvdHlwZSksYyhVLnByb3RvdHlwZSxoLChmdW5jdGlvbigpe3JldHVybiB0aGlzfSkpLGUuQXN5bmNJdGVyYXRvcj1VLGUuYXN5bmM9ZnVuY3Rpb24odCxyLG4saSxvKXt2b2lkIDA9PT1vJiYobz1Qcm9taXNlKTt2YXIgYT1uZXcgVShsKHQscixuLGkpLG8pO3JldHVybiBlLmlzR2VuZXJhdG9yRnVuY3Rpb24ocik/YTphLm5leHQoKS50aGVuKChmdW5jdGlvbih0KXtyZXR1cm4gdC5kb25lP3QudmFsdWU6YS5uZXh0KCl9KSl9LEkoTyksYyhPLGYsIkdlbmVyYXRvciIpLGMoTyx1LChmdW5jdGlvbigpe3JldHVybiB0aGlzfSkpLGMoTywidG9TdHJpbmciLChmdW5jdGlvbigpe3JldHVybiJbb2JqZWN0IEdlbmVyYXRvcl0ifSkpLGUua2V5cz1mdW5jdGlvbih0KXt2YXIgZT1PYmplY3QodCkscj1bXTtmb3IodmFyIG4gaW4gZSlyLnB1c2gobik7cmV0dXJuIHIucmV2ZXJzZSgpLGZ1bmN0aW9uIHQoKXtmb3IoO3IubGVuZ3RoOyl7dmFyIG49ci5wb3AoKTtpZihuIGluIGUpcmV0dXJuIHQudmFsdWU9bix0LmRvbmU9ITEsdH1yZXR1cm4gdC5kb25lPSEwLHR9fSxlLnZhbHVlcz1QLGoucHJvdG90eXBlPXtjb25zdHJ1Y3RvcjpqLHJlc2V0OmZ1bmN0aW9uKGUpe2lmKHRoaXMucHJldj0wLHRoaXMubmV4dD0wLHRoaXMuc2VudD10aGlzLl9zZW50PXQsdGhpcy5kb25lPSExLHRoaXMuZGVsZWdhdGU9bnVsbCx0aGlzLm1ldGhvZD0ibmV4dCIsdGhpcy5hcmc9dCx0aGlzLnRyeUVudHJpZXMuZm9yRWFjaChfKSwhZSlmb3IodmFyIHIgaW4gdGhpcykidCI9PT1yLmNoYXJBdCgwKSYmby5jYWxsKHRoaXMscikmJiFpc05hTigrci5zbGljZSgxKSkmJih0aGlzW3JdPXQpfSxzdG9wOmZ1bmN0aW9uKCl7dGhpcy5kb25lPSEwO3ZhciB0PXRoaXMudHJ5RW50cmllc1swXS5jb21wbGV0aW9uO2lmKCJ0aHJvdyI9PT10LnR5cGUpdGhyb3cgdC5hcmc7cmV0dXJuIHRoaXMucnZhbH0sZGlzcGF0Y2hFeGNlcHRpb246ZnVuY3Rpb24oZSl7aWYodGhpcy5kb25lKXRocm93IGU7dmFyIHI9dGhpcztmdW5jdGlvbiBuKG4saSl7cmV0dXJuIHMudHlwZT0idGhyb3ciLHMuYXJnPWUsci5uZXh0PW4saSYmKHIubWV0aG9kPSJuZXh0IixyLmFyZz10KSwhIWl9Zm9yKHZhciBpPXRoaXMudHJ5RW50cmllcy5sZW5ndGgtMTtpPj0wOy0taSl7dmFyIGE9dGhpcy50cnlFbnRyaWVzW2ldLHM9YS5jb21wbGV0aW9uO2lmKCJyb290Ij09PWEudHJ5TG9jKXJldHVybiBuKCJlbmQiKTtpZihhLnRyeUxvYzw9dGhpcy5wcmV2KXt2YXIgdT1vLmNhbGwoYSwiY2F0Y2hMb2MiKSxoPW8uY2FsbChhLCJmaW5hbGx5TG9jIik7aWYodSYmaCl7aWYodGhpcy5wcmV2PGEuY2F0Y2hMb2MpcmV0dXJuIG4oYS5jYXRjaExvYywhMCk7aWYodGhpcy5wcmV2PGEuZmluYWxseUxvYylyZXR1cm4gbihhLmZpbmFsbHlMb2MpfWVsc2UgaWYodSl7aWYodGhpcy5wcmV2PGEuY2F0Y2hMb2MpcmV0dXJuIG4oYS5jYXRjaExvYywhMCl9ZWxzZXtpZighaCl0aHJvdyBFcnJvcigidHJ5IHN0YXRlbWVudCB3aXRob3V0IGNhdGNoIG9yIGZpbmFsbHkiKTtpZih0aGlzLnByZXY8YS5maW5hbGx5TG9jKXJldHVybiBuKGEuZmluYWxseUxvYyl9fX19LGFicnVwdDpmdW5jdGlvbih0LGUpe2Zvcih2YXIgcj10aGlzLnRyeUVudHJpZXMubGVuZ3RoLTE7cj49MDstLXIpe3ZhciBuPXRoaXMudHJ5RW50cmllc1tyXTtpZihuLnRyeUxvYzw9dGhpcy5wcmV2JiZvLmNhbGwobiwiZmluYWxseUxvYyIpJiZ0aGlzLnByZXY8bi5maW5hbGx5TG9jKXt2YXIgaT1uO2JyZWFrfX1pJiYoImJyZWFrIj09PXR8fCJjb250aW51ZSI9PT10KSYmaS50cnlMb2M8PWUmJmU8PWkuZmluYWxseUxvYyYmKGk9bnVsbCk7dmFyIGE9aT9pLmNvbXBsZXRpb246e307cmV0dXJuIGEudHlwZT10LGEuYXJnPWUsaT8odGhpcy5tZXRob2Q9Im5leHQiLHRoaXMubmV4dD1pLmZpbmFsbHlMb2Msdik6dGhpcy5jb21wbGV0ZShhKX0sY29tcGxldGU6ZnVuY3Rpb24odCxlKXtpZigidGhyb3ciPT09dC50eXBlKXRocm93IHQuYXJnO3JldHVybiJicmVhayI9PT10LnR5cGV8fCJjb250aW51ZSI9PT10LnR5cGU/dGhpcy5uZXh0PXQuYXJnOiJyZXR1cm4iPT09dC50eXBlPyh0aGlzLnJ2YWw9dGhpcy5hcmc9dC5hcmcsdGhpcy5tZXRob2Q9InJldHVybiIsdGhpcy5uZXh0PSJlbmQiKToibm9ybWFsIj09PXQudHlwZSYmZSYmKHRoaXMubmV4dD1lKSx2fSxmaW5pc2g6ZnVuY3Rpb24odCl7Zm9yKHZhciBlPXRoaXMudHJ5RW50cmllcy5sZW5ndGgtMTtlPj0wOy0tZSl7dmFyIHI9dGhpcy50cnlFbnRyaWVzW2VdO2lmKHIuZmluYWxseUxvYz09PXQpcmV0dXJuIHRoaXMuY29tcGxldGUoci5jb21wbGV0aW9uLHIuYWZ0ZXJMb2MpLF8ociksdn19LGNhdGNoOmZ1bmN0aW9uKHQpe2Zvcih2YXIgZT10aGlzLnRyeUVudHJpZXMubGVuZ3RoLTE7ZT49MDstLWUpe3ZhciByPXRoaXMudHJ5RW50cmllc1tlXTtpZihyLnRyeUxvYz09PXQpe3ZhciBuPXIuY29tcGxldGlvbjtpZigidGhyb3ciPT09bi50eXBlKXt2YXIgaT1uLmFyZztfKHIpfXJldHVybiBpfX10aHJvdyBFcnJvcigiaWxsZWdhbCBjYXRjaCBhdHRlbXB0Iil9LGRlbGVnYXRlWWllbGQ6ZnVuY3Rpb24oZSxyLG4pe3JldHVybiB0aGlzLmRlbGVnYXRlPXtpdGVyYXRvcjpQKGUpLHJlc3VsdE5hbWU6cixuZXh0TG9jOm59LCJuZXh0Ij09PXRoaXMubWV0aG9kJiYodGhpcy5hcmc9dCksdn19LGV9ZnVuY3Rpb24gaSh0KXtyZXR1cm4gaT0iZnVuY3Rpb24iPT10eXBlb2YgU3ltYm9sJiYic3ltYm9sIj09dHlwZW9mIFN5bWJvbC5pdGVyYXRvcj9mdW5jdGlvbih0KXtyZXR1cm4gdHlwZW9mIHR9OmZ1bmN0aW9uKHQpe3JldHVybiB0JiYiZnVuY3Rpb24iPT10eXBlb2YgU3ltYm9sJiZ0LmNvbnN0cnVjdG9yPT09U3ltYm9sJiZ0IT09U3ltYm9sLnByb3RvdHlwZT8ic3ltYm9sIjp0eXBlb2YgdH0saSh0KX1mdW5jdGlvbiBvKHQsZSxyLG4saSxvLGEpe3RyeXt2YXIgcz10W29dKGEpLHU9cy52YWx1ZX1jYXRjaCh0KXtyZXR1cm4gdm9pZCByKHQpfXMuZG9uZT9lKHUpOlByb21pc2UucmVzb2x2ZSh1KS50aGVuKG4saSl9dmFyIGE9cigyNDIpLnNpbWQscz1yKDMzMCkuRWwuUUU7dC5leHBvcnRzPWZ1bmN0aW9uKCl7dmFyIHQsZT0odD1uKCkubWFyaygoZnVuY3Rpb24gdChlLG8sdSl7dmFyIGgsZixjLGw7cmV0dXJuIG4oKS53cmFwKChmdW5jdGlvbih0KXtmb3IoOzspc3dpdGNoKHQucHJldj10Lm5leHQpe2Nhc2UgMDppZih2b2lkIDAhPT1yLmcuVGVzc2VyYWN0Q29yZSl7dC5uZXh0PTIwO2JyZWFrfWlmKGg9ImxvYWRpbmcgdGVzc2VyYWN0IGNvcmUiLHUucHJvZ3Jlc3Moe3N0YXR1czpoLHByb2dyZXNzOjB9KSwianMiIT09KGY9b3x8Imh0dHBzOi8vY2RuLmpzZGVsaXZyLm5ldC9ucG0vdGVzc2VyYWN0LmpzLWNvcmVAdiIuY29uY2F0KHMuc3Vic3RyaW5nKDEpKSkuc2xpY2UoLTIpKXt0Lm5leHQ9ODticmVha31jPWYsdC5uZXh0PTEyO2JyZWFrO2Nhc2UgODpyZXR1cm4gdC5uZXh0PTEwLGEoKTtjYXNlIDEwOmw9dC5zZW50LGM9IiIuY29uY2F0KGYucmVwbGFjZSgvXC8kLywiIiksbD9lPyIvdGVzc2VyYWN0LWNvcmUtc2ltZC1sc3RtLndhc20uanMiOiIvdGVzc2VyYWN0LWNvcmUtc2ltZC53YXNtLmpzIjplPyIvdGVzc2VyYWN0LWNvcmUtbHN0bS53YXNtLmpzIjoiL3Rlc3NlcmFjdC1jb3JlLndhc20uanMiKTtjYXNlIDEyOmlmKHIuZy5pbXBvcnRTY3JpcHRzKGMpLHZvaWQgMCE9PXIuZy5UZXNzZXJhY3RDb3JlfHx2b2lkIDA9PT1yLmcuVGVzc2VyYWN0Q29yZVdBU018fCJvYmplY3QiIT09KCJ1bmRlZmluZWQiPT10eXBlb2YgV2ViQXNzZW1ibHk/InVuZGVmaW5lZCI6aShXZWJBc3NlbWJseSkpKXt0Lm5leHQ9MTc7YnJlYWt9ci5nLlRlc3NlcmFjdENvcmU9ci5nLlRlc3NlcmFjdENvcmVXQVNNLHQubmV4dD0xOTticmVhaztjYXNlIDE3OmlmKHZvaWQgMCE9PXIuZy5UZXNzZXJhY3RDb3JlKXt0Lm5leHQ9MTk7YnJlYWt9dGhyb3cgRXJyb3IoIkZhaWxlZCB0byBsb2FkIFRlc3NlcmFjdENvcmUiKTtjYXNlIDE5OnUucHJvZ3Jlc3Moe3N0YXR1czpoLHByb2dyZXNzOjF9KTtjYXNlIDIwOnJldHVybiB0LmFicnVwdCgicmV0dXJuIixyLmcuVGVzc2VyYWN0Q29yZSk7Y2FzZSAyMTpjYXNlImVuZCI6cmV0dXJuIHQuc3RvcCgpfX0pLHQpfSkpLGZ1bmN0aW9uKCl7dmFyIGU9dGhpcyxyPWFyZ3VtZW50cztyZXR1cm4gbmV3IFByb21pc2UoKGZ1bmN0aW9uKG4saSl7dmFyIGE9dC5hcHBseShlLHIpO2Z1bmN0aW9uIHModCl7byhhLG4saSxzLHUsIm5leHQiLHQpfWZ1bmN0aW9uIHUodCl7byhhLG4saSxzLHUsInRocm93Iix0KX1zKHZvaWQgMCl9KSl9KTtyZXR1cm4gZnVuY3Rpb24odCxyLG4pe3JldHVybiBlLmFwcGx5KHRoaXMsYXJndW1lbnRzKX19KCl9fSxlPXt9O2Z1bmN0aW9uIHIobil7dmFyIGk9ZVtuXTtpZih2b2lkIDAhPT1pKXJldHVybiBpLmV4cG9ydHM7dmFyIG89ZVtuXT17aWQ6bixsb2FkZWQ6ITEsZXhwb3J0czp7fX07cmV0dXJuIHRbbl0uY2FsbChvLmV4cG9ydHMsbyxvLmV4cG9ydHMsciksby5sb2FkZWQ9ITAsby5leHBvcnRzfXIuZD0odCxlKT0+e2Zvcih2YXIgbiBpbiBlKXIubyhlLG4pJiYhci5vKHQsbikmJk9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0LG4se2VudW1lcmFibGU6ITAsZ2V0OmVbbl19KX0sci5nPWZ1bmN0aW9uKCl7aWYoIm9iamVjdCI9PXR5cGVvZiBnbG9iYWxUaGlzKXJldHVybiBnbG9iYWxUaGlzO3RyeXtyZXR1cm4gdGhpc3x8bmV3IEZ1bmN0aW9uKCJyZXR1cm4gdGhpcyIpKCl9Y2F0Y2godCl7aWYoIm9iamVjdCI9PXR5cGVvZiB3aW5kb3cpcmV0dXJuIHdpbmRvd319KCksci5vPSh0LGUpPT5PYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwodCxlKSxyLnI9dD0+eyJ1bmRlZmluZWQiIT10eXBlb2YgU3ltYm9sJiZTeW1ib2wudG9TdHJpbmdUYWcmJk9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0LFN5bWJvbC50b1N0cmluZ1RhZyx7dmFsdWU6Ik1vZHVsZSJ9KSxPYmplY3QuZGVmaW5lUHJvcGVydHkodCwiX19lc01vZHVsZSIse3ZhbHVlOiEwfSl9LHIubm1kPXQ9Pih0LnBhdGhzPVtdLHQuY2hpbGRyZW58fCh0LmNoaWxkcmVuPVtdKSx0KSwoKCk9PnsidXNlIHN0cmljdCI7ZnVuY3Rpb24gdChlKXtyZXR1cm4gdD0iZnVuY3Rpb24iPT10eXBlb2YgU3ltYm9sJiYic3ltYm9sIj09dHlwZW9mIFN5bWJvbC5pdGVyYXRvcj9mdW5jdGlvbih0KXtyZXR1cm4gdHlwZW9mIHR9OmZ1bmN0aW9uKHQpe3JldHVybiB0JiYiZnVuY3Rpb24iPT10eXBlb2YgU3ltYm9sJiZ0LmNvbnN0cnVjdG9yPT09U3ltYm9sJiZ0IT09U3ltYm9sLnByb3RvdHlwZT8ic3ltYm9sIjp0eXBlb2YgdH0sdChlKX1mdW5jdGlvbiBlKHQsZSl7dmFyIHI9T2JqZWN0LmtleXModCk7aWYoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyl7dmFyIG49T2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyh0KTtlJiYobj1uLmZpbHRlcigoZnVuY3Rpb24oZSl7cmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodCxlKS5lbnVtZXJhYmxlfSkpKSxyLnB1c2guYXBwbHkocixuKX1yZXR1cm4gcn1mdW5jdGlvbiBuKGUscixuKXtyZXR1cm4ocj1mdW5jdGlvbihlKXt2YXIgcj1mdW5jdGlvbihlKXtpZigib2JqZWN0IiE9dChlKXx8IWUpcmV0dXJuIGU7dmFyIHI9ZVtTeW1ib2wudG9QcmltaXRpdmVdO2lmKHZvaWQgMCE9PXIpe3ZhciBuPXIuY2FsbChlLCJzdHJpbmciKTtpZigib2JqZWN0IiE9dChuKSlyZXR1cm4gbjt0aHJvdyBuZXcgVHlwZUVycm9yKCJAQHRvUHJpbWl0aXZlIG11c3QgcmV0dXJuIGEgcHJpbWl0aXZlIHZhbHVlLiIpfXJldHVybiBTdHJpbmcoZSl9KGUpO3JldHVybiJzeW1ib2wiPT10KHIpP3I6cisiIn0ocikpaW4gZT9PYmplY3QuZGVmaW5lUHJvcGVydHkoZSxyLHt2YWx1ZTpuLGVudW1lcmFibGU6ITAsY29uZmlndXJhYmxlOiEwLHdyaXRhYmxlOiEwfSk6ZVtyXT1uLGV9dmFyIGk9cig5NjgpLG89cig5NzYpLGE9cigyNTgpLHM9cig3OTcpO3IuZy5hZGRFdmVudExpc3RlbmVyKCJtZXNzYWdlIiwoZnVuY3Rpb24odCl7dmFyIGU9dC5kYXRhO2kuZGlzcGF0Y2hIYW5kbGVycyhlLChmdW5jdGlvbih0KXtyZXR1cm4gcG9zdE1lc3NhZ2UodCl9KSl9KSksaS5zZXRBZGFwdGVyKGZ1bmN0aW9uKHQpe2Zvcih2YXIgcj0xO3I8YXJndW1lbnRzLmxlbmd0aDtyKyspe3ZhciBpPW51bGwhPWFyZ3VtZW50c1tyXT9hcmd1bWVudHNbcl06e307ciUyP2UoT2JqZWN0KGkpLCEwKS5mb3JFYWNoKChmdW5jdGlvbihlKXtuKHQsZSxpW2VdKX0pKTpPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycz9PYmplY3QuZGVmaW5lUHJvcGVydGllcyh0LE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKGkpKTplKE9iamVjdChpKSkuZm9yRWFjaCgoZnVuY3Rpb24oZSl7T2JqZWN0LmRlZmluZVByb3BlcnR5KHQsZSxPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKGksZSkpfSkpfXJldHVybiB0fSh7Z2V0Q29yZTpvLGd1bnppcDphLGZldGNoOmZ1bmN0aW9uKCl7fX0scykpfSkoKX0pKCk7Ci8vIyBzb3VyY2VNYXBwaW5nVVJMPXdvcmtlci5taW4uanMubWFw";
class od extends Ad {
  constructor(Z, i) {
    super(Z, i);
    nd(this, "_worker");
    this._init();
  }
  get worker() {
    return this._worker;
  }
  get meta() {
    return od.meta;
  }
  get mime_img() {
    return ["image/png", "image/jpeg", "image/gif"];
  }
  get hotkey_info() {
    return {
      name: "OCR识别",
      show: !0,
      meta: !1,
      shift: !0,
      alt: !1,
      ctrl: !0,
      key: ["o"]
    };
  }
  get tool() {
    return {
      id: this.meta.id,
      type: qd.item,
      class: ["iconfont", "icon-ocr"],
      tooltip: "OCR识别",
      click: this.click_ocr.bind(this)
    };
  }
  _init() {
    const Z = document.createElement("link");
    Z.setAttribute("rel", "stylesheet"), Z.setAttribute("href", `${this.env.server_http}/mod-file/${this.env.modname}/index.css`), document.head.appendChild(Z), this.editor.toolbar.register(this.tool);
  }
  async ocr() {
    const { doc: Z, tips: i } = this.editor, { courier: y, history: s, cursor: h, statusbar: M, clipboard: S } = Z, { modname: C } = this.env, e = await S.read_clipboard();
    let L;
    for (let [a, Y] of e)
      if (this.mime_img.includes(Y.type)) {
        L = Y;
        break;
      }
    if (!L) {
      i.tip_orange("粘贴板第一格不是图片");
      return;
    }
    this._worker || (this._worker = await Ll.createWorker(["chi_sim", "eng"], 1, {
      workerPath: Yl,
      langPath: `${this.env.server_http}/mod-file/${C}/${encodeURIComponent("tesseract/langs")}`,
      corePath: `${this.env.server_http}/mod-file/${C}/${encodeURIComponent("tesseract/core")}`
    })), i.tip_info("开始识别");
    const R = await this.worker.recognize(L), P = R.data.text.replaceAll(" ", ""), F = S.get_cubedata_from_text(P);
    return S.paste_cubes(F), i.tip_success("识别完成"), R;
  }
  close() {
    var Z;
    (Z = this.worker) == null || Z.terminate();
  }
  click_ocr(Z, i) {
    return this.ocr();
  }
  read_clipboard_image() {
  }
  export() {
    return {};
  }
  update_data(Z) {
    return Z;
  }
  static get meta() {
    return {
      name: "OCR",
      id: "deepsky:ocr",
      version: 1
    };
  }
}
const nl = (X, c) => new od(X, c);
export {
  nl as init
};
